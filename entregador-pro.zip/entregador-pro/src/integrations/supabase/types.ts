export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      bill_payments: {
        Row: {
          bill_id: string
          created_at: string
          id: string
          is_demo: boolean
          notes: string | null
          paid_amount: number
          paid_on: string
          reference_month: string
          user_id: string
        }
        Insert: {
          bill_id: string
          created_at?: string
          id?: string
          is_demo?: boolean
          notes?: string | null
          paid_amount: number
          paid_on: string
          reference_month: string
          user_id?: string
        }
        Update: {
          bill_id?: string
          created_at?: string
          id?: string
          is_demo?: boolean
          notes?: string | null
          paid_amount?: number
          paid_on?: string
          reference_month?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bill_payments_bill_id_fkey"
            columns: ["bill_id"]
            isOneToOne: false
            referencedRelation: "bills"
            referencedColumns: ["id"]
          },
        ]
      }
      bills: {
        Row: {
          active: boolean
          category: string
          created_at: string
          due_day: number
          end_month: string | null
          expected_amount: number
          id: string
          interval_months: number
          is_demo: boolean
          name: string
          notes: string | null
          start_month: string
          user_id: string
        }
        Insert: {
          active?: boolean
          category?: string
          created_at?: string
          due_day: number
          end_month?: string | null
          expected_amount: number
          id?: string
          interval_months?: number
          is_demo?: boolean
          name: string
          notes?: string | null
          start_month: string
          user_id?: string
        }
        Update: {
          active?: boolean
          category?: string
          created_at?: string
          due_day?: number
          end_month?: string | null
          expected_amount?: number
          id?: string
          interval_months?: number
          is_demo?: boolean
          name?: string
          notes?: string | null
          start_month?: string
          user_id?: string
        }
        Relationships: []
      }
      bulletins: {
        Row: {
          audio_path: string | null
          audio_started_at: string | null
          audio_status: string | null
          body_text: string
          bulletin_date: string
          cities: string[]
          created_at: string
          id: string
          intro: string | null
          items: Json
          outro: string | null
          period_end: string
          period_start: string
          slot: string
          sources: string[]
          telegram_status: string | null
          title: string
          user_id: string
        }
        Insert: {
          audio_path?: string | null
          audio_started_at?: string | null
          audio_status?: string | null
          body_text: string
          bulletin_date: string
          cities?: string[]
          created_at?: string
          id?: string
          intro?: string | null
          items?: Json
          outro?: string | null
          period_end: string
          period_start: string
          slot: string
          sources?: string[]
          telegram_status?: string | null
          title: string
          user_id: string
        }
        Update: {
          audio_path?: string | null
          audio_started_at?: string | null
          audio_status?: string | null
          body_text?: string
          bulletin_date?: string
          cities?: string[]
          created_at?: string
          id?: string
          intro?: string | null
          items?: Json
          outro?: string | null
          period_end?: string
          period_start?: string
          slot?: string
          sources?: string[]
          telegram_status?: string | null
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          created_at: string
          id: string
          message_id: string
          parts: Json
          role: string
          thread_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          message_id: string
          parts?: Json
          role: string
          thread_id: string
          user_id?: string
        }
        Update: {
          created_at?: string
          id?: string
          message_id?: string
          parts?: Json
          role?: string
          thread_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_messages_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "chat_threads"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_threads: {
        Row: {
          created_at: string
          id: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Update: {
          created_at?: string
          id?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      earnings: {
        Row: {
          amount: number
          created_at: string
          date: string
          hours: number | null
          id: string
          is_demo: boolean
          km: number | null
          notes: string | null
          source: string
          user_id: string
          workplace_id: string | null
        }
        Insert: {
          amount: number
          created_at?: string
          date: string
          hours?: number | null
          id?: string
          is_demo?: boolean
          km?: number | null
          notes?: string | null
          source: string
          user_id?: string
          workplace_id?: string | null
        }
        Update: {
          amount?: number
          created_at?: string
          date?: string
          hours?: number | null
          id?: string
          is_demo?: boolean
          km?: number | null
          notes?: string | null
          source?: string
          user_id?: string
          workplace_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "earnings_workplace_id_fkey"
            columns: ["workplace_id"]
            isOneToOne: false
            referencedRelation: "workplaces"
            referencedColumns: ["id"]
          },
        ]
      }
      entry_shortcuts: {
        Row: {
          amount: number | null
          created_at: string
          description: string | null
          hours: number | null
          id: string
          kind: string
          km: number | null
          name: string
          notes: string | null
          topic: string
          user_id: string
          workplace_id: string | null
        }
        Insert: {
          amount?: number | null
          created_at?: string
          description?: string | null
          hours?: number | null
          id?: string
          kind: string
          km?: number | null
          name: string
          notes?: string | null
          topic: string
          user_id?: string
          workplace_id?: string | null
        }
        Update: {
          amount?: number | null
          created_at?: string
          description?: string | null
          hours?: number | null
          id?: string
          kind?: string
          km?: number | null
          name?: string
          notes?: string | null
          topic?: string
          user_id?: string
          workplace_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "entry_shortcuts_workplace_id_fkey"
            columns: ["workplace_id"]
            isOneToOne: false
            referencedRelation: "workplaces"
            referencedColumns: ["id"]
          },
        ]
      }
      expenses: {
        Row: {
          amount: number
          category: string
          created_at: string
          date: string
          description: string
          id: string
          is_demo: boolean
          notes: string | null
          user_id: string
        }
        Insert: {
          amount: number
          category: string
          created_at?: string
          date: string
          description: string
          id?: string
          is_demo?: boolean
          notes?: string | null
          user_id?: string
        }
        Update: {
          amount?: number
          category?: string
          created_at?: string
          date?: string
          description?: string
          id?: string
          is_demo?: boolean
          notes?: string | null
          user_id?: string
        }
        Relationships: []
      }
      goal_contributions: {
        Row: {
          amount: number
          created_at: string
          date: string
          goal_id: string
          id: string
          is_demo: boolean
          notes: string | null
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          date: string
          goal_id: string
          id?: string
          is_demo?: boolean
          notes?: string | null
          user_id?: string
        }
        Update: {
          amount?: number
          created_at?: string
          date?: string
          goal_id?: string
          id?: string
          is_demo?: boolean
          notes?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "goal_contributions_goal_id_fkey"
            columns: ["goal_id"]
            isOneToOne: false
            referencedRelation: "goals"
            referencedColumns: ["id"]
          },
        ]
      }
      goals: {
        Row: {
          active: boolean
          basis: string
          created_at: string
          end_date: string | null
          extra_days: string[]
          id: string
          is_demo: boolean
          kind: string
          name: string
          notes: string | null
          off_days: string[]
          start_date: string
          target_amount: number
          user_id: string
          work_weekdays: number[]
        }
        Insert: {
          active?: boolean
          basis?: string
          created_at?: string
          end_date?: string | null
          extra_days?: string[]
          id?: string
          is_demo?: boolean
          kind: string
          name: string
          notes?: string | null
          off_days?: string[]
          start_date: string
          target_amount: number
          user_id?: string
          work_weekdays?: number[]
        }
        Update: {
          active?: boolean
          basis?: string
          created_at?: string
          end_date?: string | null
          extra_days?: string[]
          id?: string
          is_demo?: boolean
          kind?: string
          name?: string
          notes?: string | null
          off_days?: string[]
          start_date?: string
          target_amount?: number
          user_id?: string
          work_weekdays?: number[]
        }
        Relationships: []
      }
      installment_payments: {
        Row: {
          amount: number
          created_at: string
          id: string
          installment_id: string
          is_demo: boolean
          notes: string | null
          paid_on: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          installment_id: string
          is_demo?: boolean
          notes?: string | null
          paid_on: string
          user_id?: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          installment_id?: string
          is_demo?: boolean
          notes?: string | null
          paid_on?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "installment_payments_installment_id_fkey"
            columns: ["installment_id"]
            isOneToOne: false
            referencedRelation: "installments"
            referencedColumns: ["id"]
          },
        ]
      }
      installments: {
        Row: {
          amount: number
          created_at: string
          due_date: string
          id: string
          is_demo: boolean
          loan_id: string | null
          number: number
          paid_amount: number
          paid_at: string | null
          sale_id: string | null
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          due_date: string
          id?: string
          is_demo?: boolean
          loan_id?: string | null
          number: number
          paid_amount?: number
          paid_at?: string | null
          sale_id?: string | null
          user_id?: string
        }
        Update: {
          amount?: number
          created_at?: string
          due_date?: string
          id?: string
          is_demo?: boolean
          loan_id?: string | null
          number?: number
          paid_amount?: number
          paid_at?: string | null
          sale_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "installments_loan_id_fkey"
            columns: ["loan_id"]
            isOneToOne: false
            referencedRelation: "loans"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "installments_sale_id_fkey"
            columns: ["sale_id"]
            isOneToOne: false
            referencedRelation: "sales"
            referencedColumns: ["id"]
          },
        ]
      }
      job_state: {
        Row: {
          last_error: string | null
          last_ingest_at: string | null
          last_run_at: string | null
          locked_until: string | null
          name: string
          paused_at: string | null
          paused_reason: string | null
        }
        Insert: {
          last_error?: string | null
          last_ingest_at?: string | null
          last_run_at?: string | null
          locked_until?: string | null
          name: string
          paused_at?: string | null
          paused_reason?: string | null
        }
        Update: {
          last_error?: string | null
          last_ingest_at?: string | null
          last_run_at?: string | null
          locked_until?: string | null
          name?: string
          paused_at?: string | null
          paused_reason?: string | null
        }
        Relationships: []
      }
      loans: {
        Row: {
          created_at: string
          first_due_date: string
          id: string
          installments_count: number
          interest_rate: number | null
          is_demo: boolean
          loan_date: string
          notes: string | null
          person_name: string
          person_phone: string | null
          principal: number
          total_due: number
          user_id: string
        }
        Insert: {
          created_at?: string
          first_due_date: string
          id?: string
          installments_count: number
          interest_rate?: number | null
          is_demo?: boolean
          loan_date: string
          notes?: string | null
          person_name: string
          person_phone?: string | null
          principal: number
          total_due: number
          user_id?: string
        }
        Update: {
          created_at?: string
          first_due_date?: string
          id?: string
          installments_count?: number
          interest_rate?: number | null
          is_demo?: boolean
          loan_date?: string
          notes?: string | null
          person_name?: string
          person_phone?: string | null
          principal?: number
          total_due?: number
          user_id?: string
        }
        Relationships: []
      }
      news_items: {
        Row: {
          cities: string[]
          fetched_at: string
          id: string
          is_alert: boolean
          origin: string
          published_at: string | null
          source_id: string
          source_name: string
          summary: string | null
          title: string
          title_key: string
          topics: string[]
          url: string
        }
        Insert: {
          cities?: string[]
          fetched_at?: string
          id?: string
          is_alert?: boolean
          origin: string
          published_at?: string | null
          source_id: string
          source_name: string
          summary?: string | null
          title: string
          title_key: string
          topics?: string[]
          url: string
        }
        Update: {
          cities?: string[]
          fetched_at?: string
          id?: string
          is_alert?: boolean
          origin?: string
          published_at?: string | null
          source_id?: string
          source_name?: string
          summary?: string | null
          title?: string
          title_key?: string
          topics?: string[]
          url?: string
        }
        Relationships: []
      }
      news_preferences: {
        Row: {
          afternoon_enabled: boolean
          afternoon_time: string
          cities: string[]
          created_at: string
          morning_enabled: boolean
          morning_time: string
          tg_alerts: boolean
          tg_bulletins: boolean
          tg_from: string
          tg_topics: string[]
          tg_until: string
          topics: string[]
          updated_at: string
          user_id: string
        }
        Insert: {
          afternoon_enabled?: boolean
          afternoon_time?: string
          cities?: string[]
          created_at?: string
          morning_enabled?: boolean
          morning_time?: string
          tg_alerts?: boolean
          tg_bulletins?: boolean
          tg_from?: string
          tg_topics?: string[]
          tg_until?: string
          topics?: string[]
          updated_at?: string
          user_id?: string
        }
        Update: {
          afternoon_enabled?: boolean
          afternoon_time?: string
          cities?: string[]
          created_at?: string
          morning_enabled?: boolean
          morning_time?: string
          tg_alerts?: boolean
          tg_bulletins?: boolean
          tg_from?: string
          tg_topics?: string[]
          tg_until?: string
          topics?: string[]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      news_source_status: {
        Row: {
          last_count: number
          last_error: string | null
          last_ok_at: string | null
          last_run_at: string | null
          ok: boolean
          source_id: string
        }
        Insert: {
          last_count?: number
          last_error?: string | null
          last_ok_at?: string | null
          last_run_at?: string | null
          ok?: boolean
          source_id: string
        }
        Update: {
          last_count?: number
          last_error?: string | null
          last_ok_at?: string | null
          last_run_at?: string | null
          ok?: boolean
          source_id?: string
        }
        Relationships: []
      }
      notification_log: {
        Row: {
          id: string
          kind: string
          news_id: string
          sent_at: string
          user_id: string
        }
        Insert: {
          id?: string
          kind: string
          news_id: string
          sent_at?: string
          user_id: string
        }
        Update: {
          id?: string
          kind?: string
          news_id?: string
          sent_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notification_log_news_id_fkey"
            columns: ["news_id"]
            isOneToOne: false
            referencedRelation: "news_items"
            referencedColumns: ["id"]
          },
        ]
      }
      phone_verifications: {
        Row: {
          attempts: number
          code_hash: string
          expires_at: string
          phone: string
          sent_at: string
          user_id: string
        }
        Insert: {
          attempts?: number
          code_hash: string
          expires_at: string
          phone: string
          sent_at?: string
          user_id: string
        }
        Update: {
          attempts?: number
          code_hash?: string
          expires_at?: string
          phone?: string
          sent_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          email: string
          full_name: string
          id: string
          phone: string
          phone_verified: boolean
          phone_verified_at: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          email?: string
          full_name?: string
          id: string
          phone?: string
          phone_verified?: boolean
          phone_verified_at?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          phone?: string
          phone_verified?: boolean
          phone_verified_at?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      sales: {
        Row: {
          created_at: string
          customer_name: string
          customer_phone: string | null
          description: string
          down_payment: number
          first_due_date: string
          id: string
          installments_count: number
          is_demo: boolean
          notes: string | null
          sale_date: string
          total: number
          user_id: string
        }
        Insert: {
          created_at?: string
          customer_name: string
          customer_phone?: string | null
          description: string
          down_payment?: number
          first_due_date: string
          id?: string
          installments_count: number
          is_demo?: boolean
          notes?: string | null
          sale_date: string
          total: number
          user_id?: string
        }
        Update: {
          created_at?: string
          customer_name?: string
          customer_phone?: string | null
          description?: string
          down_payment?: number
          first_due_date?: string
          id?: string
          installments_count?: number
          is_demo?: boolean
          notes?: string | null
          sale_date?: string
          total?: number
          user_id?: string
        }
        Relationships: []
      }
      tasks: {
        Row: {
          created_at: string
          done: boolean
          done_at: string | null
          due_date: string
          due_time: string | null
          id: string
          is_demo: boolean
          notes: string | null
          title: string
          user_id: string
        }
        Insert: {
          created_at?: string
          done?: boolean
          done_at?: string | null
          due_date: string
          due_time?: string | null
          id?: string
          is_demo?: boolean
          notes?: string | null
          title: string
          user_id?: string
        }
        Update: {
          created_at?: string
          done?: boolean
          done_at?: string | null
          due_date?: string
          due_time?: string | null
          id?: string
          is_demo?: boolean
          notes?: string | null
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      telegram_link_codes: {
        Row: {
          code: string
          created_at: string
          expires_at: string
          user_id: string
        }
        Insert: {
          code: string
          created_at?: string
          expires_at: string
          user_id: string
        }
        Update: {
          code?: string
          created_at?: string
          expires_at?: string
          user_id?: string
        }
        Relationships: []
      }
      telegram_links: {
        Row: {
          chat_id: number
          linked_at: string
          tg_name: string | null
          tg_username: string | null
          user_id: string
        }
        Insert: {
          chat_id: number
          linked_at?: string
          tg_name?: string | null
          tg_username?: string | null
          user_id: string
        }
        Update: {
          chat_id?: number
          linked_at?: string
          tg_name?: string | null
          tg_username?: string | null
          user_id?: string
        }
        Relationships: []
      }
      workplaces: {
        Row: {
          address: string | null
          app_used: string | null
          created_at: string
          id: string
          is_demo: boolean
          name: string
          notes: string | null
          photo_path: string | null
          start_date: string | null
          user_id: string
        }
        Insert: {
          address?: string | null
          app_used?: string | null
          created_at?: string
          id?: string
          is_demo?: boolean
          name: string
          notes?: string | null
          photo_path?: string | null
          start_date?: string | null
          user_id?: string
        }
        Update: {
          address?: string | null
          app_used?: string | null
          created_at?: string
          id?: string
          is_demo?: boolean
          name?: string
          notes?: string | null
          photo_path?: string | null
          start_date?: string | null
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      create_loan_with_installments: {
        Args: { p_installments: Json; p_loan: Json }
        Returns: string
      }
      create_sale_with_installments: {
        Args: { p_installments: Json; p_sale: Json }
        Returns: string
      }
      ingest_news: { Args: { p_items: Json }; Returns: number }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
