import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Nels Nere actions that need server secrets (news reading, AI, Telegram). */

export const refreshNews = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { ingestIfStale } = await import("@/lib/nels-job.server");
    const { data: job } = await supabaseAdmin.from("job_state").select("last_ingest_at").eq("name", "nels-nere").single();
    // At most one full read every 3 minutes, shared by everyone.
    const recent = job?.last_ingest_at && Date.now() - new Date(job.last_ingest_at).getTime() < 3 * 60_000;
    if (recent) return { inserted: 0, recent: true, failed: [] as string[] };
    const r = await ingestIfStale(supabaseAdmin, { last_ingest_at: null }, true);
    return { inserted: r?.inserted ?? 0, recent: false, failed: r?.failed ?? [] };
  });

export const generateBulletinNow = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { createBulletin, BulletinAiError } = await import("@/lib/bulletins.server");
    const { localDate } = await import("@/lib/news");
    const { aiErrorMessage } = await import("@/lib/ai/gateway.server");
    const { data: prefs } = await context.supabase
      .from("news_preferences")
      .select("cities, topics")
      .eq("user_id", context.userId)
      .maybeSingle();
    const now = new Date();
    try {
      const { bulletin } = await createBulletin(
        supabaseAdmin,
        { user_id: context.userId, cities: prefs?.cities ?? [], topics: prefs?.topics ?? [] },
        "avulso",
        localDate(now),
        "00:00",
        now,
      );
      return { ok: true as const, id: bulletin.id };
    } catch (e) {
      console.error("generateBulletinNow failed", e);
      const status = e instanceof BulletinAiError ? e.status : undefined;
      return { ok: false as const, error: status ? aiErrorMessage(e) : "Não consegui montar o boletim agora. Tente de novo." };
    }
  });

export const getTelegramStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { telegramConfigured, getBotInfo } = await import("@/lib/telegram.server");
    const { data: link } = await context.supabase
      .from("telegram_links")
      .select("tg_name, tg_username, linked_at")
      .eq("user_id", context.userId)
      .maybeSingle();
    if (!telegramConfigured()) return { configured: false as const, link };
    try {
      const bot = await getBotInfo();
      return { configured: true as const, bot: bot.username, link };
    } catch (e) {
      return { configured: false as const, link, error: e instanceof Error ? e.message : "Bot indisponível" };
    }
  });

export const createTelegramLink = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { telegramConfigured, getBotInfo } = await import("@/lib/telegram.server");
    if (!telegramConfigured()) return { ok: false as const, error: "O bot do Telegram ainda não foi configurado neste app." };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    const bytes = new Uint8Array(8);
    crypto.getRandomValues(bytes);
    const code = Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("");
    await supabaseAdmin.from("telegram_link_codes").delete().eq("user_id", context.userId);
    const { error } = await supabaseAdmin
      .from("telegram_link_codes")
      .insert({ code, user_id: context.userId, expires_at: new Date(Date.now() + 15 * 60_000).toISOString() });
    if (error) return { ok: false as const, error: "Não consegui gerar o código. Tente de novo." };
    const bot = await getBotInfo();
    return { ok: true as const, code, bot: bot.username, link: `https://t.me/${bot.username}?start=${code}` };
  });

export const sendTelegramTest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({}).passthrough().parse(d ?? {}))
  .handler(async ({ context }) => {
    const { telegramConfigured, sendTelegramMessage } = await import("@/lib/telegram.server");
    if (!telegramConfigured()) return { ok: false as const, error: "O bot do Telegram ainda não foi configurado." };
    const { data: link } = await context.supabase.from("telegram_links").select("chat_id").eq("user_id", context.userId).maybeSingle();
    if (!link) return { ok: false as const, error: "Conecte seu Telegram primeiro." };
    try {
      await sendTelegramMessage(link.chat_id, "✅ Teste do <b>Nels Nere</b>: suas notificações estão funcionando.");
      return { ok: true as const };
    } catch (e) {
      return { ok: false as const, error: e instanceof Error ? e.message : "Falha no envio" };
    }
  });

export const sendBulletinToTelegram = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { telegramConfigured, sendTelegramMessage, escapeHtml } = await import("@/lib/telegram.server");
    if (!telegramConfigured()) return { ok: false as const, error: "O bot do Telegram ainda não foi configurado." };
    const [{ data: link }, { data: b }] = await Promise.all([
      context.supabase.from("telegram_links").select("chat_id").eq("user_id", context.userId).maybeSingle(),
      context.supabase.from("bulletins").select("*").eq("id", data.id).maybeSingle(),
    ]);
    if (!link) return { ok: false as const, error: "Conecte seu Telegram primeiro." };
    if (!b) return { ok: false as const, error: "Boletim não encontrado." };
    const { bulletinTelegramHtml } = await import("@/lib/bulletins.server");
    const { APP_URL } = await import("@/lib/nels-job.server");
    try {
      await sendTelegramMessage(link.chat_id, bulletinTelegramHtml(b, APP_URL, escapeHtml));
      return { ok: true as const };
    } catch (e) {
      return { ok: false as const, error: e instanceof Error ? e.message : "Falha no envio" };
    }
  });
