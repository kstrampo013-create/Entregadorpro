import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { CITIES, NEWS_SOURCES, normalizeText, stripSourceSuffix, TIME_ZONE, TOPICS, zonedToUtc } from "@/lib/news";
import { fetchFeed, googleNewsUrl } from "@/lib/news-ingest.server";

export type NewsFilters = {
  cidade: string | null;
  assunto: string | null;
  fonte: string | null;
  desde: string | null;
  ate: string | null;
  texto: string | null;
  limite: number | null;
};

function fmt(iso: string | null) {
  if (!iso) return "data não informada";
  return new Intl.DateTimeFormat("pt-BR", { timeZone: TIME_ZONE, dateStyle: "short", timeStyle: "short" }).format(new Date(iso));
}

function matchCity(input: string): string | null {
  const n = normalizeText(input).trim();
  return CITIES.find((c) => normalizeText(c).trim() === n) ?? CITIES.find((c) => normalizeText(c).includes(n)) ?? null;
}

/** Stored news the user can read (RLS), filtered for Thassi. */
export async function searchStoredNews(supabase: SupabaseClient<Database>, f: NewsFilters) {
  let q = supabase
    .from("news_items")
    .select("title, summary, source_name, url, published_at, cities, topics")
    .order("published_at", { ascending: false, nullsFirst: false })
    .limit(Math.min(Math.max(f.limite ?? 12, 1), 25));
  const notes: string[] = [];
  if (f.cidade) {
    const city = matchCity(f.cidade);
    if (city) q = q.contains("cities", [city]);
    else notes.push(`A cidade "${f.cidade}" não está entre as acompanhadas; busquei sem filtro de cidade.`);
  }
  if (f.assunto && TOPICS.some((t) => t.id === f.assunto)) q = q.contains("topics", [f.assunto]);
  if (f.fonte) {
    const n = normalizeText(f.fonte).trim();
    const src = NEWS_SOURCES.find((s) => normalizeText(s.name).includes(n) || s.domain.includes(n.replace(/\s/g, "")));
    if (src) q = q.eq("source_id", src.id);
    else q = q.ilike("source_name", `%${f.fonte.replace(/[%_,()]/g, " ")}%`);
  }
  if (f.desde && /^\d{4}-\d{2}-\d{2}$/.test(f.desde)) q = q.gte("published_at", zonedToUtc(f.desde, "00:00").toISOString());
  if (f.ate && /^\d{4}-\d{2}-\d{2}$/.test(f.ate)) q = q.lte("published_at", zonedToUtc(f.ate, "23:59").toISOString());
  if (f.texto) {
    const t = f.texto.replace(/[%_,()*.:"\\]/g, " ").trim();
    if (t) q = q.or(`title.ilike.%${t}%,summary.ilike.%${t}%`);
  }
  const { data, error } = await q;
  if (error) return { erro: `Falha ao consultar as notícias: ${error.message}` };
  return {
    total: data.length,
    observacoes: notes,
    noticias: data.map((n) => ({
      titulo: n.title,
      resumo: n.summary ?? "(sem resumo; detalhes no link)",
      fonte: n.source_name,
      link: n.url,
      publicada: fmt(n.published_at),
      cidades: n.cities,
      assuntos: n.topics.map((t) => TOPICS.find((x) => x.id === t)?.label ?? t),
    })),
  };
}

/** Live Google News search (last 7 days) for what is not in the stored base. */
export async function searchGoogleNews(consulta: string) {
  try {
    const entries = await fetchFeed(googleNewsUrl(`${consulta} when:7d`));
    return {
      total: Math.min(entries.length, 10),
      aviso: "Resultados do Google Notícias: só título, veículo e data. Detalhes apenas no link.",
      noticias: entries.slice(0, 10).map((e) => ({
        titulo: stripSourceSuffix(e.title, e.sourceName),
        fonte: e.sourceName ?? "Google Notícias",
        link: e.link,
        publicada: e.pubDate ? fmt(new Date(e.pubDate).toISOString()) : "data não informada",
      })),
    };
  } catch (e) {
    return { erro: `Não consegui consultar o Google Notícias agora (${e instanceof Error ? e.message : "erro"}).` };
  }
}
