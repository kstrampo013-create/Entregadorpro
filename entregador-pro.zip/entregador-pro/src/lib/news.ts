/**
 * Nels Nere — pure news rules (sources, cities, topics, dedupe keys, bulletin windows).
 * No I/O here so it runs in the browser, the server and the unit tests alike.
 */

export const TIME_ZONE = "America/Sao_Paulo";

export type NewsSource = {
  id: string;
  name: string;
  site: string;
  domain: string;
  /** Public RSS feed, when the outlet offers one that answers automated reads. */
  rss: string | null;
  /** How the app reaches this source, shown to the user. */
  access: "rss" | "google";
  note?: string;
};

export const NEWS_SOURCES: NewsSource[] = [
  {
    id: "diariodovale",
    name: "Diário do Vale",
    site: "https://diariodovale.com.br",
    domain: "diariodovale.com.br",
    rss: null,
    access: "google",
    note: "O site bloqueia a leitura automática do feed. As matérias chegam pelo Google Notícias, com link para o site oficial.",
  },
  {
    id: "jornalaqui",
    name: "Jornal aQui",
    site: "https://jornalaqui.com.br",
    domain: "jornalaqui.com.br",
    rss: "https://jornalaqui.com.br/feed/",
    access: "rss",
  },
  {
    id: "focoregional",
    name: "Foco Regional",
    site: "https://focoregional.com.br",
    domain: "focoregional.com.br",
    rss: null,
    access: "google",
    note: "Não oferece feed público. As matérias chegam pelo Google Notícias.",
  },
  {
    id: "jornalponto",
    name: "Jornal Ponto",
    site: "https://www.jornalponto.com/site/",
    domain: "jornalponto.com",
    rss: "https://www.jornalponto.com/site/feed/",
    access: "rss",
  },
  {
    id: "folhasulfluminense",
    name: "Folha Sul Fluminense",
    site: "https://folhasulfluminense.com.br",
    domain: "folhasulfluminense.com.br",
    rss: "https://folhasulfluminense.com.br/feed/",
    access: "rss",
  },
  {
    id: "cidadenet",
    name: "Portal CidadeNet",
    site: "https://portalcidadenet.com.br",
    domain: "portalcidadenet.com.br",
    rss: "https://portalcidadenet.com.br/feed/",
    access: "rss",
  },
  {
    id: "prefeituravr",
    name: "Volta Redonda — Portal de Notícias",
    site: "https://www.voltaredonda.rj.gov.br",
    domain: "voltaredonda.rj.gov.br",
    rss: null,
    access: "google",
    note: "Portal oficial da Prefeitura de Volta Redonda; sem feed público. As notícias chegam pelo Google Notícias.",
  },
  {
    id: "avozdacidade",
    name: "A Voz da Cidade",
    site: "https://avozdacidade.com",
    domain: "avozdacidade.com",
    rss: "https://avozdacidade.com/wp/feed/",
    access: "rss",
  },
  {
    id: "folhadointerior",
    name: "Folha do Interior",
    site: "https://www.folhadointerior.com.br",
    domain: "folhadointerior.com.br",
    rss: "https://www.folhadointerior.com.br/feed/",
    access: "rss",
  },
  {
    id: "guiasulfluminense",
    name: "Guia Sul Fluminense",
    site: "https://guiasulfluminense.com.br",
    domain: "guiasulfluminense.com.br",
    rss: "https://guiasulfluminense.com.br/feed/",
    access: "rss",
  },
];

/** Google News searches that complement the outlets (other sources found by Google). */
export const GOOGLE_REGION_QUERIES = [
  '"Volta Redonda"',
  '"Barra Mansa"',
  '"Resende" RJ',
  '"Sul Fluminense"',
  '"Barra do Piraí" OR Pinheiral OR "Porto Real" OR Itatiaia OR Quatis',
  '"Angra dos Reis" OR Paraty OR Valença OR Vassouras',
];

/** Longest names first so "Barra do Piraí" is matched before "Piraí". */
export const CITIES = [
  "Engenheiro Paulo de Frontin",
  "Paty do Alferes",
  "Miguel Pereira",
  "Barra do Piraí",
  "Angra dos Reis",
  "Volta Redonda",
  "Rio das Flores",
  "Barra Mansa",
  "Mangaratiba",
  "Porto Real",
  "Pinheiral",
  "Rio Claro",
  "Itatiaia",
  "Vassouras",
  "Resende",
  "Valença",
  "Paraty",
  "Quatis",
  "Piraí",
] as const;

export const MAIN_CITIES = ["Volta Redonda", "Barra Mansa", "Resende", "Barra do Piraí", "Pinheiral", "Porto Real", "Itatiaia", "Angra dos Reis"];

export const TOPICS: { id: string; label: string; keywords: string[] }[] = [
  {
    id: "seguranca",
    label: "Segurança",
    keywords: ["policia", "policial", "pm ", "preso", "presa", "prisao", "prende", "apreend", "tiro", "baleado", "homicid", "assassin", "roubo", "furto", "trafico", "crime", "suspeito", "delegacia", "guarda municipal", "drogas", "cocaina", "maconha", "foragido"],
  },
  {
    id: "transito",
    label: "Trânsito",
    keywords: ["transito", "acidente", "colisao", "rodovia", "dutra", "br-393", "br-116", "rj-", "engarrafamento", "onibus", "motorista", "motociclista", "moto ", "carreta", "caminhao", "atropel", "radar", "estrada", "viaduto", "serra das araras"],
  },
  {
    id: "politica",
    label: "Política",
    keywords: ["prefeito", "prefeita", "vereador", "camara municipal", "eleicao", "eleicoes", "eleitor", "deputad", "governador", "governo", "senado", "candidat", "politic", "lula", "bolsonaro", "stf", "tse"],
  },
  {
    id: "economia",
    label: "Economia e empregos",
    keywords: ["emprego", "vagas", "empresa", "csn", "industria", "economia", "comercio", "investimento", "salario", "inflacao", "mercado", "combustive", "gasolina", "preco", "fabrica", "contrata", "feirao"],
  },
  {
    id: "saude",
    label: "Saúde",
    keywords: ["saude", "hospital", "vacina", "dengue", "upa", "medico", "sus ", "doenca", "santa casa", "posto de saude", "cirurgia", "epidemia", "gripe"],
  },
  {
    id: "educacao",
    label: "Educação",
    keywords: ["escola", "educacao", "aluno", "universidade", "enem", "ensino", "professor", "uff", "ubm", "unifoa", "matricula", "creche", "estudante"],
  },
  {
    id: "esportes",
    label: "Esportes",
    keywords: ["futebol", "voltaco", "esporte", "campeonato", "partida", "atleta", "torneio", "corrida", "serie c", "serie d", "estadio", "raulino"],
  },
  {
    id: "cultura",
    label: "Cultura e lazer",
    keywords: ["cultura", "show", "festival", "teatro", "musica", "exposicao", "festa", "cinema", "lazer", "turismo", "feira", "artista", "rouanet"],
  },
  {
    id: "clima",
    label: "Tempo e clima",
    keywords: ["chuva", "temporal", "calor", "frio", "previsao do tempo", "alagamento", "enchente", "defesa civil", "deslizamento", "tempestade", "ventania", "inmet"],
  },
  {
    id: "servicos",
    label: "Serviços públicos",
    keywords: ["prefeitura", "inscricoes", "inscricao", "abastecimento", "falta de agua", "saae", "energia eletrica", "light", "enel", "concurso", "programa", "castracao", "iptu", "mutirao", "atendimento"],
  },
];

/** Words that make a story worth an "alerta" notification (automatic keyword detection). */
export const ALERT_KEYWORDS = [
  "interdit",
  "interdicao",
  "temporal",
  "enchente",
  "alagamento",
  "deslizamento",
  "desabamento",
  "incendio",
  "alerta",
  "urgente",
  "falta de agua",
  "sem agua",
  "sem energia",
  "apagao",
  "rompimento",
  "tiroteio",
  "pista bloqueada",
  "bloqueio total",
  "evacua",
];

export function topicLabel(id: string): string {
  return TOPICS.find((t) => t.id === id)?.label ?? id;
}

export function sourceById(id: string): NewsSource | undefined {
  return NEWS_SOURCES.find((s) => s.id === id);
}

/** Lowercase, no accents, punctuation turned into spaces, padded so word matching is simple. */
export function normalizeText(text: string): string {
  return (
    " " +
    text
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9-]+/g, " ")
      .replace(/\s+/g, " ")
      .trim() +
    " "
  );
}

/** Keyword matches at the start of a word ("apreend" matches "apreendidos"). */
function hasKeyword(normalized: string, keyword: string): boolean {
  const k = normalizeText(keyword).trimStart();
  // keep a trailing space when the keyword asks for a whole word ("pm ", "sus ")
  const needle = keyword.endsWith(" ") ? " " + k : " " + k.trimEnd();
  return normalized.includes(needle);
}

export function detectCities(text: string): string[] {
  let t = normalizeText(text);
  const found: string[] = [];
  for (const city of CITIES) {
    const needle = normalizeText(city);
    if (t.includes(needle)) {
      found.push(city);
      t = t.split(needle).join(" ");
    }
  }
  return found;
}

export function detectTopics(text: string): string[] {
  const t = normalizeText(text);
  return TOPICS.filter((topic) => topic.keywords.some((k) => hasKeyword(t, k))).map((topic) => topic.id);
}

export function isAlert(text: string): boolean {
  const t = normalizeText(text);
  return ALERT_KEYWORDS.some((k) => hasKeyword(t, k));
}

/** Google News titles end with " - Source name"; drop it to compare titles across sources. */
export function stripSourceSuffix(title: string, sourceName?: string | null): string {
  const t = title.trim();
  if (sourceName) {
    const suffix = ` - ${sourceName}`;
    if (t.toLowerCase().endsWith(suffix.toLowerCase())) return t.slice(0, -suffix.length).trim();
  }
  return t;
}

/** Same story = same normalized title (accents, case and punctuation ignored). */
export function titleKey(title: string): string {
  return normalizeText(title).trim().slice(0, 160);
}

/** Remove tracking params, hash and trailing slash so the same link is stored once. */
export function normalizeUrl(raw: string): string {
  try {
    const u = new URL(raw.trim());
    u.hash = "";
    for (const key of [...u.searchParams.keys()]) {
      if (/^(utm_|fbclid|gclid|amp$)/i.test(key)) u.searchParams.delete(key);
    }
    let s = u.toString();
    if (s.endsWith("/") && u.pathname !== "/") s = s.slice(0, -1);
    return s;
  } catch {
    return raw.trim();
  }
}

const ENTITIES: Record<string, string> = {
  "&amp;": "&",
  "&lt;": "<",
  "&gt;": ">",
  "&quot;": '"',
  "&#039;": "'",
  "&apos;": "'",
  "&nbsp;": " ",
  "&hellip;": "…",
  "&#8230;": "…",
  "&#8211;": "–",
  "&#8212;": "—",
  "&#8216;": "‘",
  "&#8217;": "’",
  "&#8220;": "“",
  "&#8221;": "”",
};

export function decodeEntities(text: string): string {
  return text
    .replace(/&#(\d+);/g, (m, n) => (ENTITIES[m] ?? String.fromCodePoint(Number(n))))
    .replace(/&#x([0-9a-f]+);/gi, (_m, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/&[a-z]+;/gi, (m) => ENTITIES[m.toLowerCase()] ?? m);
}

/** RSS description → plain summary (no HTML, no "The post … appeared first on …"). */
export function cleanSummary(html: string | null | undefined, max = 420): string | null {
  if (!html) return null;
  let t = decodeEntities(String(html).replace(/<[^>]*>/g, " "));
  t = t.replace(/The post .*? appeared first on .*?\.?$/i, "");
  t = t.replace(/O post .*? apareceu primeiro em .*?\.?$/i, "");
  t = t.replace(/\s+/g, " ").trim();
  if (!t) return null;
  if (t.length > max) t = t.slice(0, max).replace(/\s+\S*$/, "") + "…";
  return t;
}

/** Titles we never keep (official gazette entries, empty titles). */
export function isNoiseTitle(title: string): boolean {
  const t = title.trim();
  return t.length < 12 || /^SEI\//i.test(t) || /^(despacho|portaria|edital) n/i.test(t);
}

/* ---------------- time helpers (São Paulo) ---------------- */

function zoneParts(date: Date, timeZone = TIME_ZONE) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  }).formatToParts(date);
  const get = (type: string) => Number(parts.find((p) => p.type === type)?.value ?? 0);
  return { year: get("year"), month: get("month"), day: get("day"), hour: get("hour"), minute: get("minute"), second: get("second") };
}

/** "yyyy-MM-dd" of the given instant in São Paulo. */
export function localDate(date: Date, timeZone = TIME_ZONE): string {
  const p = zoneParts(date, timeZone);
  return `${p.year}-${String(p.month).padStart(2, "0")}-${String(p.day).padStart(2, "0")}`;
}

/** Minutes since midnight in São Paulo. */
export function localMinutes(date: Date, timeZone = TIME_ZONE): number {
  const p = zoneParts(date, timeZone);
  return p.hour * 60 + p.minute;
}

/** "06:00" / "06:00:00" → 360 */
export function timeToMinutes(time: string): number {
  const [h, m] = time.split(":").map((x) => Number(x));
  return (h ?? 0) * 60 + (m ?? 0);
}

/** The UTC instant of a São Paulo wall-clock date + time. */
export function zonedToUtc(date: string, time: string, timeZone = TIME_ZONE): Date {
  const [y, mo, d] = date.split("-").map(Number);
  const minutes = timeToMinutes(time);
  const guess = Date.UTC(y!, mo! - 1, d!, Math.floor(minutes / 60), minutes % 60);
  // offset of the zone at that moment (works for any zone, with or without DST)
  const p = zoneParts(new Date(guess), timeZone);
  const asUtc = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second);
  return new Date(guess - (asUtc - guess));
}

export type BulletinSlot = "manha" | "tarde";

/**
 * Period covered by each bulletin:
 * - manhã: the 12 hours before its time (night and early morning);
 * - tarde: from midnight of the same day until its time.
 */
export function bulletinWindow(slot: BulletinSlot, date: string, time: string): { start: Date; end: Date } {
  const end = zonedToUtc(date, time);
  if (slot === "manha") return { start: new Date(end.getTime() - 12 * 3600_000), end };
  return { start: zonedToUtc(date, "00:00"), end };
}

/** A bulletin is due from its time until 3 hours later (missed runs are not sent hours late). */
export const BULLETIN_GRACE_MIN = 180;

export function isBulletinDue(now: Date, time: string, enabled: boolean): boolean {
  if (!enabled) return false;
  const diff = localMinutes(now) - timeToMinutes(time);
  return diff >= 0 && diff < BULLETIN_GRACE_MIN;
}

/** Notification window, e.g. 07:00–22:00; supports windows across midnight (22:00–06:00). */
export function isWithinWindow(now: Date, from: string, until: string): boolean {
  const n = localMinutes(now);
  const f = timeToMinutes(from);
  const u = timeToMinutes(until);
  if (f === u) return true;
  return f < u ? n >= f && n < u : n >= f || n < u;
}

export type RankableItem = {
  id: string;
  published_at: string | null;
  fetched_at: string;
  cities: string[];
  topics: string[];
  origin: string;
  is_alert: boolean;
};

/** Filter by the user's cities/topics (empty = all) and order most relevant first. */
export function pickBulletinItems<T extends RankableItem>(
  items: T[],
  prefs: { cities: string[]; topics: string[] },
  limit = 10,
): T[] {
  const filtered = items.filter((it) => {
    const cityOk = prefs.cities.length === 0 ? it.cities.length > 0 : it.cities.some((c) => prefs.cities.includes(c));
    const topicOk = prefs.topics.length === 0 || it.topics.some((t) => prefs.topics.includes(t));
    return cityOk && topicOk;
  });
  const score = (it: T) =>
    (it.is_alert ? 3 : 0) + (it.origin === "rss" ? 1 : 0) + Math.min(it.cities.length, 2) * 0.5;
  const time = (it: T) => new Date(it.published_at ?? it.fetched_at).getTime();
  return [...filtered].sort((a, b) => score(b) - score(a) || time(b) - time(a)).slice(0, limit);
}
