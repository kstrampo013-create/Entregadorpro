/**
 * Telegram bot through the Lovable connector gateway (the bot token never reaches app code).
 * Needs LOVABLE_API_KEY and TELEGRAM_API_KEY (Telegram connector linked to the project).
 */
const GATEWAY_URL = "https://connector-gateway.lovable.dev/telegram";

export function telegramConfigured(): boolean {
  return Boolean(process.env["LOVABLE_API_KEY"] && process.env["TELEGRAM_API_KEY"]);
}

export class TelegramError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}

export async function telegramCall<T = unknown>(method: string, body: Record<string, unknown>): Promise<T> {
  const lovable = process.env["LOVABLE_API_KEY"];
  const tg = process.env["TELEGRAM_API_KEY"];
  if (!lovable || !tg) throw new TelegramError("Telegram ainda não foi conectado a este app.", 503);
  const res = await fetch(`${GATEWAY_URL}/${method}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${lovable}`,
      "X-Connection-Api-Key": tg,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  if (!res.ok) {
    console.error(`Telegram ${method} failed [${res.status}]: ${text}`);
    throw new TelegramError(`Telegram recusou o envio [${res.status}]: ${text.slice(0, 200)}`, res.status);
  }
  const data = JSON.parse(text) as { ok: boolean; result?: T; description?: string };
  if (!data.ok) throw new TelegramError(`Telegram: ${data.description ?? "erro"}`, 400);
  return data.result as T;
}

export function escapeHtml(text: string): string {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

export async function sendTelegramMessage(chatId: number, html: string) {
  return telegramCall("sendMessage", {
    chat_id: chatId,
    text: html.slice(0, 4000),
    parse_mode: "HTML",
    link_preview_options: { is_disabled: true },
  });
}

let botCache: { username: string; name: string } | null = null;
export async function getBotInfo() {
  if (botCache) return botCache;
  const me = await telegramCall<{ username: string; first_name: string }>("getMe", {});
  botCache = { username: me.username, name: me.first_name };
  return botCache;
}

/** Secret Telegram must echo on every webhook call (derived, never stored). */
export async function webhookSecret(): Promise<string> {
  const key = process.env["TELEGRAM_API_KEY"] ?? "";
  const { createHash } = await import("node:crypto");
  return createHash("sha256").update(`telegram-webhook:${key}`).digest("base64url");
}
