import { Output, streamText } from "ai";
import { z } from "zod";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { aiErrorStatus, CHAT_MODEL, createGatewayProvider, responsesOptions } from "@/lib/ai/gateway.server";
import { bulletinWindow, pickBulletinItems, TIME_ZONE, type BulletinSlot } from "@/lib/news";

type Admin = SupabaseClient<Database>;
type Prefs = Database["public"]["Tables"]["news_preferences"]["Row"];
type News = Database["public"]["Tables"]["news_items"]["Row"];

export type BulletinItem = {
  id: string;
  title: string;
  summary: string;
  source: string;
  url: string;
  cities: string[];
  published_at: string | null;
};

const SLOT_TITLE: Record<string, string> = { manha: "Boletim da manhã", tarde: "Boletim da tarde", avulso: "Boletim extra" };

const schema = z.object({
  abertura: z.string(),
  manchetes: z.array(z.object({ id: z.string(), titulo: z.string(), resumo: z.string() })),
  encerramento: z.string(),
});

function fmtTime(iso: string | null) {
  if (!iso) return "horário não informado";
  return new Intl.DateTimeFormat("pt-BR", { timeZone: TIME_ZONE, day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }).format(new Date(iso));
}

function fmtDate(date: string) {
  const [y, m, d] = date.split("-");
  return `${d}/${m}/${y}`;
}

export class BulletinAiError extends Error {
  constructor(
    message: string,
    public status: number | undefined,
  ) {
    super(message);
  }
}

/** Writes the spoken-style text for the chosen stories using only their titles/summaries. */
async function writeWithAi(slot: string, date: string, picked: News[]) {
  const { provider } = createGatewayProvider();
  const list = picked
    .map(
      (n, i) =>
        `${i + 1}. id=${n.id}\nTítulo: ${n.title}\nResumo do veículo: ${n.summary ?? "(sem resumo — use só o título)"}\nFonte: ${n.source_name}\nCidades: ${n.cities.join(", ") || "região"}\nPublicada: ${fmtTime(n.published_at)}`,
    )
    .join("\n\n");
  const result = streamText({
    model: provider.responses(CHAT_MODEL),
    providerOptions: responsesOptions("low"),
    output: Output.object({ schema }),
    instructions:
      "Você é Thassi, apresentadora do boletim de notícias Nels Nere, do Sul Fluminense (RJ). Escreva em português do Brasil, em tom de rádio: frases curtas, claras e naturais para serem lidas em voz alta. " +
      "Use SOMENTE os fatos presentes no título e no resumo de cada notícia. Não invente números, nomes, horários nem detalhes. Se o resumo não existir, resuma apenas o que o título diz e diga que os detalhes estão na fonte. " +
      "Para cada notícia, devolva o mesmo id recebido, um título curto e um resumo de 1 a 3 frases que cite a cidade e o nome da fonte (por exemplo: 'segundo o Diário do Vale'). " +
      "A abertura cumprimenta (bom dia / boa tarde), diz a data e quantas notícias serão lidas. O encerramento é uma frase curta lembrando que os links estão no app.",
    prompt: `${SLOT_TITLE[slot]} de ${fmtDate(date)}. Notícias selecionadas (mantenha a ordem):\n\n${list}`,
  });
  try {
    return await result.output;
  } catch (e) {
    throw new BulletinAiError(e instanceof Error ? e.message : String(e), aiErrorStatus(e));
  }
}

/**
 * Builds and stores one bulletin for a user. Idempotent for regular slots
 * (unique per user/date/slot): a second call returns the existing bulletin.
 */
export async function createBulletin(
  admin: Admin,
  prefs: Pick<Prefs, "user_id" | "cities" | "topics">,
  slot: BulletinSlot | "avulso",
  date: string,
  time: string,
  now = new Date(),
) {
  if (slot !== "avulso") {
    const { data: existing } = await admin
      .from("bulletins")
      .select("*")
      .eq("user_id", prefs.user_id)
      .eq("slot", slot)
      .eq("bulletin_date", date)
      .maybeSingle();
    if (existing) return { bulletin: existing, created: false };
  }
  const window =
    slot === "avulso" ? { start: new Date(now.getTime() - 12 * 3600_000), end: now } : bulletinWindow(slot, date, time);

  const { data: rows, error } = await admin
    .from("news_items")
    .select("*")
    .or(
      `and(published_at.gte.${window.start.toISOString()},published_at.lte.${window.end.toISOString()}),and(published_at.is.null,fetched_at.gte.${window.start.toISOString()},fetched_at.lte.${window.end.toISOString()})`,
    )
    .order("published_at", { ascending: false, nullsFirst: false })
    .limit(400);
  if (error) throw new Error(`news query: ${error.message}`);
  const picked = pickBulletinItems(rows ?? [], { cities: prefs.cities, topics: prefs.topics }, 8);

  let intro: string;
  let outro: string | null = null;
  let items: BulletinItem[] = [];
  let body: string;
  const where = prefs.cities.length ? prefs.cities.join(", ") : "Sul Fluminense";
  if (picked.length === 0) {
    intro = `Não encontrei notícias publicadas entre ${fmtTime(window.start.toISOString())} e ${fmtTime(window.end.toISOString())} sobre ${where} nas fontes acompanhadas.`;
    body = intro;
  } else {
    const ai = await writeWithAi(slot, date, picked);
    const byId = new Map(picked.map((n) => [n.id, n]));
    const seen = new Set<string>();
    for (const m of ai.manchetes) {
      const n = byId.get(m.id);
      if (!n || seen.has(n.id)) continue; // ignore ids the model did not receive
      seen.add(n.id);
      items.push({ id: n.id, title: m.titulo || n.title, summary: m.resumo, source: n.source_name, url: n.url, cities: n.cities, published_at: n.published_at });
    }
    if (items.length === 0) {
      items = picked.map((n) => ({ id: n.id, title: n.title, summary: n.summary ?? "Detalhes na fonte.", source: n.source_name, url: n.url, cities: n.cities, published_at: n.published_at }));
    }
    intro = ai.abertura;
    outro = ai.encerramento;
    body = [intro, ...items.map((it) => `${it.title}. ${it.summary}`), outro].filter(Boolean).join("\n\n");
  }

  const record: Database["public"]["Tables"]["bulletins"]["Insert"] = {
    user_id: prefs.user_id,
    slot,
    bulletin_date: date,
    title: `${SLOT_TITLE[slot]} — ${fmtDate(date)}`,
    intro,
    outro,
    body_text: body,
    items: items as never,
    sources: [...new Set(items.map((i) => i.source))],
    cities: [...new Set(items.flatMap((i) => i.cities))],
    period_start: window.start.toISOString(),
    period_end: window.end.toISOString(),
  };
  const { data: saved, error: insErr } = await admin.from("bulletins").insert(record).select("*").single();
  if (insErr) {
    if (insErr.code === "23505" && slot !== "avulso") {
      const { data: existing } = await admin.from("bulletins").select("*").eq("user_id", prefs.user_id).eq("slot", slot).eq("bulletin_date", date).single();
      return { bulletin: existing!, created: false };
    }
    throw new Error(`bulletin insert: ${insErr.message}`);
  }
  return { bulletin: saved, created: true };
}

/** Telegram text (HTML) for a bulletin, with the source links. */
export function bulletinTelegramHtml(b: Database["public"]["Tables"]["bulletins"]["Row"], appUrl: string, escape: (s: string) => string) {
  const items = (b.items as unknown as BulletinItem[]) ?? [];
  const lines = [`<b>📰 Nels Nere · ${escape(b.title)}</b>`, "", escape(b.intro ?? "")];
  items.forEach((it, i) => {
    lines.push("", `<b>${i + 1}. ${escape(it.title)}</b>`, escape(it.summary), `<a href="${escape(it.url)}">${escape(it.source)}</a>`);
  });
  if (b.outro) lines.push("", escape(b.outro));
  lines.push("", `🎧 Ouça na voz da Thassi: ${escape(appUrl)}/noticias/boletins`);
  return lines.join("\n");
}
