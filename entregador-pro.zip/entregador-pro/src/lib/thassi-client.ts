import { createParser } from "eventsource-parser";
import { supabase } from "@/integrations/supabase/client";
import { chunkForSpeech, toSpeakable } from "@/lib/speech-text";

/** Browser helpers for Thassi: signed-in requests, her voice (streamed) and voice questions. */

export async function authHeaders(): Promise<Record<string, string>> {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function errorText(res: Response) {
  const raw = await res.text();
  try {
    return (JSON.parse(raw) as { error?: string }).error ?? raw;
  } catch {
    return raw || `Erro ${res.status}`;
  }
}

function decodePCM(pending: Uint8Array, incoming: Uint8Array) {
  const bytes = new Uint8Array(pending.length + incoming.length);
  bytes.set(pending);
  bytes.set(incoming, pending.length);
  const usable = bytes.length - (bytes.length % 2);
  const view = new DataView(bytes.buffer);
  const samples = new Float32Array(usable / 2);
  for (let i = 0; i < samples.length; i++) samples[i] = view.getInt16(i * 2, true) / 32768;
  return { samples, pending: bytes.slice(usable) };
}

async function speakChunk(text: string, signal: AbortSignal): Promise<void> {
  signal.throwIfAborted();
  const context = new AudioContext({ sampleRate: 24000 });
  const sources = new Set<AudioBufferSourceNode>();
  let playhead = 0;
  let pending = new Uint8Array(0);
  let completed = false;
  let samplesPlayed = 0;
  const controller = new AbortController();
  const abort = () => {
    controller.abort(signal.reason);
    for (const s of sources) s.stop();
  };
  signal.addEventListener("abort", abort, { once: true });
  let playback: Promise<void> = Promise.resolve();
  try {
    if (context.state === "suspended") await context.resume();
    const res = await fetch("/api/thassi/tts", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(await authHeaders()) },
      body: JSON.stringify({ text }),
      signal: controller.signal,
    });
    if (!res.ok || !res.body) throw new Error(await errorText(res));
    const parser = createParser({
      onEvent(event) {
        const payload = JSON.parse(event.data) as { type: string; audio?: string; error?: unknown };
        if (payload.type === "error" || payload.error) throw new Error("A voz falhou no meio da leitura.");
        if (payload.type === "speech.audio.done") {
          completed = true;
          return;
        }
        if (payload.type !== "speech.audio.delta" || !payload.audio) return;
        const decoded = decodePCM(pending, Uint8Array.from(atob(payload.audio), (c) => c.charCodeAt(0)));
        pending = new Uint8Array(decoded.pending);
        if (!decoded.samples.length) return;
        samplesPlayed += decoded.samples.length;
        const buffer = context.createBuffer(1, decoded.samples.length, 24000);
        buffer.copyToChannel(decoded.samples, 0);
        const source = context.createBufferSource();
        source.buffer = buffer;
        source.connect(context.destination);
        sources.add(source);
        playback = new Promise<void>((resolve) => {
          source.onended = () => {
            sources.delete(source);
            resolve();
          };
        });
        playhead = Math.max(playhead, context.currentTime + 0.05);
        source.start(playhead);
        playhead += buffer.duration;
      },
    });
    const reader = res.body.pipeThrough(new TextDecoderStream()).getReader();
    try {
      for (;;) {
        const next = await reader.read();
        if (next.done) break;
        parser.feed(next.value);
      }
      parser.reset({ consume: true });
    } finally {
      reader.releaseLock();
    }
    if (!completed || !samplesPlayed) throw new Error("A voz não chegou completa.");
    await playback;
    signal.throwIfAborted();
  } finally {
    signal.removeEventListener("abort", abort);
    controller.abort();
    for (const s of sources) s.stop();
    await context.close();
  }
}

/** Reads a (markdown) answer aloud in Thassi's voice, chunk by chunk, until done or aborted. */
export async function speak(markdown: string, signal: AbortSignal) {
  const text = toSpeakable(markdown.split(/\n\s*\**fontes:?\**/i)[0] ?? markdown);
  for (const chunk of chunkForSpeech(text, 700)) await speakChunk(chunk, signal);
}

function encodeWav(chunks: readonly Float32Array[], sampleRate: number): Blob {
  const length = chunks.reduce((s, c) => s + c.length, 0);
  const bytes = new ArrayBuffer(44 + length * 2);
  const view = new DataView(bytes);
  const tag = (o: number, v: string) => {
    for (let i = 0; i < v.length; i++) view.setUint8(o + i, v.charCodeAt(i));
  };
  tag(0, "RIFF");
  view.setUint32(4, 36 + length * 2, true);
  tag(8, "WAVE");
  tag(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  tag(36, "data");
  view.setUint32(40, length * 2, true);
  let o = 44;
  for (const c of chunks)
    for (const v of c) {
      const s = Math.max(-1, Math.min(1, v));
      view.setInt16(o, s * (s < 0 ? 32768 : 32767), true);
      o += 2;
    }
  return new Blob([bytes], { type: "audio/wav" });
}

/** Records the microphone into a complete WAV file. */
export async function recordWav(): Promise<{ stop: () => Promise<File>; cancel: () => void }> {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  let context: AudioContext | undefined;
  try {
    context = new AudioContext();
    await context.resume();
    const ctx = context;
    const source = ctx.createMediaStreamSource(stream);
    const node = ctx.createScriptProcessor(4096, 1, 1);
    const chunks: Float32Array[] = [];
    node.onaudioprocess = (e) => chunks.push(new Float32Array(e.inputBuffer.getChannelData(0)));
    source.connect(node);
    node.connect(ctx.destination);
    let stopped = false;
    const release = () => {
      stopped = true;
      stream.getTracks().forEach((t) => t.stop());
      node.disconnect();
      source.disconnect();
      node.onaudioprocess = null;
    };
    return {
      async stop() {
        if (stopped) throw new Error("Gravação já encerrada");
        release();
        const blob = encodeWav(chunks, ctx.sampleRate);
        await ctx.close();
        if (blob.size < 8192) throw new Error("Não ouvi nada. Segure e fale de novo.");
        return new File([blob], "pergunta.wav", { type: "audio/wav" });
      },
      cancel() {
        if (stopped) return;
        release();
        void ctx.close();
      },
    };
  } catch (error) {
    stream.getTracks().forEach((t) => t.stop());
    await context?.close();
    throw error;
  }
}

/** Voice question → text (Portuguese). */
export async function transcribe(file: File): Promise<string> {
  const form = new FormData();
  form.append("file", file);
  const res = await fetch("/api/thassi/stt", { method: "POST", headers: await authHeaders(), body: form });
  if (!res.ok || !res.body) throw new Error(await errorText(res));
  let text = "";
  let final: string | null = null;
  let failure: string | null = null;
  const parser = createParser({
    onEvent(event) {
      if (event.data === "[DONE]") return;
      const p = JSON.parse(event.data) as { type?: string; delta?: string; text?: string; error?: unknown };
      if (p.type === "error" || p.error) failure = "Não consegui entender o áudio.";
      else if (p.type === "transcript.text.delta" && p.delta) text += p.delta;
      else if (p.type === "transcript.text.done") final = p.text ?? text;
    },
  });
  const reader = res.body.pipeThrough(new TextDecoderStream()).getReader();
  for (;;) {
    const next = await reader.read();
    if (next.done) break;
    parser.feed(next.value);
  }
  if (failure) throw new Error(failure);
  if (final === null) throw new Error("A transcrição não terminou. Tente de novo.");
  return (final as string).trim();
}

export async function getBulletinAudioUrl(bulletinId: string): Promise<string> {
  const res = await fetch("/api/thassi/bulletin-audio", {
    method: "POST",
    headers: { "Content-Type": "application/json", ...(await authHeaders()) },
    body: JSON.stringify({ bulletinId }),
  });
  if (!res.ok) throw new Error(await errorText(res));
  return ((await res.json()) as { url: string }).url;
}
