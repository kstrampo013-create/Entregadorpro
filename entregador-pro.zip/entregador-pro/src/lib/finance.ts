import {
  addDays,
  addMonths,
  addYears,
  endOfMonth,
  endOfWeek,
  format,
  getDaysInMonth,
  parseISO,
  startOfMonth,
  startOfWeek,
  subDays,
  subMonths,
  subWeeks,
} from "date-fns";

/** Pure financial rules. Everything here is covered by src/lib/finance.test.ts. */

export const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
const cents = (n: number) => Math.round(n * 100);

export interface PlannedInstallment {
  number: number;
  amount: number;
  due_date: string;
}

/**
 * Splits `amount` into `count` installments that add up exactly to `amount`.
 * Every installment gets the same value; the last one absorbs the rounding difference.
 * Due dates are monthly from `firstDue` (day clamped to month length, e.g. 31/01 -> 28/02).
 */
export function buildInstallments(amount: number, count: number, firstDue: string): PlannedInstallment[] {
  if (!Number.isInteger(count) || count < 1) throw new Error("Quantidade de parcelas inválida");
  if (!(amount > 0)) throw new Error("Valor deve ser maior que zero");
  const totalCents = cents(amount);
  const base = Math.floor(totalCents / count);
  const first = parseISO(firstDue);
  return Array.from({ length: count }, (_, i) => {
    const isLast = i === count - 1;
    const c = isLast ? totalCents - base * (count - 1) : base;
    return {
      number: i + 1,
      amount: c / 100,
      due_date: format(addMonths(first, i), "yyyy-MM-dd"),
    };
  });
}

/** Amount financed in a sale (total minus down payment). */
export function financedAmount(total: number, downPayment: number): number {
  return round2(total - (downPayment || 0));
}

/**
 * Total to be repaid on a loan. Interest is ONLY applied when the user informed a rate;
 * an empty/null rate means no interest at all.
 * The rate is a simple percentage over the principal for the whole agreement.
 */
export function loanTotal(principal: number, interestRatePct: number | null | undefined): number {
  if (interestRatePct == null || Number.isNaN(interestRatePct) || interestRatePct === 0) return round2(principal);
  return round2(principal * (1 + interestRatePct / 100));
}

export type InstallmentStatus = "pago" | "parcial" | "atrasado" | "pendente";

export function installmentStatus(
  i: { amount: number; paid_amount: number; due_date: string },
  today: string,
): InstallmentStatus {
  const remaining = round2(Number(i.amount) - Number(i.paid_amount));
  if (remaining <= 0) return "pago";
  if (i.due_date < today) return "atrasado";
  if (Number(i.paid_amount) > 0) return "parcial";
  return "pendente";
}

export function remainingOf(i: { amount: number; paid_amount: number }): number {
  return Math.max(0, round2(Number(i.amount) - Number(i.paid_amount)));
}

/** Earnings per km; null when there is no km data. */
export function perKm(earnings: number, kmTotal: number): number | null {
  if (!kmTotal || kmTotal <= 0) return null;
  return round2(earnings / kmTotal);
}

export function perHour(earnings: number, hours: number): number | null {
  if (!hours || hours <= 0) return null;
  return round2(earnings / hours);
}

export function sum<T>(rows: T[], pick: (r: T) => number | string | null | undefined): number {
  return round2(rows.reduce((acc, r) => acc + (Number(pick(r)) || 0), 0));
}

export interface Range {
  start: string;
  end: string;
}

export type PeriodKind = "dia" | "semana" | "mes";

/** Week starts on Monday. */
export function periodRange(kind: PeriodKind, ref: string): Range {
  const d = parseISO(ref);
  const f = (x: Date) => format(x, "yyyy-MM-dd");
  if (kind === "dia") return { start: ref, end: ref };
  if (kind === "semana") return { start: f(startOfWeek(d, { weekStartsOn: 1 })), end: f(endOfWeek(d, { weekStartsOn: 1 })) };
  return { start: f(startOfMonth(d)), end: f(endOfMonth(d)) };
}

/** The equivalent period immediately before `kind` at `ref`. */
export function previousPeriod(kind: PeriodKind, ref: string): Range {
  const d = parseISO(ref);
  const f = (x: Date) => format(x, "yyyy-MM-dd");
  if (kind === "dia") return periodRange("dia", f(subDays(d, 1)));
  if (kind === "semana") return periodRange("semana", f(subWeeks(d, 1)));
  return periodRange("mes", f(subMonths(d, 1)));
}

export const inRange = (date: string | null | undefined, r: Range) => !!date && date >= r.start && date <= r.end;

/* ---------------- Recurring bills ---------------- */

export interface BillLike {
  id: string;
  due_day: number;
  interval_months: number;
  start_month: string; // any date in the first month
  end_month: string | null;
  active: boolean;
}

export interface BillOccurrence {
  bill_id: string;
  reference_month: string; // yyyy-MM-01
  due_date: string;
}

/** Due date of a bill in a given month (day clamped to the month length). */
export function billDueDate(dueDay: number, monthISO: string): string {
  const m = parseISO(monthISO);
  const day = Math.min(dueDay, getDaysInMonth(m));
  return format(new Date(m.getFullYear(), m.getMonth(), day), "yyyy-MM-dd");
}

/** All occurrences of a bill whose due date falls inside `range`. */
export function billOccurrences(bill: BillLike, range: Range): BillOccurrence[] {
  if (!bill.active) return [];
  const out: BillOccurrence[] = [];
  let m = startOfMonth(parseISO(bill.start_month));
  const endLimit = bill.end_month ? startOfMonth(parseISO(bill.end_month)) : null;
  const rangeEnd = parseISO(range.end);
  let guard = 0;
  while (m <= rangeEnd && guard < 600) {
    if (endLimit && m > endLimit) break;
    const ref = format(m, "yyyy-MM-dd");
    const due = billDueDate(bill.due_day, ref);
    if (due >= range.start && due <= range.end) out.push({ bill_id: bill.id, reference_month: ref, due_date: due });
    m = addMonths(m, bill.interval_months);
    guard++;
  }
  return out;
}

export type BillStatus = "pago" | "atrasado" | "pendente";
export function billStatus(dueDate: string, paid: boolean, today: string): BillStatus {
  if (paid) return "pago";
  return dueDate < today ? "atrasado" : "pendente";
}

/* ---------------- Wallet (receivables) ---------------- */

export interface WalletInstallment {
  amount: number;
  paid_amount: number;
  due_date: string;
}

export interface WalletSummary {
  original: number;
  received: number;
  remaining: number;
  pendingCount: number;
  nextDue: string | null;
  status: "quitado" | "atrasado" | "em_dia";
}

/** Aggregates one contract (sale or loan). Computed from installments only, so payments are never double counted. */
export function summarizeContract(installments: WalletInstallment[], today: string): WalletSummary {
  const original = sum(installments, (i) => i.amount);
  const received = sum(installments, (i) => Math.min(Number(i.paid_amount), Number(i.amount)));
  const open = installments.filter((i) => remainingOf(i) > 0).sort((a, b) => a.due_date.localeCompare(b.due_date));
  const remaining = round2(original - received);
  return {
    original,
    received,
    remaining,
    pendingCount: open.length,
    nextDue: open[0]?.due_date ?? null,
    status: open.length === 0 ? "quitado" : open.some((i) => i.due_date < today) ? "atrasado" : "em_dia",
  };
}

export interface DayResult {
  earned: number;
  spent: number;
  /** Real gain of the day: earnings minus expenses already spent. */
  net: number;
}

/**
 * Per-day earnings, expenses and real gain (earned − spent) inside `range`.
 * Future-dated expenses are planned, not spent, so they never reduce a day's result.
 * Only days with at least one entry appear in the map.
 */
export function dailyResults(
  earnings: { date: string; amount: number | string }[],
  expenses: { date: string; amount: number | string }[],
  range: Range,
  today: string,
): Map<string, DayResult> {
  const c = new Map<string, { e: number; s: number }>();
  const add = (date: string, key: "e" | "s", amount: number | string) => {
    if (!inRange(date, range)) return;
    const cur = c.get(date) ?? { e: 0, s: 0 };
    cur[key] += cents(Number(amount) || 0);
    c.set(date, cur);
  };
  for (const e of earnings) add(e.date, "e", e.amount);
  for (const x of expenses) if (x.date <= today) add(x.date, "s", x.amount);
  const out = new Map<string, DayResult>();
  for (const [date, v] of c) out.set(date, { earned: v.e / 100, spent: v.s / 100, net: (v.e - v.s) / 100 });
  return out;
}

/* ---------------- Goals (metas) ---------------- */

export type GoalKind = "mensal" | "objetivo";
export type GoalBasis = "lucro" | "ganhos" | "guardado";
export type DurationUnit = "dias" | "meses" | "anos";

export interface GoalLike {
  kind: GoalKind | string;
  target_amount: number | string;
  start_date: string;
  end_date: string | null;
  /** 0 = domingo … 6 = sábado */
  work_weekdays: number[];
  extra_days: string[];
  off_days: string[];
}

const iso = (d: Date) => format(d, "yyyy-MM-dd");
const dayBefore = (date: string) => iso(subDays(parseISO(date), 1));

/** Last day of a goal that starts on `start` and lasts `amount` days/months/years (start day included). */
export function goalEndDate(start: string, amount: number, unit: DurationUnit): string {
  if (!Number.isInteger(amount) || amount < 1) throw new Error("Duração inválida");
  const s = parseISO(start);
  if (unit === "dias") return iso(addDays(s, amount - 1));
  if (unit === "meses") return iso(subDays(addMonths(s, amount), 1));
  return iso(subDays(addYears(s, amount), 1));
}

/** A day counts as a work day when its weekday is in the pattern, unless the user unmarked it; extra days are always work days. */
export function isGoalWorkDay(goal: Pick<GoalLike, "work_weekdays" | "extra_days" | "off_days">, date: string): boolean {
  if (goal.off_days.includes(date)) return false;
  if (goal.extra_days.includes(date)) return true;
  return goal.work_weekdays.includes(parseISO(date).getDay());
}

/** Flips one day between "vou trabalhar" and "folga" and returns the new override lists. */
export function toggleGoalDay(
  goal: Pick<GoalLike, "work_weekdays" | "extra_days" | "off_days">,
  date: string,
): { extra_days: string[]; off_days: string[] } {
  const inPattern = goal.work_weekdays.includes(parseISO(date).getDay());
  const extra = goal.extra_days.filter((d) => d !== date);
  const off = goal.off_days.filter((d) => d !== date);
  const wasWork = isGoalWorkDay(goal, date);
  if (wasWork && inPattern) off.push(date);
  if (!wasWork && !inPattern) extra.push(date);
  return { extra_days: extra.sort(), off_days: off.sort() };
}

/**
 * The period a date belongs to. Monthly goals restart every month (first month starts on start_date);
 * a goal with a deadline is one period from start_date to end_date. Null when the date is outside the goal.
 */
export function goalPeriod(goal: GoalLike, date: string): Range | null {
  if (date < goal.start_date || (goal.end_date && date > goal.end_date)) return null;
  if (goal.kind !== "mensal") return { start: goal.start_date, end: goal.end_date ?? goal.start_date };
  const m = periodRange("mes", date);
  return {
    start: m.start < goal.start_date ? goal.start_date : m.start,
    end: goal.end_date && goal.end_date < m.end ? goal.end_date : m.end,
  };
}

export function goalWorkDays(goal: GoalLike, range: Range): string[] {
  if (range.end < range.start) return [];
  const out: string[] = [];
  let d = parseISO(range.start);
  const end = parseISO(range.end);
  let guard = 0;
  while (d <= end && guard < 4000) {
    const s = iso(d);
    if (isGoalWorkDay(goal, s)) out.push(s);
    d = addDays(d, 1);
    guard++;
  }
  return out;
}

/** Amount that counts toward a goal on each day: real gain, earnings only, or money set aside for it. */
export function goalDailyValues(
  basis: GoalBasis | string,
  data: {
    earnings: { date: string; amount: number | string }[];
    expenses: { date: string; amount: number | string }[];
    contributions: { date: string; amount: number | string }[];
  },
  today: string,
): Map<string, number> {
  const c = new Map<string, number>();
  const add = (date: string, amount: number | string, sign: 1 | -1) =>
    c.set(date, (c.get(date) ?? 0) + sign * cents(Number(amount) || 0));
  if (basis === "guardado") {
    for (const x of data.contributions) add(x.date, x.amount, 1);
  } else {
    for (const e of data.earnings) add(e.date, e.amount, 1);
    if (basis === "lucro") for (const x of data.expenses) if (x.date <= today) add(x.date, x.amount, -1);
  }
  const out = new Map<string, number>();
  for (const [d, v] of c) out.set(d, v / 100);
  return out;
}

function sumValues(values: Map<string, number>, start: string, end: string): number {
  if (end < start) return 0;
  let t = 0;
  for (const [d, v] of values) if (d >= start && d <= end) t += cents(v);
  return t / 100;
}

const ceilDiv = (amount: number, parts: number) => Math.ceil(cents(amount) / parts) / 100;

/**
 * How much must be made on each remaining work day of the period of `date` (date ≥ today).
 * Counts what was already made before that day, so the daily target rises when a day falls short
 * and drops when a day goes beyond. Null when `date` is not a work day, is outside the goal, or the goal is already reached.
 */
export function goalDayTarget(goal: GoalLike, values: Map<string, number>, date: string, today: string): number | null {
  if (date < today || !isGoalWorkDay(goal, date)) return null;
  const p = goalPeriod(goal, date);
  if (!p) return null;
  const from = today > p.start ? today : p.start;
  const missing = round2(Number(goal.target_amount) - sumValues(values, p.start, dayBefore(from)));
  if (missing <= 0) return null;
  const left = goalWorkDays(goal, { start: from, end: p.end }).length;
  return left > 0 ? ceilDiv(missing, left) : null;
}

export type GoalStatus = "concluida" | "em_andamento" | "futura" | "encerrada" | "sem_dias";

export interface GoalProgress {
  period: Range;
  target: number;
  achieved: number;
  remaining: number;
  /** 0–100 */
  pct: number;
  workDays: number;
  /** Work days from today (included) to the end of the period. */
  workDaysLeft: number;
  /** What each remaining work day needs, counting from the start of today. */
  perDay: number | null;
  todayIsWorkDay: boolean;
  todayDone: number;
  /** What is still missing today to hit today's target. */
  todayMissing: number;
  monthsLeft: number;
  perMonth: number | null;
  status: GoalStatus;
}

export function goalProgress(goal: GoalLike, values: Map<string, number>, today: string): GoalProgress {
  const target = round2(Number(goal.target_amount));
  const ref = today < goal.start_date ? goal.start_date : goal.end_date && today > goal.end_date ? goal.end_date : today;
  const period = goalPeriod(goal, ref)!;
  const upTo = today < period.end ? today : period.end;
  const achieved = sumValues(values, period.start, upTo);
  const remaining = Math.max(0, round2(target - achieved));
  const from = today > period.start ? today : period.start;
  const workDaysLeft = today > period.end ? 0 : goalWorkDays(goal, { start: from, end: period.end }).length;
  const before = sumValues(values, period.start, dayBefore(from));
  const missingAtStart = Math.max(0, round2(target - before));
  const perDay = missingAtStart > 0 && workDaysLeft > 0 ? ceilDiv(missingAtStart, workDaysLeft) : null;
  const inside = today >= period.start && today <= period.end;
  const todayIsWorkDay = inside && isGoalWorkDay(goal, today);
  const todayDone = inside ? (values.get(today) ?? 0) : 0;
  const todayMissing = todayIsWorkDay && perDay != null ? Math.max(0, round2(perDay - todayDone)) : 0;
  const monthsLeft =
    today > period.end
      ? 0
      : (parseISO(period.end).getFullYear() - parseISO(from).getFullYear()) * 12 +
        (parseISO(period.end).getMonth() - parseISO(from).getMonth()) +
        1;
  const status: GoalStatus =
    achieved >= target
      ? "concluida"
      : today < goal.start_date
        ? "futura"
        : goal.end_date && today > goal.end_date
          ? "encerrada"
          : workDaysLeft === 0
            ? "sem_dias"
            : "em_andamento";
  return {
    period,
    target,
    achieved,
    remaining,
    pct: target > 0 ? Math.min(100, Math.max(0, Math.round((achieved / target) * 100))) : 0,
    workDays: goalWorkDays(goal, period).length,
    workDaysLeft,
    perDay,
    todayIsWorkDay,
    todayDone,
    todayMissing,
    monthsLeft,
    perMonth: goal.kind === "mensal" ? target : monthsLeft > 0 && remaining > 0 ? ceilDiv(remaining, monthsLeft) : null,
    status,
  };
}
