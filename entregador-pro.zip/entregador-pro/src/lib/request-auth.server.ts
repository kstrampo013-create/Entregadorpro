import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

/** Verifies the Supabase bearer token of a server-route request; RLS then applies as that user. */
export async function authenticateRequest(request: Request) {
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) return { error: new Response("Server configuration error", { status: 500 }) } as const;
  const token = /^Bearer (.+)$/.exec(request.headers.get("authorization") ?? "")?.[1];
  if (!token || token.split(".").length !== 3) {
    return { error: Response.json({ error: "Faça login novamente." }, { status: 401 }) } as const;
  }
  const supabase = createClient<Database>(url, key, {
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
      headers: { Authorization: `Bearer ${token}` },
    },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data, error } = await supabase.auth.getClaims(token);
  if (error || !data?.claims?.sub) {
    return { error: Response.json({ error: "Faça login novamente." }, { status: 401 }) } as const;
  }
  return { supabase, userId: data.claims.sub } as const;
}
