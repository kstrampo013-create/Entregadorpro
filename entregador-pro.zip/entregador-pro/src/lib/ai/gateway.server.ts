import { createOpenAI } from "@ai-sdk/openai";
import { APICallError } from "ai";
import { createLovableAiGatewayRunIdFetch } from "./run-id";

/** Lovable AI (server only). */
export const AI_BASE_URL = "https://ai.gateway.lovable.dev";
export const CHAT_MODEL = "openai/gpt-6-astra";
export const TTS_MODEL = "google/gemini-3.1-flash-tts-preview";
/** Gemini prebuilt female voice. */
export const TTS_VOICE = "Kore";
export const STT_MODEL = "openai/gpt-transcribe";

export function aiKey(): string {
  const key = process.env["LOVABLE_API_KEY"];
  if (!key) throw new Error("LOVABLE_API_KEY is not configured");
  return key;
}

/** Request-scoped OpenAI Responses provider through Lovable AI. */
export function createGatewayProvider(initialRunId?: string) {
  const key = aiKey();
  const runIdFetch = createLovableAiGatewayRunIdFetch(initialRunId);
  const provider = createOpenAI({
    baseURL: `${AI_BASE_URL}/v1`,
    apiKey: key,
    headers: { "Lovable-API-Key": key, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: runIdFetch.fetch,
  });
  return { provider, runIdFetch };
}

export function responsesOptions(effort: "low" | "medium" = "low") {
  return {
    openai: {
      store: false,
      forceReasoning: true,
      reasoningEffort: effort,
      reasoningSummary: "auto",
      include: ["reasoning.encrypted_content"],
    },
  };
}

/** HTTP status of a failed AI call, when there is one. */
export function aiErrorStatus(error: unknown): number | undefined {
  if (APICallError.isInstance(error)) return error.statusCode;
  const cause = (error as { cause?: unknown } | null)?.cause;
  if (cause && APICallError.isInstance(cause)) return cause.statusCode;
  return undefined;
}

export function aiErrorMessage(error: unknown): string {
  const status = aiErrorStatus(error);
  if (status === 402) return "Os créditos de IA do app acabaram. O dono do app precisa adicionar créditos no Lovable.";
  if (status === 403) return "O acesso à IA foi bloqueado para este app no momento.";
  if (status === 429) return "Muitas perguntas ao mesmo tempo. Espere alguns segundos e tente de novo.";
  if (status && status >= 500) return "O serviço de IA está instável agora. Tente de novo em instantes.";
  return "Não consegui responder agora. Tente de novo.";
}
