/** Brazilian phone helpers. */

export function onlyDigits(s: string): string {
  return (s || "").replace(/\D/g, "");
}

/** Returns +55DDXXXXXXXXX or null if it does not look like a valid BR mobile/landline. */
export function toE164BR(input: string): string | null {
  let d = onlyDigits(input);
  if (d.startsWith("55") && (d.length === 12 || d.length === 13)) d = d.slice(2);
  if (d.startsWith("0")) d = d.slice(1);
  if (d.length !== 10 && d.length !== 11) return null;
  if (d.length === 11 && d[2] !== "9") return null;
  return `+55${d}`;
}

export function formatPhoneBR(input: string): string {
  const d = onlyDigits(input).replace(/^55(?=\d{10,11}$)/, "");
  if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
  if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return input;
}

export function isValidPin(pin: string): boolean {
  return /^\d{6}$/.test(pin);
}
