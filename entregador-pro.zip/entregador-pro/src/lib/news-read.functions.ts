import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Shared Nels Nere data: readable only through these signed-in server reads (no direct table access). */

export const getNewsItems = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const since = new Date(Date.now() - 7 * 24 * 3600_000).toISOString();
    const { data, error } = await supabaseAdmin
      .from("news_items")
      .select("*")
      .or(`published_at.gte.${since},and(published_at.is.null,fetched_at.gte.${since})`)
      .order("published_at", { ascending: false, nullsFirst: false })
      .limit(800);
    if (error) throw new Error("Não foi possível carregar as notícias.");
    return data;
  });

export const getSourceStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin.from("news_source_status").select("source_id, ok, last_ok_at");
    if (error) throw new Error("Não foi possível carregar as fontes.");
    return data;
  });

export const getJobState = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin.from("job_state").select("last_ingest_at").eq("name", "nels-nere").maybeSingle();
    if (error) throw new Error("Não foi possível carregar o status.");
    return data;
  });
