import { createOpenAICompatible } from "@ai-sdk/openai-compatible";
import { streamText } from "ai";
import { AI_BASE_URL, aiKey } from "@/lib/ai/gateway.server";
import { createLovableAiGatewayRunIdFetch } from "@/lib/ai/run-id";

/** Gemini model used only for Google Search grounding (Chat Completions + google_search tool). */
export const GOOGLE_SEARCH_MODEL = "google/gemini-3.8-flash";

function nowText() {
  return new Intl.DateTimeFormat("pt-BR", { timeZone: "America/Sao_Paulo", dateStyle: "full", timeStyle: "short" }).format(
    new Date(),
  );
}

/**
 * Pesquisa ao vivo na web pelo Google (Gemini com Google Search) e devolve um resumo com links.
 * Os links vêm escritos pelo modelo; o gateway não devolve os metadados de citação nativos.
 */
export async function searchGoogleWeb(pergunta: string, signal?: AbortSignal, runId?: string) {
  const key = aiKey();
  const runIdFetch = createLovableAiGatewayRunIdFetch(runId);
  const provider = createOpenAICompatible({
    name: "lovable",
    baseURL: `${AI_BASE_URL}/v1`,
    headers: { "Lovable-API-Key": key, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: (input, init) => {
      const body = JSON.parse(String(init?.body));
      body.tools = [...(body.tools ?? []), { type: "google_search" }];
      return runIdFetch.fetch(input, { ...init, body: JSON.stringify(body) });
    },
  });
  try {
    const result = streamText({
      model: provider(GOOGLE_SEARCH_MODEL),
      maxRetries: 0,
      ...(signal ? { abortSignal: signal } : {}),
      system: [
        `Agora é ${nowText()} (horário de Brasília). O usuário mora no Sul Fluminense (RJ).`,
        "Pesquise no Google e responda em português do Brasil com os fatos encontrados, de forma objetiva (até 200 palavras).",
        "Liste no final, em 'Fontes:', os sites usados com link completo em markdown [Nome do site](https://...).",
        "Se a pesquisa não trouxer a resposta, diga claramente que não encontrou. Nunca invente.",
      ].join("\n"),
      prompt: pergunta,
    });
    const text = (await result.text).trim();
    if (!text) return { erro: "A pesquisa no Google não trouxe resposta agora." };
    return {
      resultado: text,
      aviso:
        "Resumo feito a partir de uma pesquisa no Google. Os links foram escritos pela pesquisa; repasse-os como estão e não invente outros.",
    };
  } catch (e) {
    if (signal?.aborted) throw e;
    console.error("google search failed", e);
    return { erro: "Não consegui pesquisar no Google agora. Tente de novo em instantes." };
  }
}
