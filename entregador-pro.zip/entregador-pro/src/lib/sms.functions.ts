import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { toE164BR } from "@/lib/phone";

/**
 * Phone confirmation by SMS (Twilio through the Lovable connector gateway).
 * Needs: LOVABLE_API_KEY, TWILIO_API_KEY (Twilio connector) and TWILIO_FROM_NUMBER.
 * While they are missing, the functions answer `configured: false` and nothing is faked.
 */

const GATEWAY_URL = "https://connector-gateway.lovable.dev/twilio";
const CODE_TTL_MIN = 10;
const RESEND_SECONDS = 60;
const MAX_ATTEMPTS = 5;

function smsConfigured() {
  return Boolean(process.env["LOVABLE_API_KEY"] && process.env["TWILIO_API_KEY"] && process.env["TWILIO_FROM_NUMBER"]);
}

async function sha256(text: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function randomCode() {
  const n = new Uint32Array(1);
  crypto.getRandomValues(n);
  return String((n[0] ?? 0) % 1_000_000).padStart(6, "0");
}

export const getSmsStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async () => ({ configured: smsConfigured() }));

export const sendPhoneCode = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    if (!smsConfigured()) {
      return { ok: false as const, configured: false, message: "O envio de SMS ainda não foi configurado neste app." };
    }
    const { supabase, userId } = context;
    const { data: profile, error } = await supabase.from("profiles").select("phone, phone_verified").eq("id", userId).single();
    if (error || !profile) return { ok: false as const, configured: true, message: "Perfil não encontrado." };
    if (profile.phone_verified) return { ok: true as const, configured: true, alreadyVerified: true, message: "Telefone já confirmado." };
    const phone = toE164BR(profile.phone);
    if (!phone) return { ok: false as const, configured: true, message: "Telefone do perfil é inválido. Corrija no seu perfil." };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: existing } = await supabaseAdmin.from("phone_verifications").select("sent_at").eq("user_id", userId).maybeSingle();
    if (existing && Date.now() - new Date(existing.sent_at).getTime() < RESEND_SECONDS * 1000) {
      return { ok: false as const, configured: true, message: "Aguarde 1 minuto para pedir outro código." };
    }

    const code = randomCode();
    const code_hash = await sha256(`${userId}:${code}`);
    const { error: upErr } = await supabaseAdmin.from("phone_verifications").upsert({
      user_id: userId,
      phone,
      code_hash,
      attempts: 0,
      sent_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + CODE_TTL_MIN * 60_000).toISOString(),
    });
    if (upErr) {
      console.error("phone_verifications upsert failed", upErr);
      return { ok: false as const, configured: true, message: "Não foi possível gerar o código." };
    }

    const res = await fetch(`${GATEWAY_URL}/Messages.json`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env["LOVABLE_API_KEY"]}`,
        "X-Connection-Api-Key": process.env["TWILIO_API_KEY"]!,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        To: phone,
        From: process.env["TWILIO_FROM_NUMBER"]!,
        Body: `Entregador Pro: seu código de confirmação é ${code}. Ele vale por ${CODE_TTL_MIN} minutos.`,
      }),
    });
    if (!res.ok) {
      const body = await res.text();
      console.error(`Twilio send failed [${res.status}]: ${body}`);
      await supabaseAdmin.from("phone_verifications").delete().eq("user_id", userId);
      return { ok: false as const, configured: true, message: `O provedor de SMS recusou o envio (código ${res.status}).` };
    }
    return { ok: true as const, configured: true, message: "Código enviado por SMS." };
  });

export const verifyPhoneCode = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { code: string }) => z.object({ code: z.string().regex(/^\d{6}$/) }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row } = await supabaseAdmin.from("phone_verifications").select("*").eq("user_id", userId).maybeSingle();
    if (!row) return { ok: false, message: "Peça um código primeiro." };
    if (new Date(row.expires_at).getTime() < Date.now()) return { ok: false, message: "Código expirado. Peça outro." };
    if (row.attempts >= MAX_ATTEMPTS) return { ok: false, message: "Muitas tentativas. Peça um novo código." };

    const { data: profile } = await supabase.from("profiles").select("phone").eq("id", userId).single();
    if (!profile || toE164BR(profile.phone) !== row.phone) {
      return { ok: false, message: "O telefone mudou. Peça um novo código." };
    }

    const hash = await sha256(`${userId}:${data.code}`);
    if (hash !== row.code_hash) {
      await supabaseAdmin.from("phone_verifications").update({ attempts: row.attempts + 1 }).eq("user_id", userId);
      return { ok: false, message: "Código incorreto." };
    }

    const { error } = await supabaseAdmin
      .from("profiles")
      .update({ phone_verified: true, phone_verified_at: new Date().toISOString() })
      .eq("id", userId);
    if (error) {
      console.error("profile verify update failed", error);
      return { ok: false, message: "Não foi possível confirmar agora." };
    }
    await supabaseAdmin.from("phone_verifications").delete().eq("user_id", userId);
    return { ok: true, message: "Telefone confirmado!" };
  });
