import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert, TablesUpdate } from "@/integrations/supabase/types";

export type TableName =
  | "earnings"
  | "expenses"
  | "sales"
  | "loans"
  | "installments"
  | "installment_payments"
  | "workplaces"
  | "bills"
  | "bill_payments"
  | "entry_shortcuts"
  | "tasks"
  | "goals"
  | "goal_contributions";

export type Earning = Tables<"earnings">;
export type Expense = Tables<"expenses">;
export type Sale = Tables<"sales">;
export type Loan = Tables<"loans">;
export type Installment = Tables<"installments">;
export type InstallmentPayment = Tables<"installment_payments">;
export type Workplace = Tables<"workplaces">;
export type Bill = Tables<"bills">;
export type BillPayment = Tables<"bill_payments">;
export type Profile = Tables<"profiles">;
export type EntryShortcut = Tables<"entry_shortcuts">;
export type Task = Tables<"tasks">;
export type Goal = Tables<"goals">;
export type GoalContribution = Tables<"goal_contributions">;

export type Row<T extends TableName> = Tables<T>;
export type Insert<T extends TableName> = TablesInsert<T>;
export type Update<T extends TableName> = TablesUpdate<T>;

const ORDER: Record<TableName, string> = {
  earnings: "date",
  expenses: "date",
  sales: "sale_date",
  loans: "loan_date",
  installments: "due_date",
  installment_payments: "paid_on",
  workplaces: "created_at",
  bills: "created_at",
  bill_payments: "paid_on",
  entry_shortcuts: "created_at",
  tasks: "due_date",
  goals: "created_at",
  goal_contributions: "date",
};

/** Reads every row the signed-in user can see (RLS), paging past the 1000-row API limit. */
export async function fetchAll<T extends TableName>(table: T): Promise<Row<T>[]> {
  const out: Row<T>[] = [];
  const page = 1000;
  for (let from = 0; ; from += page) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data, error } = await (supabase.from(table) as any)
      .select("*")
      .order(ORDER[table], { ascending: false })
      .order("id", { ascending: true })
      .range(from, from + page - 1);
    if (error) throw error;
    out.push(...((data ?? []) as Row<T>[]));
    if (!data || data.length < page) break;
  }
  return out;
}

/** Postgres unique violation: the same record (same client-generated id) was already saved. */
export function isDuplicate(error: unknown): boolean {
  return !!error && typeof error === "object" && "code" in error && (error as { code?: string }).code === "23505";
}

export function errorMessage(error: unknown): string {
  if (!error) return "Erro desconhecido";
  if (typeof error === "string") return error;
  if (typeof error === "object" && "message" in error) {
    const msg = String((error as { message: unknown }).message);
    if (msg.includes("Failed to fetch")) return "Sem conexão com a internet. Tente novamente.";
    if (msg.includes("violates check constraint")) return "Algum valor informado é inválido.";
    return msg;
  }
  return "Erro inesperado";
}

export function newId(): string {
  return crypto.randomUUID();
}
