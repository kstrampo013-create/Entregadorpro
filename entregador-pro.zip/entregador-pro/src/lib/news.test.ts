import { describe, expect, it } from "vitest";
import {
  bulletinWindow,
  cleanSummary,
  detectCities,
  detectTopics,
  isAlert,
  isBulletinDue,
  isNoiseTitle,
  isWithinWindow,
  NEWS_SOURCES,
  normalizeUrl,
  pickBulletinItems,
  stripSourceSuffix,
  titleKey,
  zonedToUtc,
} from "./news";

describe("fontes", () => {
  it("acompanha as 10 fontes pedidas", () => {
    expect(NEWS_SOURCES).toHaveLength(10);
    expect(NEWS_SOURCES.map((s) => s.name)).toContain("Diário do Vale");
    expect(NEWS_SOURCES.map((s) => s.name)).toContain("Guia Sul Fluminense");
  });
});

describe("cidades", () => {
  it("reconhece Barra do Piraí sem contar Piraí de novo", () => {
    expect(detectCities("Acidente na RJ-145 em Barra do Piraí")).toEqual(["Barra do Piraí"]);
  });
  it("ignora acentos e maiúsculas", () => {
    expect(detectCities("VOLTA REDONDA e barra mansa")).toEqual(["Volta Redonda", "Barra Mansa"]);
  });
});

describe("assuntos e alertas", () => {
  it("classifica por radical de palavra", () => {
    expect(detectTopics("PM apreende drogas em Barra Mansa")).toContain("seguranca");
  });
  it("marca interdição como alerta", () => {
    expect(isAlert("Pista da Dutra é interditada após acidente")).toBe(true);
    expect(isAlert("Festival de música no fim de semana")).toBe(false);
  });
});

describe("duplicadas", () => {
  it("mesmo título com sufixo do Google gera a mesma chave", () => {
    const a = titleKey(stripSourceSuffix("Prefeitura abre vagas - Diário do Vale", "Diário do Vale"));
    const b = titleKey("Prefeitura abre vagas");
    expect(a).toBe(b);
  });
  it("remove parâmetros de rastreamento do link", () => {
    expect(normalizeUrl("https://a.com/noticia/?utm_source=x#topo")).toBe("https://a.com/noticia");
  });
  it("descarta despachos do diário oficial", () => {
    expect(isNoiseTitle("SEI/VOLTAREDONDA - 02398342 - Despacho")).toBe(true);
  });
  it("limpa o resumo do feed", () => {
    expect(cleanSummary("<p>Texto &amp; mais.</p> The post X appeared first on Y.")).toBe("Texto & mais.");
  });
});

describe("boletins", () => {
  it("06h em São Paulo = 09h UTC", () => {
    expect(zonedToUtc("2026-10-28", "06:00").toISOString()).toBe("2026-10-28T09:00:00.000Z");
  });
  it("boletim da manhã cobre as 12 horas anteriores", () => {
    const w = bulletinWindow("manha", "2026-10-28", "06:00");
    expect(w.start.toISOString()).toBe("2026-10-27T21:00:00.000Z");
    expect(w.end.toISOString()).toBe("2026-10-28T09:00:00.000Z");
  });
  it("boletim da tarde cobre da meia-noite até as 16h", () => {
    const w = bulletinWindow("tarde", "2026-10-28", "16:00");
    expect(w.start.toISOString()).toBe("2026-10-28T03:00:00.000Z");
    expect(w.end.toISOString()).toBe("2026-10-28T19:00:00.000Z");
  });
  it("fica pendente só até 3 horas depois do horário", () => {
    expect(isBulletinDue(new Date("2026-10-28T09:05:00Z"), "06:00", true)).toBe(true);
    expect(isBulletinDue(new Date("2026-10-28T08:55:00Z"), "06:00", true)).toBe(false);
    expect(isBulletinDue(new Date("2026-10-28T12:01:00Z"), "06:00", true)).toBe(false);
    expect(isBulletinDue(new Date("2026-10-28T09:05:00Z"), "06:00", false)).toBe(false);
  });
  it("janela de notificações atravessa a meia-noite", () => {
    expect(isWithinWindow(new Date("2026-10-28T02:00:00Z"), "22:00", "06:00")).toBe(true); // 23h SP
    expect(isWithinWindow(new Date("2026-10-28T15:00:00Z"), "22:00", "06:00")).toBe(false); // 12h SP
  });
  it("filtra pelas cidades escolhidas", () => {
    const base = { published_at: null, fetched_at: "2026-10-28T10:00:00Z", topics: [], origin: "rss", is_alert: false };
    const items = [
      { ...base, id: "a", cities: ["Volta Redonda"] },
      { ...base, id: "b", cities: ["Resende"] },
      { ...base, id: "c", cities: [] },
    ];
    expect(pickBulletinItems(items, { cities: ["Resende"], topics: [] }).map((i) => i.id)).toEqual(["b"]);
    expect(pickBulletinItems(items, { cities: [], topics: [] }).map((i) => i.id).sort()).toEqual(["a", "b"]);
  });
});
