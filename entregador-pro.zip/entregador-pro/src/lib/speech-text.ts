/** Text prepared for Thassi's voice (no markdown, no links) and split into ordered chunks. */

export function toSpeakable(markdown: string): string {
  return markdown
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/!\[[^\]]*\]\([^)]*\)/g, " ")
    .replace(/\[([^\]]+)\]\((?:[^)]+)\)/g, "$1")
    .replace(/https?:\/\/\S+/g, " ")
    .replace(/^#{1,6}\s*/gm, "")
    .replace(/^\s*[-*•]\s+/gm, "")
    .replace(/[*_`>#|]/g, "")
    .replace(/\n{2,}/g, "\n")
    .replace(/[ \t]+/g, " ")
    .trim();
}

export function chunkForSpeech(text: string, max = 900): string[] {
  const chunks: string[] = [];
  let current = "";
  for (const sentence of text.match(/[^.!?\n]+[.!?]*\s*|\n+/g) ?? []) {
    if ((current + sentence).length <= max) {
      current += sentence;
      continue;
    }
    if (current.trim()) chunks.push(current.trim());
    current = "";
    for (let i = 0; i < sentence.length; i += max) {
      const part = sentence.slice(i, i + max);
      if (i + max < sentence.length) chunks.push(part.trim());
      else current = part;
    }
  }
  if (current.trim()) chunks.push(current.trim());
  return chunks.filter(Boolean);
}
