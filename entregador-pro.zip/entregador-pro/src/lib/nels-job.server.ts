import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { BulletinAiError, bulletinTelegramHtml, createBulletin } from "@/lib/bulletins.server";
import { ingestAll } from "@/lib/news-ingest.server";
import { isBulletinDue, isWithinWindow, localDate, type BulletinSlot } from "@/lib/news";
import { escapeHtml, sendTelegramMessage, telegramConfigured } from "@/lib/telegram.server";

type Admin = SupabaseClient<Database>;
type JobRow = Database["public"]["Tables"]["job_state"]["Row"];

export const JOB_NAME = "nels-nere";
export const APP_URL = "https://rider-earnings-compass.lovable.app";
const INGEST_EVERY_MS = 14 * 60_000;
/** Stop starting new AI work after this long (the run itself ends ~30 s after the trigger). */
const AI_BUDGET_MS = 20_000;
const MAX_BULLETINS_PER_RUN = 3;
const MAX_ALERTS_PER_RUN = 25;
const MAX_ALERTS_PER_USER = 3;

async function admin(): Promise<Admin> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

async function acquireLock(db: Admin): Promise<JobRow | null> {
  const now = new Date();
  const { data, error } = await db
    .from("job_state")
    .update({ locked_until: new Date(now.getTime() + 4 * 60_000).toISOString(), last_run_at: now.toISOString() })
    .eq("name", JOB_NAME)
    .or(`locked_until.is.null,locked_until.lt.${now.toISOString()}`)
    .select("*")
    .maybeSingle();
  if (error) throw new Error(`lock: ${error.message}`);
  return data;
}

export async function ingestIfStale(db: Admin, job: Pick<JobRow, "last_ingest_at">, force = false) {
  if (!force && job.last_ingest_at && Date.now() - new Date(job.last_ingest_at).getTime() < INGEST_EVERY_MS) return null;
  const r = await ingestAll(db);
  await db.from("job_state").update({ last_ingest_at: new Date().toISOString() }).eq("name", JOB_NAME);
  return r;
}

/** Sends (once) a bulletin to the owner's Telegram, recording the outcome on the bulletin. */
export async function deliverBulletinToTelegram(db: Admin, bulletin: Database["public"]["Tables"]["bulletins"]["Row"]) {
  if (!telegramConfigured()) return "skipped";
  const [{ data: link }, { data: prefs }] = await Promise.all([
    db.from("telegram_links").select("chat_id").eq("user_id", bulletin.user_id).maybeSingle(),
    db.from("news_preferences").select("tg_bulletins").eq("user_id", bulletin.user_id).maybeSingle(),
  ]);
  let status: string;
  if (!link || !(prefs?.tg_bulletins ?? true)) status = "skipped";
  else {
    try {
      await sendTelegramMessage(link.chat_id, bulletinTelegramHtml(bulletin, APP_URL, escapeHtml));
      status = "sent";
    } catch (e) {
      status = `erro: ${(e instanceof Error ? e.message : String(e)).slice(0, 150)}`;
    }
  }
  await db.from("bulletins").update({ telegram_status: status }).eq("id", bulletin.id);
  return status;
}

async function runDueBulletins(db: Admin, job: JobRow, startedAt: number) {
  const now = new Date();
  const date = localDate(now);
  const { data: prefs, error } = await db
    .from("news_preferences")
    .select("user_id, cities, topics, morning_enabled, morning_time, afternoon_enabled, afternoon_time")
    .or("morning_enabled.eq.true,afternoon_enabled.eq.true");
  if (error) throw new Error(`prefs: ${error.message}`);
  const due: { prefs: (typeof prefs)[number]; slot: BulletinSlot; time: string }[] = [];
  for (const p of prefs ?? []) {
    if (isBulletinDue(now, p.morning_time, p.morning_enabled)) due.push({ prefs: p, slot: "manha", time: p.morning_time });
    if (isBulletinDue(now, p.afternoon_time, p.afternoon_enabled)) due.push({ prefs: p, slot: "tarde", time: p.afternoon_time });
  }
  if (due.length === 0) return { due: 0, created: 0 };
  const { data: done } = await db
    .from("bulletins")
    .select("user_id, slot")
    .eq("bulletin_date", date)
    .in("user_id", [...new Set(due.map((d) => d.prefs.user_id))]);
  const doneKeys = new Set((done ?? []).map((b) => `${b.user_id}:${b.slot}`));
  const pending = due.filter((d) => !doneKeys.has(`${d.prefs.user_id}:${d.slot}`));

  // Paused for credits/policy: only one probe bulletin per run until one succeeds.
  const limit = job.paused_at ? 1 : MAX_BULLETINS_PER_RUN;
  let created = 0;
  let failures = 0;
  for (const d of pending.slice(0, limit)) {
    if (Date.now() - startedAt > AI_BUDGET_MS) break;
    try {
      const { bulletin } = await createBulletin(db, d.prefs, d.slot, date, d.time, now);
      created++;
      if (job.paused_at) {
        await db.from("job_state").update({ paused_at: null, paused_reason: null }).eq("name", JOB_NAME);
        job.paused_at = null;
      }
      await deliverBulletinToTelegram(db, bulletin);
    } catch (e) {
      const status = e instanceof BulletinAiError ? e.status : undefined;
      console.error(`bulletin ${d.prefs.user_id}/${d.slot} failed [${status ?? "-"}]:`, e);
      if (status === 402 || status === 403) {
        await db
          .from("job_state")
          .update({
            paused_at: new Date().toISOString(),
            paused_reason: status === 402 ? "Créditos de IA esgotados" : "Acesso à IA bloqueado",
          })
          .eq("name", JOB_NAME);
        break;
      }
      if (status === 429 || ++failures >= 2) break;
    }
  }
  return { due: pending.length, created };
}

/** Bulletins whose Telegram delivery has not been attempted yet (e.g. created by "Gerar agora"). */
async function deliverPendingBulletins(db: Admin) {
  if (!telegramConfigured()) return 0;
  const { data } = await db
    .from("bulletins")
    .select("*")
    .is("telegram_status", null)
    .neq("slot", "avulso")
    .gte("created_at", new Date(Date.now() - 3 * 3600_000).toISOString())
    .limit(10);
  for (const b of data ?? []) await deliverBulletinToTelegram(db, b);
  return data?.length ?? 0;
}

async function sendAlerts(db: Admin) {
  if (!telegramConfigured()) return { sent: 0 };
  const { data: links } = await db.from("telegram_links").select("user_id, chat_id");
  if (!links?.length) return { sent: 0 };
  const { data: prefs } = await db
    .from("news_preferences")
    .select("user_id, cities, tg_alerts, tg_topics, tg_from, tg_until")
    .in(
      "user_id",
      links.map((l) => l.user_id),
    );
  const now = new Date();
  const active = (prefs ?? []).filter((p) => (p.tg_alerts || p.tg_topics.length > 0) && isWithinWindow(now, p.tg_from, p.tg_until));
  if (!active.length) return { sent: 0 };
  const sinceFetch = new Date(now.getTime() - 60 * 60_000).toISOString();
  const sincePub = new Date(now.getTime() - 6 * 3600_000).toISOString();
  const { data: news } = await db
    .from("news_items")
    .select("id, title, url, source_name, cities, topics, is_alert, published_at")
    .gte("fetched_at", sinceFetch)
    .or(`published_at.is.null,published_at.gte.${sincePub}`)
    .order("fetched_at", { ascending: false })
    .limit(150);
  if (!news?.length) return { sent: 0 };
  let sent = 0;
  for (const p of active) {
    if (sent >= MAX_ALERTS_PER_RUN) break;
    const chat = links.find((l) => l.user_id === p.user_id)!.chat_id;
    const matches = news.filter((n) => {
      const cityOk = p.cities.length ? n.cities.some((c) => p.cities.includes(c)) : n.cities.length > 0;
      return cityOk && ((p.tg_alerts && n.is_alert) || n.topics.some((t) => p.tg_topics.includes(t)));
    });
    if (!matches.length) continue;
    const { data: logged } = await db
      .from("notification_log")
      .select("news_id")
      .eq("user_id", p.user_id)
      .in(
        "news_id",
        matches.map((m) => m.id),
      );
    const already = new Set((logged ?? []).map((l) => l.news_id));
    let perUser = 0;
    for (const n of matches) {
      if (already.has(n.id) || perUser >= MAX_ALERTS_PER_USER || sent >= MAX_ALERTS_PER_RUN) continue;
      // claim first so a story is never sent twice, even if two runs overlap
      const { error } = await db.from("notification_log").insert({ user_id: p.user_id, news_id: n.id, kind: n.is_alert ? "alerta" : "assunto" });
      if (error) continue;
      try {
        await sendTelegramMessage(
          chat,
          `${n.is_alert ? "⚠️ <b>Alerta</b>" : "📰 <b>Notícia</b>"} · ${escapeHtml(n.cities.join(", "))}\n<b>${escapeHtml(n.title)}</b>\n<a href="${escapeHtml(n.url)}">${escapeHtml(n.source_name)}</a>`,
        );
        sent++;
        perUser++;
      } catch (e) {
        console.error("alert send failed", e);
      }
    }
  }
  return { sent };
}

/** One scheduler tick: refresh news (every ~15 min), due bulletins, Telegram delivery and alerts. */
export async function runNelsTick() {
  // News and bulletins are now only created when the user taps "Gerar notícias" / "Gerar agora".
  return { skipped: "geração automática desligada" };
}

/** Old automatic tick, kept for reference; not called. */
export async function runNelsTickAutomatic() {
  const db = await admin();
  const startedAt = Date.now();
  const job = await acquireLock(db);
  if (!job) return { skipped: "outra execução em andamento" };
  const report: Record<string, unknown> = {};
  try {
    report["ingest"] = await ingestIfStale(db, job);
    report["bulletins"] = await runDueBulletins(db, job, startedAt);
    report["telegram_pending"] = await deliverPendingBulletins(db);
    report["alerts"] = await sendAlerts(db);
    await db.from("job_state").update({ last_error: null }).eq("name", JOB_NAME);
  } catch (e) {
    console.error("nels tick failed", e);
    await db
      .from("job_state")
      .update({ last_error: (e instanceof Error ? e.message : String(e)).slice(0, 300) })
      .eq("name", JOB_NAME);
    report["error"] = e instanceof Error ? e.message : String(e);
  } finally {
    await db.from("job_state").update({ locked_until: null }).eq("name", JOB_NAME);
  }
  return report;
}
