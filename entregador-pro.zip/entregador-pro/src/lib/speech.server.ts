import { createParser } from "eventsource-parser";
import { AI_BASE_URL, aiKey, TTS_MODEL, TTS_VOICE } from "@/lib/ai/gateway.server";

/** Spoken style for Thassi (Gemini TTS takes steering text before the content). */
export function thassiSpeechPrompt(text: string) {
  return `Leia em português do Brasil, com voz feminina natural de apresentadora de telejornal, tom claro, calmo e objetivo: ${text}`;
}

export function speechBody(text: string, stream: boolean) {
  return {
    model: TTS_MODEL,
    contents: [{ role: "user", parts: [{ text: thassiSpeechPrompt(text) }] }],
    generationConfig: {
      responseModalities: ["AUDIO"],
      speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: TTS_VOICE } } },
    },
    stream_format: stream ? "sse" : "audio",
  };
}

/** Streaming speech (SSE with 24 kHz PCM deltas) for live playback. */
export function requestSpeechStream(text: string, signal?: AbortSignal) {
  return fetch(`${AI_BASE_URL}/v1/audio/speech`, {
    method: "POST",
    headers: { Authorization: `Bearer ${aiKey()}`, "Content-Type": "application/json" },
    body: JSON.stringify(speechBody(text, true)),
    ...(signal ? { signal } : {}),
  });
}

export class SpeechError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}

/** Synthesizes one chunk and returns its raw PCM (signed 16-bit LE, mono, 24 kHz). */
export async function synthesizePcm(text: string): Promise<Uint8Array> {
  const res = await requestSpeechStream(text);
  if (!res.ok || !res.body) {
    throw new SpeechError(`Falha na voz [${res.status}]: ${(await res.text()).slice(0, 300)}`, res.status);
  }
  const parts: Uint8Array[] = [];
  let done = false;
  let failure: string | null = null;
  const parser = createParser({
    onEvent(event) {
      let payload: { type?: string; audio?: string; error?: unknown };
      try {
        payload = JSON.parse(event.data);
      } catch {
        return;
      }
      if (payload.type === "error" || payload.error) failure = event.data.slice(0, 300);
      else if (payload.type === "speech.audio.done") done = true;
      else if (payload.type === "speech.audio.delta" && payload.audio) {
        const bin = atob(payload.audio);
        const bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        parts.push(bytes);
      }
    },
  });
  const reader = res.body.pipeThrough(new TextDecoderStream()).getReader();
  for (;;) {
    const next = await reader.read();
    if (next.done) break;
    parser.feed(next.value);
  }
  if (failure) throw new SpeechError(`Falha na voz: ${failure}`, 502);
  if (!done || parts.length === 0) throw new SpeechError("A voz não terminou de ser gerada.", 502);
  const total = parts.reduce((s, p) => s + p.length, 0);
  const out = new Uint8Array(total);
  let o = 0;
  for (const p of parts) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}

/** Wraps PCM chunks into one WAV file. */
export function pcmToWav(chunks: Uint8Array[], sampleRate = 24000): Uint8Array {
  const dataLen = chunks.reduce((s, c) => s + c.length - (c.length % 2), 0);
  const buf = new Uint8Array(44 + dataLen);
  const view = new DataView(buf.buffer);
  const tag = (off: number, s: string) => {
    for (let i = 0; i < s.length; i++) view.setUint8(off + i, s.charCodeAt(i));
  };
  tag(0, "RIFF");
  view.setUint32(4, 36 + dataLen, true);
  tag(8, "WAVE");
  tag(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  tag(36, "data");
  view.setUint32(40, dataLen, true);
  let off = 44;
  for (const c of chunks) {
    const even = c.length - (c.length % 2);
    buf.set(c.subarray(0, even), off);
    off += even;
  }
  return buf;
}
