import { fetchAll, type TableName } from "@/lib/db";
import { supabase } from "@/integrations/supabase/client";

function download(filename: string, blob: Blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function csvCell(v: unknown): string {
  if (v == null) return "";
  const s = typeof v === "number" ? String(v).replace(".", ",") : String(v);
  return /[";\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/** CSV with ";" separator and BOM so Excel/Sheets in pt-BR open it correctly. */
export function downloadCSV(filename: string, header: string[], rows: unknown[][]) {
  const body = [header, ...rows].map((r) => r.map(csvCell).join(";")).join("\r\n");
  download(filename, new Blob(["\ufeff" + body], { type: "text/csv;charset=utf-8" }));
}

export interface PdfSection {
  title: string;
  head: string[];
  body: (string | number)[][];
}

export async function downloadPDF(filename: string, title: string, subtitle: string, summary: [string, string][], sections: PdfSection[]) {
  const [{ jsPDF }, { default: autoTable }] = await Promise.all([import("jspdf"), import("jspdf-autotable")]);
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const green: [number, number, number] = [21, 94, 71];
  doc.setFillColor(...green);
  doc.rect(0, 0, 595, 70, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(18);
  doc.text(title, 40, 38);
  doc.setFontSize(10);
  doc.text(subtitle, 40, 56);
  doc.setTextColor(30, 30, 30);
  autoTable(doc, {
    startY: 90,
    head: [["Indicador", "Valor"]],
    body: summary,
    theme: "grid",
    headStyles: { fillColor: green },
    columnStyles: { 1: { halign: "right", fontStyle: "bold" } },
  });
  for (const s of sections) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const y = ((doc as any).lastAutoTable?.finalY ?? 90) + 24;
    doc.setFontSize(12);
    doc.text(s.title, 40, y);
    autoTable(doc, { startY: y + 8, head: [s.head], body: s.body.length ? s.body : [["Sem registros"]], theme: "striped", headStyles: { fillColor: green }, styles: { fontSize: 8 } });
  }
  doc.setFontSize(8);
  doc.setTextColor(120);
  doc.text(`Gerado em ${new Date().toLocaleString("pt-BR")} · Entregador Pro`, 40, 820);
  doc.save(filename);
}

const BACKUP_TABLES: TableName[] = ["earnings", "expenses", "workplaces", "sales", "loans", "installments", "installment_payments", "bills", "bill_payments", "entry_shortcuts", "tasks", "goals", "goal_contributions"];

/** Full JSON backup of everything the signed-in user owns. */
export async function downloadBackup() {
  const { data: u } = await supabase.auth.getUser();
  const { data: profile } = await supabase.from("profiles").select("full_name, phone, email").eq("id", u.user!.id).maybeSingle();
  const tables: Record<string, unknown[]> = {};
  for (const t of BACKUP_TABLES) tables[t] = await fetchAll(t);
  const payload = { app: "Entregador Pro", version: 1, exported_at: new Date().toISOString(), profile, tables };
  download(`entregador-pro-backup-${new Date().toISOString().slice(0, 10)}.json`, new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }));
}
