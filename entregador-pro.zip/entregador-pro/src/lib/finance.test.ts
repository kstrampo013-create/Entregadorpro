import { describe, expect, it } from "vitest";
import {
  billDueDate,
  billOccurrences,
  billStatus,
  buildInstallments,
  dailyResults,
  financedAmount,
  goalDailyValues,
  goalDayTarget,
  goalEndDate,
  goalProgress,
  isGoalWorkDay,
  toggleGoalDay,
  installmentStatus,
  loanTotal,
  perKm,
  periodRange,
  previousPeriod,
  summarizeContract,
} from "./finance";
import { parseMoney } from "./format";
import { isValidPin, toE164BR } from "./phone";

describe("buildInstallments", () => {
  it("splits 100 into 3 parcels that add up exactly to 100", () => {
    const p = buildInstallments(100, 3, "2026-01-10");
    expect(p.map((x) => x.amount)).toEqual([33.33, 33.33, 33.34]);
    expect(p.reduce((s, x) => s + Math.round(x.amount * 100), 0)).toBe(10000);
  });

  it("generates monthly due dates clamped to the end of the month", () => {
    const p = buildInstallments(300, 3, "2026-01-31");
    expect(p.map((x) => x.due_date)).toEqual(["2026-01-31", "2026-02-28", "2026-03-31"]);
  });

  it("numbers parcels from 1", () => {
    expect(buildInstallments(50, 2, "2026-05-05").map((x) => x.number)).toEqual([1, 2]);
  });

  it("rejects zero parcels", () => {
    expect(() => buildInstallments(100, 0, "2026-01-01")).toThrow();
  });
});

describe("sales and loans", () => {
  it("financed amount discounts the down payment", () => {
    expect(financedAmount(1200, 200)).toBe(1000);
  });

  it("applies no interest when no rate was informed", () => {
    expect(loanTotal(500, null)).toBe(500);
    expect(loanTotal(500, undefined)).toBe(500);
  });

  it("applies the informed interest rate over the principal", () => {
    expect(loanTotal(1000, 10)).toBe(1100);
  });
});

describe("installmentStatus", () => {
  const today = "2026-10-20";
  it("is paid when fully paid", () => {
    expect(installmentStatus({ amount: 50, paid_amount: 50, due_date: "2026-09-01" }, today)).toBe("pago");
  });
  it("is overdue when due before today with balance", () => {
    expect(installmentStatus({ amount: 50, paid_amount: 10, due_date: "2026-10-19" }, today)).toBe("atrasado");
  });
  it("is partial when partially paid and not due yet", () => {
    expect(installmentStatus({ amount: 50, paid_amount: 10, due_date: "2026-10-25" }, today)).toBe("parcial");
  });
  it("is pending when due today with nothing paid", () => {
    expect(installmentStatus({ amount: 50, paid_amount: 0, due_date: today }, today)).toBe("pendente");
  });
});

describe("wallet summary", () => {
  it("computes received and remaining from installments only", () => {
    const s = summarizeContract(
      [
        { amount: 100, paid_amount: 100, due_date: "2026-09-10" },
        { amount: 100, paid_amount: 40, due_date: "2026-10-10" },
        { amount: 100, paid_amount: 0, due_date: "2026-11-10" },
      ],
      "2026-10-20",
    );
    expect(s.original).toBe(300);
    expect(s.received).toBe(140);
    expect(s.remaining).toBe(160);
    expect(s.pendingCount).toBe(2);
    expect(s.nextDue).toBe("2026-10-10");
    expect(s.status).toBe("atrasado");
  });

  it("marks a fully paid contract as settled", () => {
    const s = summarizeContract([{ amount: 80, paid_amount: 80, due_date: "2026-01-01" }], "2026-10-20");
    expect(s.status).toBe("quitado");
    expect(s.remaining).toBe(0);
  });
});

describe("periods", () => {
  it("weeks start on Monday", () => {
    expect(periodRange("semana", "2026-10-22")).toEqual({ start: "2026-10-19", end: "2026-10-25" });
  });
  it("month range covers the whole month", () => {
    expect(periodRange("mes", "2026-02-10")).toEqual({ start: "2026-02-01", end: "2026-02-28" });
  });
  it("previous month of March is February", () => {
    expect(previousPeriod("mes", "2026-03-15")).toEqual({ start: "2026-02-01", end: "2026-02-28" });
  });
});

describe("per km", () => {
  it("divides earnings by km", () => {
    expect(perKm(250, 100)).toBe(2.5);
  });
  it("returns null without km", () => {
    expect(perKm(250, 0)).toBeNull();
  });
});

describe("recurring bills", () => {
  const bill = { id: "b", due_day: 31, interval_months: 1, start_month: "2026-01-01", end_month: null, active: true };
  it("clamps due day to month length", () => {
    expect(billDueDate(31, "2026-02-01")).toBe("2026-02-28");
  });
  it("generates one occurrence per month in range", () => {
    const occ = billOccurrences(bill, { start: "2026-01-01", end: "2026-03-31" });
    expect(occ.map((o) => o.due_date)).toEqual(["2026-01-31", "2026-02-28", "2026-03-31"]);
  });
  it("respects quarterly interval", () => {
    const occ = billOccurrences({ ...bill, due_day: 10, interval_months: 3 }, { start: "2026-01-01", end: "2026-12-31" });
    expect(occ.map((o) => o.reference_month)).toEqual(["2026-01-01", "2026-04-01", "2026-07-01", "2026-10-01"]);
  });
  it("is overdue after the due date when unpaid", () => {
    expect(billStatus("2026-10-10", false, "2026-10-20")).toBe("atrasado");
    expect(billStatus("2026-10-10", true, "2026-10-20")).toBe("pago");
  });
});

describe("input parsing", () => {
  it("parses Brazilian money", () => {
    expect(parseMoney("1.234,56")).toBe(1234.56);
    expect(parseMoney("12,5")).toBe(12.5);
    expect(parseMoney("R$ 30")).toBe(30);
  });
  it("normalizes BR phones to E.164", () => {
    expect(toE164BR("(11) 98765-4321")).toBe("+5511987654321");
    expect(toE164BR("123")).toBeNull();
  });
  it("PIN must be exactly 6 digits", () => {
    expect(isValidPin("123456")).toBe(true);
    expect(isValidPin("12345")).toBe(false);
    expect(isValidPin("12a456")).toBe(false);
  });
});

describe("dailyResults (ganho real do dia)", () => {
  const range = { start: "2026-11-01", end: "2026-11-30" };
  it("subtracts the day's expenses from the day's earnings", () => {
    const r = dailyResults(
      [{ date: "2026-11-02", amount: 150 }, { date: "2026-11-02", amount: 80.5 }],
      [{ date: "2026-11-02", amount: 40.2 }],
      range,
      "2026-11-02",
    );
    expect(r.get("2026-11-02")).toEqual({ earned: 230.5, spent: 40.2, net: 190.3 });
  });
  it("shows a negative result on a day with only expenses", () => {
    const r = dailyResults([], [{ date: "2026-11-01", amount: 60 }], range, "2026-11-02");
    expect(r.get("2026-11-01")?.net).toBe(-60);
  });
  it("does not count future (planned) expenses", () => {
    const r = dailyResults([{ date: "2026-11-05", amount: 100 }], [{ date: "2026-11-05", amount: 30 }], range, "2026-11-02");
    expect(r.get("2026-11-05")).toEqual({ earned: 100, spent: 0, net: 100 });
  });
  it("ignores entries outside the month shown", () => {
    const r = dailyResults([{ date: "2026-10-31", amount: 100 }], [], range, "2026-11-02");
    expect(r.size).toBe(0);
  });
});

describe("metas (goals)", () => {
  // Novembro/2026: dia 1 é domingo. Segunda a sábado = 25 dias de trabalho.
  const monthly = {
    kind: "mensal",
    target_amount: 5000,
    start_date: "2026-11-01",
    end_date: null,
    work_weekdays: [1, 2, 3, 4, 5, 6],
    extra_days: [] as string[],
    off_days: [] as string[],
  };
  const today = "2026-11-03";
  const data = {
    earnings: [
      { date: "2026-11-02", amount: 300 },
      { date: "2026-11-03", amount: 100 },
    ],
    expenses: [
      { date: "2026-11-02", amount: 50 },
      { date: "2026-11-20", amount: 999 }, // futura: ainda não gasta
    ],
    contributions: [] as { date: string; amount: number }[],
  };

  it("computes the end date from days, months or years", () => {
    expect(goalEndDate("2026-11-03", 10, "dias")).toBe("2026-11-12");
    expect(goalEndDate("2026-11-01", 3, "meses")).toBe("2027-01-31");
    expect(goalEndDate("2026-11-01", 2, "anos")).toBe("2028-10-31");
  });

  it("monthly goal: what is still missing is split over the work days left, counting today", () => {
    const v = goalDailyValues("lucro", data, today);
    const p = goalProgress(monthly, v, today);
    expect(p.workDays).toBe(25);
    expect(p.workDaysLeft).toBe(24);
    expect(p.perDay).toBe(197.92); // (5000 − 250) / 24
    expect(p.achieved).toBe(350);
    expect(p.remaining).toBe(4650);
    expect(p.todayMissing).toBe(97.92); // já fez 100 hoje
    expect(p.status).toBe("em_andamento");
  });

  it("unmarking a work day raises the daily target", () => {
    const g = { ...monthly, ...toggleGoalDay(monthly, "2026-11-04") };
    expect(isGoalWorkDay(g, "2026-11-04")).toBe(false);
    expect(goalProgress(g, goalDailyValues("lucro", data, today), today).perDay).toBe(206.53); // 4750 / 23
  });

  it("toggling a day twice restores it", () => {
    const once = { ...monthly, ...toggleGoalDay(monthly, "2026-11-08") }; // domingo vira dia de trabalho
    expect(isGoalWorkDay(once, "2026-11-08")).toBe(true);
    const twice = { ...once, ...toggleGoalDay(once, "2026-11-08") };
    expect(isGoalWorkDay(twice, "2026-11-08")).toBe(false);
    expect(twice.extra_days).toEqual([]);
    expect(twice.off_days).toEqual([]);
  });

  it("monthly goal restarts in the next month", () => {
    const v = goalDailyValues("lucro", data, today);
    expect(goalDayTarget(monthly, v, "2026-12-01", today)).toBe(185.19); // 5000 / 27 dias de dezembro
    expect(goalDayTarget(monthly, v, "2026-11-08", today)).toBeNull(); // domingo
    expect(goalDayTarget(monthly, v, "2026-11-02", today)).toBeNull(); // dia que já passou
  });

  it("only counts what the goal is based on", () => {
    expect(goalDailyValues("lucro", data, today).get("2026-11-02")).toBe(250);
    expect(goalDailyValues("lucro", data, today).has("2026-11-20")).toBe(false);
    expect(goalDailyValues("ganhos", data, today).get("2026-11-02")).toBe(300);
    expect(goalDailyValues("guardado", { ...data, contributions: [{ date: "2026-11-02", amount: 80 }] }, today).get("2026-11-02")).toBe(80);
  });

  it("goal with a deadline shows how much per month is still needed", () => {
    const house = { ...monthly, kind: "objetivo", target_amount: 12000, end_date: "2027-10-31" };
    const v = goalDailyValues("guardado", { ...data, contributions: [{ date: "2026-11-02", amount: 1000 }] }, today);
    const p = goalProgress(house, v, today);
    expect(p.monthsLeft).toBe(12);
    expect(p.perMonth).toBe(916.67); // 11000 / 12
    expect(p.remaining).toBe(11000);
  });

  it("a reached goal needs nothing more", () => {
    const v = goalDailyValues("ganhos", { ...data, earnings: [{ date: "2026-11-02", amount: 6000 }] }, today);
    const p = goalProgress(monthly, v, today);
    expect(p.status).toBe("concluida");
    expect(p.perDay).toBeNull();
    expect(goalDayTarget(monthly, v, "2026-11-05", today)).toBeNull();
  });
});
