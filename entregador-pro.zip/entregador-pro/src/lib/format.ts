import { format, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";

const brl = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });
const num = new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 1 });

export function money(value: number | string | null | undefined): string {
  return brl.format(Number(value ?? 0) || 0);
}

export function km(value: number | null | undefined): string {
  return `${num.format(Number(value ?? 0))} km`;
}

export function number(value: number | null | undefined, digits = 1): string {
  return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: digits }).format(Number(value ?? 0));
}

/** "2026-10-20" -> "20/10/2026" */
export function dateBR(iso: string | null | undefined): string {
  if (!iso) return "—";
  return format(parseISO(iso.slice(0, 10)), "dd/MM/yyyy");
}

export function dateLong(iso: string): string {
  return format(parseISO(iso.slice(0, 10)), "EEEE, d 'de' MMMM", { locale: ptBR });
}

export function monthLabel(iso: string): string {
  return format(parseISO(iso.slice(0, 10)), "MMMM 'de' yyyy", { locale: ptBR });
}

/** Local "today" in yyyy-MM-dd (never UTC, to avoid off-by-one at night). */
export function todayISO(): string {
  return format(new Date(), "yyyy-MM-dd");
}

export function toISO(d: Date): string {
  return format(d, "yyyy-MM-dd");
}

/** Accepts "12,50", "1.234,56", "12.5" and returns a number rounded to cents, or NaN. */
export function parseMoney(input: string | number): number {
  if (typeof input === "number") return Math.round(input * 100) / 100;
  const s = input.trim().replace(/\s|R\$/g, "");
  if (!s) return NaN;
  let normalized = s;
  if (s.includes(",")) normalized = s.replace(/\./g, "").replace(",", ".");
  const n = Number(normalized);
  return Number.isFinite(n) ? Math.round(n * 100) / 100 : NaN;
}

export function parseDecimal(input: string): number | null {
  const s = input.trim();
  if (!s) return null;
  const n = Number(s.replace(/\./g, "").replace(",", "."));
  return Number.isFinite(n) ? n : NaN;
}
