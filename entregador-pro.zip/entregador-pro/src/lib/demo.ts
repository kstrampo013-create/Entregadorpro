import { addDays, format, subDays, subMonths } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { buildInstallments, financedAmount } from "@/lib/finance";

/**
 * Demo data is marked with is_demo = true on every row so it never mixes with real data
 * and can be removed in one action.
 */
const f = (d: Date) => format(d, "yyyy-MM-dd");

export async function loadDemoData() {
  const now = new Date();
  const wpId = crypto.randomUUID();
  const { error: wpErr } = await supabase.from("workplaces").insert({ id: wpId, name: "Shopping Centro (demo)", address: "Praça de alimentação, piso 2", app_used: "iFood", is_demo: true });
  if (wpErr) throw wpErr;

  const sources = ["iFood", "99Food", "Uber", "Particular"];
  const earnings = Array.from({ length: 24 }, (_, i) => {
    const d = subDays(now, i);
    return {
      source: sources[i % sources.length]!,
      amount: 80 + ((i * 37) % 120),
      date: f(d),
      hours: 6 + (i % 4),
      km: 60 + ((i * 13) % 80),
      workplace_id: i % 3 === 0 ? wpId : null,
      is_demo: true,
    };
  });
  const { error: eErr } = await supabase.from("earnings").insert(earnings);
  if (eErr) throw eErr;

  const cats = ["Combustível", "Alimentação", "Manutenção", "Internet e telefone", "Estacionamento"];
  const expenses = Array.from({ length: 12 }, (_, i) => ({
    description: `${cats[i % cats.length]} (demo)`,
    category: cats[i % cats.length]!,
    amount: 15 + ((i * 23) % 60),
    date: f(subDays(now, i * 2)),
    is_demo: true,
  }));
  expenses.push({ description: "Troca de óleo (demo)", category: "Manutenção", amount: 90, date: f(addDays(now, 5)), is_demo: true });
  const { error: xErr } = await supabase.from("expenses").insert(expenses);
  if (xErr) throw xErr;

  const saleFirst = f(subMonths(now, 1));
  const { error: sErr } = await supabase.rpc("create_sale_with_installments", {
    p_sale: {
      customer_name: "Maria (demo)",
      description: "Capacete novo",
      total: 600,
      down_payment: 100,
      installments_count: 5,
      sale_date: f(subMonths(now, 1)),
      first_due_date: saleFirst,
      is_demo: true,
    },
    p_installments: buildInstallments(financedAmount(600, 100), 5, saleFirst) as never,
  });
  if (sErr) throw sErr;

  const loanFirst = f(addDays(now, 3));
  const { error: lErr } = await supabase.rpc("create_loan_with_installments", {
    p_loan: {
      person_name: "João (demo)",
      principal: 300,
      interest_rate: "",
      total_due: 300,
      installments_count: 3,
      loan_date: f(now),
      first_due_date: loanFirst,
      is_demo: true,
    },
    p_installments: buildInstallments(300, 3, loanFirst) as never,
  });
  if (lErr) throw lErr;

  const { error: bErr } = await supabase.from("bills").insert([
    { name: "Aluguel (demo)", expected_amount: 700, due_day: 10, category: "Aluguel", start_month: f(subMonths(now, 2)).slice(0, 8) + "01", is_demo: true },
    { name: "Plano de celular (demo)", expected_amount: 59.9, due_day: 25, category: "Telefone", start_month: f(subMonths(now, 2)).slice(0, 8) + "01", is_demo: true },
  ]);
  if (bErr) throw bErr;

  // Mark the first sale installment as paid (overdue ones stay open to show alerts).
  const { data: inst } = await supabase.from("installments").select("id, amount").eq("is_demo", true).not("sale_id", "is", null).eq("number", 1).maybeSingle();
  if (inst) await supabase.from("installment_payments").insert({ installment_id: inst.id, amount: inst.amount, paid_on: saleFirst, is_demo: true });
}

export async function clearDemoData() {
  // Children first; sales/loans cascade their installments and payments.
  for (const t of ["installment_payments", "bill_payments", "earnings", "expenses", "sales", "loans", "bills", "workplaces"] as const) {
    const { error } = await supabase.from(t).delete().eq("is_demo", true);
    if (error) throw error;
  }
}
