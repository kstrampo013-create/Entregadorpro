import { XMLParser } from "fast-xml-parser";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import {
  cleanSummary,
  decodeEntities,
  detectCities,
  detectTopics,
  GOOGLE_REGION_QUERIES,
  isAlert,
  isNoiseTitle,
  NEWS_SOURCES,
  normalizeUrl,
  stripSourceSuffix,
  titleKey,
} from "@/lib/news";

type Admin = SupabaseClient<Database>;

export type FeedEntry = {
  title: string;
  link: string;
  description: string | null;
  pubDate: string | null;
  sourceName: string | null;
  sourceUrl: string | null;
};

const UA = "Mozilla/5.0 (compatible; EntregadorPro-NelsNere/1.0; +https://rider-earnings-compass.lovable.app)";
const MAX_AGE_MS = 7 * 24 * 3600_000;

export function googleNewsUrl(query: string): string {
  return `https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=pt-BR&gl=BR&ceid=BR:pt-419`;
}

function text(v: unknown): string | null {
  if (v == null) return null;
  if (typeof v === "string" || typeof v === "number") return String(v);
  if (typeof v === "object" && "#text" in (v as Record<string, unknown>)) return String((v as Record<string, unknown>)["#text"]);
  return null;
}

export function parseFeed(xml: string): FeedEntry[] {
  const parser = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: "@_", textNodeName: "#text", processEntities: false });
  const doc = parser.parse(xml) as Record<string, unknown>;
  const channel = (doc["rss"] as Record<string, unknown> | undefined)?.["channel"] as Record<string, unknown> | undefined;
  const raw = channel?.["item"];
  const items = Array.isArray(raw) ? raw : raw ? [raw] : [];
  return items
    .map((it: Record<string, unknown>) => {
      const source = it["source"] as Record<string, unknown> | string | undefined;
      return {
        title: decodeEntities(text(it["title"]) ?? "").trim(),
        link: (text(it["link"]) ?? "").trim(),
        description: text(it["description"]),
        pubDate: text(it["pubDate"]),
        sourceName: source ? decodeEntities(text(source) ?? "").trim() || null : null,
        sourceUrl: source && typeof source === "object" ? ((source["@_url"] as string | undefined) ?? null) : null,
      };
    })
    .filter((e) => e.title && /^https?:\/\//.test(e.link));
}

export async function fetchFeed(url: string): Promise<FeedEntry[]> {
  const res = await fetch(url, {
    headers: { "User-Agent": UA, Accept: "application/rss+xml, application/xml, text/xml, */*" },
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const body = await res.text();
  if (!body.includes("<rss")) throw new Error("Resposta não é um feed RSS");
  return parseFeed(body);
}

function hostOf(url: string | null): string | null {
  if (!url) return null;
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}

export type NewsRow = {
  url: string;
  title: string;
  title_key: string;
  summary: string | null;
  source_id: string;
  source_name: string;
  origin: "rss" | "google";
  published_at: string | null;
  cities: string[];
  topics: string[];
  is_alert: boolean;
};

export function toRow(
  e: FeedEntry,
  origin: "rss" | "google",
  fixedSource?: { id: string; name: string },
  now = Date.now(),
): NewsRow | null {
  const published = e.pubDate ? new Date(e.pubDate) : null;
  const publishedOk = published && !Number.isNaN(published.getTime()) ? published : null;
  if (publishedOk && now - publishedOk.getTime() > MAX_AGE_MS) return null;
  let sourceId = fixedSource?.id;
  let sourceName = fixedSource?.name;
  if (!fixedSource) {
    const host = hostOf(e.sourceUrl);
    const known = host ? NEWS_SOURCES.find((s) => host === s.domain || host.endsWith(`.${s.domain}`)) : undefined;
    sourceId = known?.id ?? `google:${host ?? "desconhecida"}`;
    sourceName = known?.name ?? e.sourceName ?? host ?? "Google Notícias";
  }
  const title = origin === "google" ? stripSourceSuffix(e.title, e.sourceName) : e.title;
  if (isNoiseTitle(title)) return null;
  // Google descriptions only repeat the title as a link, so they are not used as summary.
  const summary = origin === "rss" ? cleanSummary(e.description) : null;
  const haystack = `${title} ${summary ?? ""}`;
  return {
    url: normalizeUrl(e.link),
    title,
    title_key: titleKey(title),
    summary,
    source_id: sourceId!,
    source_name: sourceName!,
    origin,
    published_at: publishedOk ? publishedOk.toISOString() : null,
    cities: detectCities(haystack),
    topics: detectTopics(haystack),
    is_alert: isAlert(title),
  };
}

type Job = { statusId: string; url: string; origin: "rss" | "google"; source?: { id: string; name: string }; requireCity: boolean };

function buildJobs(): Job[] {
  const jobs: Job[] = [];
  for (const s of NEWS_SOURCES) {
    if (s.rss) jobs.push({ statusId: s.id, url: s.rss, origin: "rss", source: { id: s.id, name: s.name }, requireCity: false });
    else
      jobs.push({
        statusId: s.id,
        url: googleNewsUrl(`site:${s.domain} when:3d`),
        origin: "google",
        source: { id: s.id, name: s.name },
        requireCity: false,
      });
  }
  GOOGLE_REGION_QUERIES.forEach((q, i) =>
    jobs.push({ statusId: `google-regiao-${i + 1}`, url: googleNewsUrl(`${q} when:1d`), origin: "google", requireCity: true }),
  );
  return jobs;
}

/** Reads every source, stores new stories (duplicates skipped by link and title) and records per-source status. */
export async function ingestAll(admin: Admin) {
  const jobs = buildJobs();
  const startedAt = new Date().toISOString();
  const results = await Promise.allSettled(jobs.map((j) => fetchFeed(j.url)));
  const rssRows: NewsRow[] = [];
  const googleRows: NewsRow[] = [];
  const statuses: Database["public"]["Tables"]["news_source_status"]["Insert"][] = [];
  results.forEach((r, i) => {
    const job = jobs[i]!;
    if (r.status === "fulfilled") {
      let rows = r.value.map((e) => toRow(e, job.origin, job.source)).filter((x): x is NewsRow => !!x);
      if (job.requireCity) rows = rows.filter((x) => x.cities.length > 0);
      (job.origin === "rss" ? rssRows : googleRows).push(...rows);
      statuses.push({ source_id: job.statusId, ok: true, last_count: rows.length, last_error: null, last_run_at: startedAt, last_ok_at: startedAt });
    } else {
      const reason = r.reason instanceof Error ? r.reason.message : String(r.reason);
      console.error(`news source ${job.statusId} failed: ${reason}`);
      statuses.push({ source_id: job.statusId, ok: false, last_count: 0, last_error: reason.slice(0, 200), last_run_at: startedAt });
    }
  });
  // Direct feeds first so the outlet's own link wins over the Google copy of the same story.
  const all = [...rssRows, ...googleRows];
  let inserted = 0;
  for (let i = 0; i < all.length; i += 200) {
    const { data, error } = await admin.rpc("ingest_news", { p_items: all.slice(i, i + 200) as never });
    if (error) throw new Error(`ingest_news: ${error.message}`);
    inserted += data ?? 0;
  }
  const { error: stErr } = await admin.from("news_source_status").upsert(statuses, { onConflict: "source_id" });
  if (stErr) console.error("news_source_status upsert failed", stErr.message);
  return { inserted, read: all.length, failed: statuses.filter((s) => !s.ok).map((s) => s.source_id) };
}
