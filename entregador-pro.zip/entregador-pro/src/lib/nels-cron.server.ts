import { authenticateCronRequest } from "@/integrations/supabase/cron-auth";
import { runNelsTick } from "@/lib/nels-job.server";

/**
 * Scheduler entry point. The scheduler hangs up after a few seconds, so when the
 * runtime offers `waitUntil` the tick keeps running after an immediate 202.
 */
export async function handleNelsTickRequest(request: Request, waitUntil?: (p: Promise<unknown>) => void) {
  const authFailure = await authenticateCronRequest(request);
  if (authFailure) return authFailure;
  if (waitUntil) {
    waitUntil(runNelsTick().catch((e) => console.error("nels tick crashed", e)));
    return Response.json({ accepted: true }, { status: 202 });
  }
  return Response.json(await runNelsTick());
}
