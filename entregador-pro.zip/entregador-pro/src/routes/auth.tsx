import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { z } from "zod";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Field, SegmentedControl, TextInput } from "@/components/common";
import { Logo } from "@/components/logo";
import { setKeepSignedIn, useAuth } from "@/hooks/use-auth";
import { formatPhoneBR, isValidPin, toE164BR } from "@/lib/phone";

const searchSchema = z.object({
  redirect: z.string().optional(),
  modo: z.enum(["entrar", "cadastro", "recuperar"]).optional(),
});

export const Route = createFileRoute("/auth")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Entrar ou criar conta — Entregador Pro" },
      { name: "description", content: "Acesse sua conta do Entregador Pro com e-mail e PIN, ou crie uma conta nova." },
      { property: "og:title", content: "Entrar — Entregador Pro" },
      { property: "og:description", content: "Acesse seu controle financeiro de entregador." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function safeRedirect(r?: string) {
  if (!r) return "/painel";
  try {
    const u = new URL(r, window.location.origin);
    if (u.origin !== window.location.origin) return "/painel";
    return u.pathname + u.search;
  } catch {
    return "/painel";
  }
}

function friendlyAuthError(msg: string): string {
  if (/invalid login credentials/i.test(msg)) return "E-mail ou PIN incorretos.";
  if (/already registered|already been registered/i.test(msg)) return "Este e-mail já tem conta. Use “Entrar”.";
  if (/rate limit|too many/i.test(msg)) return "Muitas tentativas. Aguarde alguns minutos.";
  if (/weak|pwned|leaked/i.test(msg)) return "PIN muito fácil. Escolha outra combinação.";
  return msg;
}

function AuthPage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const { user, ready } = useAuth();
  const [mode, setMode] = useState<"entrar" | "cadastro" | "recuperar">(search.modo ?? "entrar");

  useEffect(() => {
    if (ready && user) navigate({ to: safeRedirect(search.redirect), replace: true });
  }, [ready, user, navigate, search.redirect]);

  return (
    <div className="grid min-h-dvh lg:grid-cols-2">
      <div className="hidden flex-col justify-between bg-hero p-10 text-primary-foreground lg:flex">
        <Link to="/" className="flex items-center gap-3">
          <Logo className="size-11" />
          <span className="font-display text-xl font-bold">Entregador Pro</span>
        </Link>
        <div>
          <h2 className="text-4xl font-extrabold leading-tight">Cada real no lugar certo.</h2>
          <p className="mt-3 max-w-md opacity-85">Ganhos, despesas, parcelas e contas sincronizados com segurança em todos os seus aparelhos.</p>
        </div>
        <p className="text-xs opacity-70">Seus dados ficam protegidos e só você tem acesso.</p>
      </div>

      <div className="flex items-start justify-center px-5 py-8 sm:items-center">
        <div className="w-full max-w-md">
          <Link to="/" className="mb-8 flex items-center gap-2.5 lg:hidden">
            <Logo className="size-9" />
            <span className="font-display text-lg font-bold">Entregador Pro</span>
          </Link>
          {mode !== "recuperar" && (
            <div className="mb-6">
              <SegmentedControl
                value={mode}
                onChange={setMode}
                options={[
                  { value: "entrar", label: "Entrar" },
                  { value: "cadastro", label: "Criar conta" },
                ]}
              />
            </div>
          )}
          {mode === "entrar" && <LoginForm onForgot={() => setMode("recuperar")} redirect={search.redirect} />}
          {mode === "cadastro" && <SignupForm />}
          {mode === "recuperar" && <ForgotForm onBack={() => setMode("entrar")} />}
        </div>
      </div>
    </div>
  );
}

function PinInput({ value, onChange, id, autoComplete }: { value: string; onChange: (v: string) => void; id: string; autoComplete: string }) {
  return (
    <TextInput
      id={id}
      type="password"
      inputMode="numeric"
      autoComplete={autoComplete}
      maxLength={6}
      placeholder="••••••"
      className="tracking-[0.5em]"
      value={value}
      onChange={(e) => onChange(e.target.value.replace(/\D/g, "").slice(0, 6))}
    />
  );
}

function LoginForm({ onForgot, redirect }: { onForgot: () => void; redirect?: string | undefined }) {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [pin, setPin] = useState("");
  const [keep, setKeep] = useState(true);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!z.string().email().safeParse(email.trim()).success) return setError("Informe um e-mail válido.");
    if (!isValidPin(pin)) return setError("O PIN tem 6 números.");
    setPending(true);
    setKeepSignedIn(keep);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim().toLowerCase(), password: pin });
    setPending(false);
    if (error) return setError(friendlyAuthError(error.message));
    navigate({ to: safeRedirect(redirect), replace: true });
  }

  return (
    <form onSubmit={submit} className="flex flex-col gap-4">
      <div>
        <h1 className="text-2xl font-bold">Bem-vindo de volta</h1>
        <p className="text-sm text-muted-foreground">Entre com seu e-mail e PIN de 6 números.</p>
      </div>
      <Field label="E-mail">
        <TextInput type="email" autoComplete="email" inputMode="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="voce@email.com" />
      </Field>
      <Field label="PIN">
        <PinInput id="pin" value={pin} onChange={setPin} autoComplete="current-password" />
      </Field>
      <label className="flex min-h-10 items-center gap-3 text-sm">
        <Checkbox checked={keep} onCheckedChange={(v) => setKeep(v === true)} className="size-5" />
        Manter conectado neste aparelho
      </label>
      {error && <p className="rounded-lg bg-destructive/10 px-3 py-2 text-sm font-medium text-destructive">{error}</p>}
      <Button type="submit" size="lg" disabled={pending}>
        {pending && <Loader2 className="animate-spin" />}
        Entrar
      </Button>
      <Button type="button" variant="link" onClick={onForgot}>
        Esqueci meu PIN
      </Button>
    </form>
  );
}

const signupSchema = z
  .object({
    full_name: z.string().trim().min(3, "Informe seu nome completo").max(120),
    phone: z.string().refine((v) => toE164BR(v) !== null, "Telefone inválido. Use DDD + número"),
    email: z.string().trim().email("E-mail inválido").max(160),
    pin: z.string().refine(isValidPin, "O PIN deve ter exatamente 6 números"),
    pin2: z.string(),
  })
  .refine((v) => v.pin === v.pin2, { path: ["pin2"], message: "Os PINs não conferem" })
  .refine((v) => !/^(\d)\1{5}$/.test(v.pin) && !["123456", "654321", "012345"].includes(v.pin), {
    path: ["pin"],
    message: "Evite PINs fáceis como 111111 ou 123456",
  });

function SignupForm() {
  const navigate = useNavigate();
  const [v, setV] = useState({ full_name: "", phone: "", email: "", pin: "", pin2: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState(false);
  const set = (k: keyof typeof v) => (val: string) => setV((s) => ({ ...s, [k]: val }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = signupSchema.safeParse(v);
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      parsed.error.issues.forEach((i) => (errs[String(i.path[0])] = i.message));
      return setErrors(errs);
    }
    setErrors({});
    setPending(true);
    setKeepSignedIn(true);
    const { data, error } = await supabase.auth.signUp({
      email: parsed.data.email.toLowerCase(),
      password: parsed.data.pin,
      options: {
        emailRedirectTo: window.location.origin,
        data: { full_name: parsed.data.full_name, phone: toE164BR(parsed.data.phone) },
      },
    });
    setPending(false);
    if (error) return setErrors({ form: friendlyAuthError(error.message) });
    if (!data.session) {
      toast.success("Conta criada! Confira seu e-mail para ativar.");
      return;
    }
    toast.success("Conta criada! Agora confirme seu telefone.");
    navigate({ to: "/verificar-telefone", replace: true });
  }

  return (
    <form onSubmit={submit} className="flex flex-col gap-4">
      <div>
        <h1 className="text-2xl font-bold">Criar conta</h1>
        <p className="text-sm text-muted-foreground">Leva menos de um minuto.</p>
      </div>
      <Field label="Nome completo" error={errors["full_name"]}>
        <TextInput autoComplete="name" value={v.full_name} onChange={(e) => set("full_name")(e.target.value)} />
      </Field>
      <Field label="Telefone (WhatsApp)" error={errors["phone"]} hint="Vamos confirmar por SMS">
        <TextInput
          type="tel"
          inputMode="tel"
          autoComplete="tel"
          placeholder="(11) 98765-4321"
          value={v.phone}
          onChange={(e) => set("phone")(e.target.value)}
          onBlur={() => set("phone")(formatPhoneBR(v.phone))}
        />
      </Field>
      <Field label="E-mail" error={errors["email"]}>
        <TextInput type="email" inputMode="email" autoComplete="email" value={v.email} onChange={(e) => set("email")(e.target.value)} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="PIN (6 números)" error={errors["pin"]}>
          <PinInput id="pin" value={v.pin} onChange={set("pin")} autoComplete="new-password" />
        </Field>
        <Field label="Repita o PIN" error={errors["pin2"]}>
          <PinInput id="pin2" value={v.pin2} onChange={set("pin2")} autoComplete="new-password" />
        </Field>
      </div>
      {errors["form"] && <p className="rounded-lg bg-destructive/10 px-3 py-2 text-sm font-medium text-destructive">{errors["form"]}</p>}
      <Button type="submit" size="lg" disabled={pending}>
        {pending && <Loader2 className="animate-spin" />}
        Criar conta
      </Button>
    </form>
  );
}

function ForgotForm({ onBack }: { onBack: () => void }) {
  const [email, setEmail] = useState("");
  const [pending, setPending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!z.string().email().safeParse(email.trim()).success) return setError("Informe um e-mail válido.");
    setPending(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim().toLowerCase(), {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setPending(false);
    if (error) return setError(friendlyAuthError(error.message));
    setSent(true);
  }

  return (
    <form onSubmit={submit} className="flex flex-col gap-4">
      <div>
        <h1 className="text-2xl font-bold">Recuperar acesso</h1>
        <p className="text-sm text-muted-foreground">Enviaremos um link para você criar um PIN novo.</p>
      </div>
      {sent ? (
        <p className="rounded-xl bg-secondary p-4 text-sm text-secondary-foreground">
          Se existir uma conta com esse e-mail, o link chegará em alguns minutos. Confira também a caixa de spam.
        </p>
      ) : (
        <>
          <Field label="E-mail" error={error ?? undefined}>
            <TextInput type="email" inputMode="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Button type="submit" size="lg" disabled={pending}>
            {pending && <Loader2 className="animate-spin" />}
            Enviar link
          </Button>
        </>
      )}
      <Button type="button" variant="ghost" onClick={onBack}>
        Voltar para entrar
      </Button>
    </form>
  );
}
