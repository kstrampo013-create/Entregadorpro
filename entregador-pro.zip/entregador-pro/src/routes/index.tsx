import { createFileRoute, Link } from "@tanstack/react-router";
import { CalendarDays, HandCoins, ShieldCheck, Smartphone, TrendingUp, Wallet } from "lucide-react";
import heroImg from "@/assets/hero-entregador.jpg";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/logo";
import { useAuth } from "@/hooks/use-auth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Entregador Pro — controle financeiro para entregadores" },
      {
        name: "description",
        content: "Registre ganhos, despesas, vendas parceladas, empréstimos e contas. Saiba seu lucro real por dia, semana e mês.",
      },
      { property: "og:title", content: "Entregador Pro — controle financeiro para entregadores" },
      { property: "og:description", content: "Ganhos, despesas, carteira de recebíveis e contas num só lugar, no celular." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

const FEATURES = [
  { icon: TrendingUp, title: "Lucro real", text: "Ganhos menos despesas, por dia, semana e mês, com ganho por km." },
  { icon: Wallet, title: "Carteira", text: "Tudo o que você tem a receber de vendas e empréstimos, sem contar duas vezes." },
  { icon: HandCoins, title: "Parcelas automáticas", text: "Cronograma gerado na hora, com pagamentos parciais e histórico." },
  { icon: CalendarDays, title: "Calendário", text: "Vencimentos, contas do mês e pagamentos com cores de situação." },
  { icon: Smartphone, title: "Instale no celular", text: "Funciona no navegador e pode ser adicionado à tela inicial." },
  { icon: ShieldCheck, title: "Seus dados protegidos", text: "Cada pessoa só enxerga os próprios dados, sincronizados entre aparelhos." },
];

function Landing() {
  const { user, ready } = useAuth();
  return (
    <div className="min-h-dvh bg-background">
      <section className="relative overflow-hidden bg-hero text-primary-foreground">
        <img
          src={heroImg}
          alt="Entregador de moto em avenida ao entardecer"
          width={1600}
          height={1008}
          className="absolute inset-0 h-full w-full object-cover opacity-35 mix-blend-luminosity"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-primary/80 via-primary/30 to-transparent" />
        <div className="relative mx-auto flex min-h-[86dvh] max-w-6xl flex-col px-5 pb-12 pt-6">
          <header className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Logo className="size-10" />
              <span className="font-display text-lg font-bold">Entregador Pro</span>
            </div>
            {ready && !user && (
              <Button variant="hero-outline" asChild>
                <Link to="/auth">Entrar</Link>
              </Button>
            )}
          </header>
          <div className="mt-auto max-w-2xl">
            <p className="mb-4 inline-flex rounded-full bg-highlight px-3 py-1 text-xs font-bold uppercase tracking-wider text-highlight-foreground">
              Feito para quem roda o dia inteiro
            </p>
            <h1 className="text-4xl font-extrabold leading-[1.05] md:text-6xl">
              Saiba quanto sobra no fim de cada corrida.
            </h1>
            <p className="mt-4 max-w-xl text-base opacity-90 md:text-lg">
              Ganhos de todos os apps, despesas da moto, vendas parceladas, empréstimos e contas do mês — num painel simples, no seu celular.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              {ready && user ? (
                <Button variant="highlight" size="xl" asChild>
                  <Link to="/painel">Abrir meu painel</Link>
                </Button>
              ) : (
                <>
                  <Button variant="highlight" size="xl" asChild>
                    <Link to="/auth" search={{ modo: "cadastro" }}>
                      Criar minha conta
                    </Link>
                  </Button>
                  <Button variant="hero-outline" size="xl" asChild>
                    <Link to="/auth">Já tenho conta</Link>
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-14">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div key={f.title} className="rounded-2xl border bg-card p-5 shadow-soft">
              <div className="mb-3 grid size-11 place-items-center rounded-xl bg-secondary text-secondary-foreground">
                <f.icon className="size-5" />
              </div>
              <h3 className="font-semibold">{f.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t py-8 text-center text-xs text-muted-foreground">
        Entregador Pro · Organização financeira para entregadores
      </footer>
    </div>
  );
}
