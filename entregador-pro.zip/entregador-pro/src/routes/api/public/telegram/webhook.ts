import { createFileRoute } from "@tanstack/react-router";

type TgMessage = {
  chat?: { id: number; type?: string };
  from?: { first_name?: string; username?: string };
  text?: string;
};

const HELP =
  "Olá! Eu sou a Thassi, do <b>Nels Nere</b> (Entregador Pro).\n\n" +
  "Para receber boletins e alertas aqui, abra o app em <b>Notícias → Ajustes</b> e toque em <b>Conectar Telegram</b>.\n\n" +
  "Comandos:\n/boletim — último boletim\n/parar — desconectar este chat";

export const Route = createFileRoute("/api/public/telegram/webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { webhookSecret, sendTelegramMessage, escapeHtml } = await import("@/lib/telegram.server");
        if (!process.env["TELEGRAM_API_KEY"]) return new Response("Not configured", { status: 503 });
        const expected = await webhookSecret();
        const actual = request.headers.get("X-Telegram-Bot-Api-Secret-Token") ?? "";
        const { timingSafeEqual } = await import("node:crypto");
        const a = Buffer.from(actual);
        const b = Buffer.from(expected);
        if (a.length !== b.length || !timingSafeEqual(a, b)) return new Response("Unauthorized", { status: 401 });

        const update = (await request.json().catch(() => null)) as { message?: TgMessage } | null;
        const msg = update?.message;
        const chatId = msg?.chat?.id;
        if (!msg || !chatId || msg.chat?.type !== "private") return Response.json({ ok: true, ignored: true });

        const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
        const text = (msg.text ?? "").trim();
        const reply = (html: string) => sendTelegramMessage(chatId, html).catch((e) => console.error("tg reply failed", e));

        const start = /^\/start(?:@\w+)?\s+([A-Z0-9]{6,12})$/i.exec(text);
        if (start) {
          const code = start[1]!.toUpperCase();
          const { data: row } = await db
            .from("telegram_link_codes")
            .select("user_id, expires_at")
            .eq("code", code)
            .maybeSingle();
          if (!row || new Date(row.expires_at).getTime() < Date.now()) {
            await reply("Esse código expirou ou não existe. Gere um novo no app em <b>Notícias → Ajustes</b>.");
            return Response.json({ ok: true });
          }
          // one chat ↔ one account
          await db.from("telegram_links").delete().eq("chat_id", chatId);
          const { error } = await db.from("telegram_links").upsert(
            { user_id: row.user_id, chat_id: chatId, tg_name: msg.from?.first_name ?? null, tg_username: msg.from?.username ?? null, linked_at: new Date().toISOString() },
            { onConflict: "user_id" },
          );
          await db.from("telegram_link_codes").delete().eq("code", code);
          if (error) {
            console.error("telegram link failed", error.message);
            await reply("Não consegui conectar agora. Tente gerar um novo código no app.");
          } else {
            await reply(
              `✅ Pronto${msg.from?.first_name ? `, ${escapeHtml(msg.from.first_name)}` : ""}! Este chat está conectado ao seu Entregador Pro.\nVocê vai receber aqui os boletins e alertas que escolheu no app.`,
            );
          }
          return Response.json({ ok: true });
        }

        const { data: link } = await db.from("telegram_links").select("user_id").eq("chat_id", chatId).maybeSingle();

        if (/^\/parar/i.test(text)) {
          if (link) await db.from("telegram_links").delete().eq("chat_id", chatId);
          await reply(link ? "Chat desconectado. Você não vai mais receber mensagens aqui." : "Este chat não estava conectado.");
          return Response.json({ ok: true });
        }

        if (/^\/boletim/i.test(text) && link) {
          const { data: last } = await db
            .from("bulletins")
            .select("*")
            .eq("user_id", link.user_id)
            .order("created_at", { ascending: false })
            .limit(1)
            .maybeSingle();
          if (!last) await reply("Ainda não há boletins. O primeiro sai no próximo horário que você escolheu.");
          else {
            const { bulletinTelegramHtml } = await import("@/lib/bulletins.server");
            const { APP_URL } = await import("@/lib/nels-job.server");
            await reply(bulletinTelegramHtml(last, APP_URL, escapeHtml));
          }
          return Response.json({ ok: true });
        }

        await reply(link ? "Para conversar com a Thassi, use o app. Aqui envio seus boletins e alertas.\n\n/boletim — último boletim\n/parar — desconectar" : HELP);
        return Response.json({ ok: true });
      },
    },
  },
});
