import { createFileRoute } from "@tanstack/react-router";

// Normally answered earlier in src/server.ts (which can keep the work alive after replying);
// this route is the same handler without that, e.g. in local development.
export const Route = createFileRoute("/api/public/jobs/nels-nere")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { handleNelsTickRequest } = await import("@/lib/nels-cron.server");
        return handleNelsTickRequest(request);
      },
    },
  },
});
