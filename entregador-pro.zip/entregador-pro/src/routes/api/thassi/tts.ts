import { createFileRoute } from "@tanstack/react-router";

/** Thassi's voice for a chat answer: streams Gemini SSE (24 kHz PCM) to the browser. */
export const Route = createFileRoute("/api/thassi/tts")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { authenticateRequest } = await import("@/lib/request-auth.server");
        const auth = await authenticateRequest(request);
        if ("error" in auth) return auth.error;
        const body = (await request.json().catch(() => null)) as { text?: unknown } | null;
        const text = typeof body?.text === "string" ? body.text.trim() : "";
        if (!text) return Response.json({ error: "Nada para ler." }, { status: 400 });
        if (text.length > 1500) return Response.json({ error: "Trecho longo demais." }, { status: 400 });
        const { requestSpeechStream } = await import("@/lib/speech.server");
        try {
          const upstream = await requestSpeechStream(text, request.signal);
          if (!upstream.ok) {
            const detail = await upstream.text();
            console.error(`tts failed [${upstream.status}]: ${detail}`);
            const msg =
              upstream.status === 402
                ? "Os créditos de IA do app acabaram."
                : upstream.status === 429
                  ? "Muitos pedidos de voz agora. Tente em alguns segundos."
                  : "Não consegui gerar a voz agora.";
            return Response.json({ error: msg }, { status: upstream.status });
          }
          return new Response(upstream.body, {
            status: 200,
            headers: { "Content-Type": "text/event-stream", "Cache-Control": "no-cache" },
          });
        } catch (e) {
          if (request.signal.aborted) return new Response(null, { status: 499 });
          throw e;
        }
      },
    },
  },
});
