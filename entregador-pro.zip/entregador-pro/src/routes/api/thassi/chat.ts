import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, isStepCount, safeValidateUIMessages, streamText, tool, type UIMessage } from "ai";
import { z } from "zod";

const TOPIC_IDS = ["seguranca", "transito", "politica", "economia", "saude", "educacao", "esportes", "cultura", "clima", "servicos"] as const;

function nowText() {
  return new Intl.DateTimeFormat("pt-BR", { timeZone: "America/Sao_Paulo", dateStyle: "full", timeStyle: "short" }).format(new Date());
}
function todayIso() {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo" }).format(new Date());
}

function instructions() {
  return [
    "Você é a Thassi, assistente de notícias do Nels Nere, módulo do app Entregador Pro, focada no Sul Fluminense (RJ): Volta Redonda, Barra Mansa, Resende, Barra do Piraí, Pinheiral, Porto Real, Itatiaia, Quatis, Piraí, Angra dos Reis e região.",
    `Agora é ${nowText()} (horário de Brasília). Hoje = ${todayIso()}.`,
    "Fale em português do Brasil, de forma simpática, direta e curta, como quem conversa com um entregador na rua. Parágrafos curtos, sem tabelas.",
    "Para qualquer pergunta sobre notícias, fatos, acontecimentos, trânsito, segurança ou serviços, SEMPRE use as ferramentas antes de responder: primeiro buscar_noticias (base já coletada das fontes regionais); se vier pouco ou nada, use buscar_no_google. Para qualquer outra pergunta (geral, clima, preços, lugares, esportes, explicações, o que for), use pesquisar_google e responda com base no resultado, citando os links.",
    "Suas respostas também são lidas em voz alta: comece com a resposta direta numa frase curta.",
    "Diga somente o que estiver nos resultados das ferramentas. Nunca invente fatos, números, nomes ou datas. Se não encontrar, diga claramente que não encontrou nas fontes e sugira onde procurar. Se algo não puder ser confirmado, diga 'não consegui confirmar'.",
    "Cite a fonte de cada notícia pelo nome do veículo e com link em markdown, por exemplo: [Diário do Vale](https://...). Informe a data de publicação quando houver.",
    "Para datas relativas (ontem, esta semana), calcule a partir de hoje e passe 'desde'/'ate' no formato AAAA-MM-DD.",
    "Você não dá conselhos médicos, jurídicos ou financeiros; para emergências oriente a ligar 190 (polícia), 192 (SAMU) ou 193 (bombeiros).",
  ].join("\n");
}

export const Route = createFileRoute("/api/thassi/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { authenticateRequest } = await import("@/lib/request-auth.server");
        const auth = await authenticateRequest(request);
        if ("error" in auth) return auth.error;
        const { supabase, userId } = auth;

        const body = (await request.json().catch(() => null)) as { threadId?: unknown; messages?: unknown } | null;
        const threadId = typeof body?.threadId === "string" ? body.threadId : "";
        if (!/^[0-9a-f-]{36}$/i.test(threadId)) return Response.json({ error: "Conversa inválida." }, { status: 400 });
        const validated = await safeValidateUIMessages<UIMessage>({ messages: body?.messages });
        if (!validated.success) return Response.json({ error: "Mensagens inválidas." }, { status: 400 });
        const messages = validated.data.slice(-30);

        const { data: thread } = await supabase.from("chat_threads").select("id, title").eq("id", threadId).maybeSingle();
        if (!thread) return Response.json({ error: "Conversa não encontrada." }, { status: 404 });

        const last = messages[messages.length - 1];
        if (!last || last.role !== "user") return Response.json({ error: "Envie uma pergunta." }, { status: 400 });
        const { error: saveErr } = await supabase
          .from("chat_messages")
          .upsert(
            { thread_id: threadId, user_id: userId, message_id: last.id, role: "user", parts: last.parts as never },
            { onConflict: "thread_id,message_id", ignoreDuplicates: true },
          );
        if (saveErr) {
          console.error("save user message failed", saveErr.message);
          return Response.json({ error: "Não consegui salvar sua mensagem. Tente de novo." }, { status: 500 });
        }

        const { createGatewayProvider, CHAT_MODEL, responsesOptions, aiErrorMessage } = await import("@/lib/ai/gateway.server");
        const { searchStoredNews, searchGoogleNews } = await import("@/lib/news-search.server");
        const { withLovableAiGatewayRunIdHeader, getLovableAiGatewayRunId } = await import("@/lib/ai/run-id");
        const { provider, runIdFetch } = createGatewayProvider(getLovableAiGatewayRunId(request));

        // Model history: text only (tool results of older turns are not needed again).
        const history = messages
          .map((m) => ({ ...m, parts: m.parts.filter((p) => p.type === "text") }))
          .filter((m) => m.parts.length > 0);

        const result = streamText({
          model: provider.responses(CHAT_MODEL),
          providerOptions: responsesOptions("low"),
          instructions: instructions(),
          messages: await convertToModelMessages(history),
          stopWhen: isStepCount(50),
          abortSignal: request.signal,
          tools: {
            buscar_noticias: tool({
              description:
                "Busca notícias já coletadas das fontes regionais do Sul Fluminense (Diário do Vale, Jornal aQui, Foco Regional, Jornal Ponto, Folha Sul Fluminense, Portal CidadeNet, Prefeitura de Volta Redonda, A Voz da Cidade, Folha do Interior, Guia Sul Fluminense e outras via Google Notícias). Use null nos filtros que não quiser aplicar.",
              inputSchema: z.object({
                cidade: z.string().nullable().describe("Nome da cidade, ex.: Volta Redonda"),
                assunto: z.enum(TOPIC_IDS).nullable(),
                fonte: z.string().nullable().describe("Nome do veículo, ex.: Diário do Vale"),
                desde: z.string().nullable().describe("Data inicial AAAA-MM-DD"),
                ate: z.string().nullable().describe("Data final AAAA-MM-DD"),
                texto: z.string().nullable().describe("Palavra ou expressão a procurar no título/resumo"),
                limite: z.number().int().nullable().describe("Quantidade (1 a 25)"),
              }),
              execute: async (input) => {
                const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
                return searchStoredNews(supabaseAdmin, input);
              },
            }),
            buscar_no_google: tool({
              description:
                "Pesquisa ao vivo no Google Notícias (últimos 7 dias). Use quando a base regional não tiver a resposta. Inclua a cidade na consulta.",
              inputSchema: z.object({ consulta: z.string().describe("Termos de busca, ex.: 'Volta Redonda trânsito Dutra'") }),
              execute: ({ consulta }) => searchGoogleNews(consulta),
            }),
            pesquisar_google: tool({
              description:
                "Pesquisa ao vivo no Google (web inteira) e devolve um resumo com links. Use para qualquer pergunta geral: clima, horários, endereços, preços, esportes, fatos, curiosidades, explicações, ou quando as outras ferramentas não acharem.",
              inputSchema: z.object({ pergunta: z.string().describe("A pergunta completa a pesquisar") }),
              execute: async ({ pergunta }) => {
                const { searchGoogleWeb } = await import("@/lib/google-search.server");
                return searchGoogleWeb(pergunta, request.signal);
              },
            }),
          },
        });

        const response = result.toUIMessageStreamResponse({
          originalMessages: messages,
          sendReasoning: true,
          onError: (error) => {
            console.error("thassi chat error", error);
            return aiErrorMessage(error);
          },
          onFinish: async ({ responseMessage, isAborted }) => {
            if (!responseMessage.parts.length) return;
            const { error } = await supabase.from("chat_messages").upsert(
              {
                thread_id: threadId,
                user_id: userId,
                message_id: responseMessage.id,
                role: "assistant",
                parts: responseMessage.parts as never,
              },
              { onConflict: "thread_id,message_id" },
            );
            if (error) console.error("save assistant message failed", error.message, { isAborted });
            const firstText = last.parts.find((p) => p.type === "text")?.text?.trim() ?? "";
            const patch: { updated_at: string; title?: string } = { updated_at: new Date().toISOString() };
            if (thread.title === "Nova conversa" && firstText) patch.title = firstText.slice(0, 60);
            const { error: tErr } = await supabase.from("chat_threads").update(patch).eq("id", threadId);
            if (tErr) console.error("thread update failed", tErr.message);
          },
        });
        return withLovableAiGatewayRunIdHeader(response, runIdFetch);
      },
    },
  },
});
