import { createFileRoute } from "@tanstack/react-router";

const MAX_BYTES = 20 * 1024 * 1024;

/** Voice question → text (streams the transcription SSE back unchanged). */
export const Route = createFileRoute("/api/thassi/stt")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { authenticateRequest } = await import("@/lib/request-auth.server");
        const auth = await authenticateRequest(request);
        if ("error" in auth) return auth.error;
        const len = Number(request.headers.get("content-length") ?? "0");
        if (len > MAX_BYTES) return Response.json({ error: "Áudio longo demais (máx. ~10 minutos)." }, { status: 413 });
        const form = await request.formData().catch(() => null);
        const file = form?.get("file");
        if (!(file instanceof File) || file.size === 0) return Response.json({ error: "Áudio não recebido." }, { status: 400 });
        if (file.size > MAX_BYTES) return Response.json({ error: "Áudio longo demais." }, { status: 413 });
        const { AI_BASE_URL, aiKey, STT_MODEL } = await import("@/lib/ai/gateway.server");
        const out = new FormData();
        out.append("file", file, file.name || "pergunta.wav");
        out.append("model", STT_MODEL);
        out.append("language", "pt");
        out.append("stream", "true");
        try {
          const upstream = await fetch(`${AI_BASE_URL}/v1/audio/transcriptions`, {
            method: "POST",
            headers: { Authorization: `Bearer ${aiKey()}` },
            body: out,
            signal: request.signal,
          });
          if (!upstream.ok) console.error(`stt failed [${upstream.status}]`);
          return new Response(upstream.body, {
            status: upstream.status,
            headers: { "Content-Type": upstream.headers.get("content-type") ?? "text/event-stream", "Cache-Control": "no-cache" },
          });
        } catch (e) {
          if (request.signal.aborted) return new Response(null, { status: 499 });
          throw e;
        }
      },
    },
  },
});
