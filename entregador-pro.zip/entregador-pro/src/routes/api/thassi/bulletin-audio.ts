import { createFileRoute } from "@tanstack/react-router";

const STALE_MS = 10 * 60_000;

/** Bulletin audio: generated once in Thassi's voice, stored privately, served by a short-lived link. */
export const Route = createFileRoute("/api/thassi/bulletin-audio")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { authenticateRequest } = await import("@/lib/request-auth.server");
        const auth = await authenticateRequest(request);
        if ("error" in auth) return auth.error;
        const body = (await request.json().catch(() => null)) as { bulletinId?: unknown } | null;
        const id = typeof body?.bulletinId === "string" ? body.bulletinId : "";
        // RLS: only the owner can read the bulletin
        const { data: b } = await auth.supabase.from("bulletins").select("*").eq("id", id).maybeSingle();
        if (!b) return Response.json({ error: "Boletim não encontrado." }, { status: 404 });

        const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
        const sign = async (path: string) => {
          const { data, error } = await db.storage.from("bulletin-audio").createSignedUrl(path, 3600);
          if (error || !data) throw new Error(error?.message ?? "signed url");
          return Response.json({ url: data.signedUrl });
        };
        if (b.audio_status === "ready" && b.audio_path) return sign(b.audio_path);

        const staleBefore = new Date(Date.now() - STALE_MS).toISOString();
        const { data: claimed } = await db
          .from("bulletins")
          .update({ audio_status: "generating", audio_started_at: new Date().toISOString() })
          .eq("id", b.id)
          .or(`audio_status.is.null,audio_status.eq.failed,and(audio_status.eq.generating,audio_started_at.lt.${staleBefore})`)
          .select("id")
          .maybeSingle();
        if (!claimed) return Response.json({ error: "O áudio já está sendo preparado. Tente de novo em instantes." }, { status: 409 });

        const { synthesizePcm, pcmToWav, SpeechError } = await import("@/lib/speech.server");
        const { chunkForSpeech } = await import("@/lib/speech-text");
        try {
          const pcm: Uint8Array[] = [];
          for (const chunk of chunkForSpeech(b.body_text)) pcm.push(await synthesizePcm(chunk));
          const wav = pcmToWav(pcm);
          const path = `${b.user_id}/${b.id}.wav`;
          const { error: upErr } = await db.storage.from("bulletin-audio").upload(path, wav, { contentType: "audio/wav", upsert: true });
          if (upErr) throw new Error(`upload: ${upErr.message}`);
          await db.from("bulletins").update({ audio_status: "ready", audio_path: path }).eq("id", b.id);
          return sign(path);
        } catch (e) {
          console.error("bulletin audio failed", e);
          await db.from("bulletins").update({ audio_status: "failed" }).eq("id", b.id);
          const status = e instanceof SpeechError ? e.status : 500;
          const msg = status === 402 ? "Os créditos de IA do app acabaram." : status === 429 ? "Muitos pedidos de voz agora. Tente em alguns minutos." : "Não consegui gerar o áudio agora.";
          return Response.json({ error: msg }, { status: status >= 400 && status < 600 ? status : 500 });
        }
      },
    },
  },
});
