import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Field, TextInput } from "@/components/common";
import { Logo } from "@/components/logo";
import { isValidPin } from "@/lib/phone";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Criar novo PIN — Entregador Pro" },
      { name: "description", content: "Defina um novo PIN de acesso para sua conta do Entregador Pro." },
      { property: "og:title", content: "Criar novo PIN — Entregador Pro" },
      { property: "og:description", content: "Recuperação de acesso da conta." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);
  const [pin, setPin] = useState("");
  const [pin2, setPin2] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "PASSWORD_RECOVERY" || session) setReady(true);
    });
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) setReady(true);
    });
    return () => data.subscription.unsubscribe();
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!isValidPin(pin)) return setError("O PIN deve ter 6 números.");
    if (pin !== pin2) return setError("Os PINs não conferem.");
    setPending(true);
    const { error } = await supabase.auth.updateUser({ password: pin });
    setPending(false);
    if (error) return setError(error.message);
    toast.success("PIN atualizado!");
    navigate({ to: "/painel", replace: true });
  }

  return (
    <div className="flex min-h-dvh items-center justify-center px-5">
      <form onSubmit={submit} className="flex w-full max-w-sm flex-col gap-4">
        <Logo className="size-11" />
        <h1 className="text-2xl font-bold">Criar novo PIN</h1>
        {!ready ? (
          <p className="text-sm text-muted-foreground">
            Abra esta página pelo link enviado ao seu e-mail. Se o link expirou, peça outro em “Esqueci meu PIN”.
          </p>
        ) : (
          <>
            <Field label="Novo PIN (6 números)">
              <TextInput type="password" inputMode="numeric" maxLength={6} value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))} />
            </Field>
            <Field label="Repita o PIN">
              <TextInput type="password" inputMode="numeric" maxLength={6} value={pin2} onChange={(e) => setPin2(e.target.value.replace(/\D/g, ""))} />
            </Field>
            {error && <p className="text-sm font-medium text-destructive">{error}</p>}
            <Button type="submit" size="lg" disabled={pending}>
              {pending && <Loader2 className="animate-spin" />}
              Salvar PIN
            </Button>
          </>
        )}
      </form>
    </div>
  );
}
