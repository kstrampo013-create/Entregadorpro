import { createFileRoute, Link } from "@tanstack/react-router";
import { Smartphone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Panel } from "@/components/common";
import { PhoneVerification } from "@/components/phone-verification";

export const Route = createFileRoute("/_authenticated/verificar-telefone")({
  head: () => ({
    meta: [
      { title: "Confirmar telefone — Entregador Pro" },
      { name: "description", content: "Confirme seu telefone por SMS." },
      { property: "og:title", content: "Confirmar telefone — Entregador Pro" },
      { property: "og:description", content: "Confirmação do telefone por SMS." },
    ],
  }),
  component: VerifyPhonePage,
});

function VerifyPhonePage() {
  return (
    <div className="mx-auto max-w-md">
      <div className="mb-5 grid size-14 place-items-center rounded-2xl bg-secondary text-secondary-foreground">
        <Smartphone className="size-7" />
      </div>
      <h1 className="text-2xl font-bold">Confirme seu telefone</h1>
      <p className="mb-5 mt-1 text-sm text-muted-foreground">Isso protege sua conta e ajuda na recuperação de acesso.</p>
      <Panel>
        <PhoneVerification />
      </Panel>
      <Button variant="ghost" size="lg" className="mt-4 w-full" asChild>
        <Link to="/painel">Continuar para o painel</Link>
      </Button>
    </div>
  );
}
