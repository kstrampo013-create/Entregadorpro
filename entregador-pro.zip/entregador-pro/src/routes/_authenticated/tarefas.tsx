import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ListTodo, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EmptyState, LoadingBlock, PageHeader, Panel } from "@/components/common";
import { TaskForm } from "@/components/forms/task-form";
import { sortTasks, TaskRow } from "@/components/task-list";
import { useTable } from "@/hooks/use-data";
import type { Task } from "@/lib/db";
import { todayISO } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/tarefas")({
  head: () => ({
    meta: [
      { title: "Tarefas — Entregador Pro" },
      { name: "description", content: "Suas tarefas com data e horário, também mostradas no calendário." },
      { property: "og:title", content: "Tarefas — Entregador Pro" },
      { property: "og:description", content: "Organize suas tarefas com data e horário." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TasksPage,
});

function TasksPage() {
  const { data = [], isLoading } = useTable("tasks");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);
  const today = todayISO();

  const groups = useMemo(() => {
    const all = sortTasks(data);
    return {
      late: all.filter((t) => !t.done && t.due_date < today),
      today: all.filter((t) => !t.done && t.due_date === today),
      next: all.filter((t) => !t.done && t.due_date > today),
      done: all.filter((t) => t.done).reverse().slice(0, 30),
    };
  }, [data, today]);

  function edit(t: Task) {
    setEditing(t);
    setOpen(true);
  }
  function create() {
    setEditing(null);
    setOpen(true);
  }

  return (
    <>
      <PageHeader
        title="Tarefas"
        subtitle="Anote o que precisa fazer, com dia e horário. Tudo aparece no calendário."
        action={
          <Button onClick={create} className="h-11 rounded-xl">
            <Plus /> Nova tarefa
          </Button>
        }
      />
      {isLoading ? (
        <LoadingBlock />
      ) : data.length === 0 ? (
        <EmptyState
          icon={<ListTodo />}
          title="Nenhuma tarefa ainda"
          text="Ex.: revisar a moto, pagar o MEI, buscar encomenda às 14h."
          action={<Button onClick={create}>Criar primeira tarefa</Button>}
        />
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {groups.late.length > 0 && <Group title="Atrasadas" tasks={groups.late} onEdit={edit} showDate />}
          <Group title="Hoje" tasks={groups.today} onEdit={edit} empty="Nada para hoje." />
          <Group title="Próximas" tasks={groups.next} onEdit={edit} showDate empty="Nenhuma tarefa marcada para os próximos dias." />
          {groups.done.length > 0 && <Group title="Concluídas" tasks={groups.done} onEdit={edit} showDate />}
        </div>
      )}
      <TaskForm open={open} onOpenChange={setOpen} record={editing} />
    </>
  );
}

function Group({ title, tasks, onEdit, showDate, empty }: { title: string; tasks: Task[]; onEdit: (t: Task) => void; showDate?: boolean; empty?: string }) {
  return (
    <Panel title={`${title}${tasks.length ? ` (${tasks.length})` : ""}`}>
      {tasks.length === 0 ? (
        <p className="text-sm text-muted-foreground">{empty}</p>
      ) : (
        <ul className="space-y-2">
          {tasks.map((t) => (
            <TaskRow key={t.id} task={t} onEdit={onEdit} showDate={!!showDate} />
          ))}
        </ul>
      )}
    </Panel>
  );
}
