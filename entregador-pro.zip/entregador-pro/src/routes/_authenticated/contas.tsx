import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { AlertTriangle, CalendarClock, Check, Pencil, Plus, Undo2 } from "lucide-react";
import { useQuickPay } from "@/hooks/use-quick-pay";
import { MonthChecklist } from "@/components/month-checklist";
import { addMonths, endOfMonth, format, startOfMonth } from "date-fns";
import { Button } from "@/components/ui/button";
import { ConfirmDelete, EmptyState, Field, FormDialog, LoadingBlock, MoneyInput, PageHeader, Panel, StatCard, StatusBadge, TextInput } from "@/components/common";
import { BillForm, INTERVALS } from "@/components/forms/bill-form";
import { useBillOccurrences, useOverdueBills, type BillOccurrenceView } from "@/hooks/use-derived";
import { useDelete, useInsert, useTable } from "@/hooks/use-data";
import { newId, type Bill } from "@/lib/db";
import { sum } from "@/lib/finance";
import { dateBR, monthLabel, money, parseMoney, todayISO } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/contas")({
  head: () => ({
    meta: [
      { title: "Contas mensais — Entregador Pro" },
      { name: "description", content: "Aluguel, internet, financiamento e outras contas recorrentes." },
      { property: "og:title", content: "Contas mensais — Entregador Pro" },
      { property: "og:description", content: "Contas recorrentes e vencimentos." },
    ],
  }),
  component: BillsPage,
});

function BillsPage() {
  const bills = useTable("bills");
  const delBill = useDelete("bills", "Conta excluída");
  const delPay = useDelete("bill_payments", "Pagamento desfeito");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Bill | null>(null);
  const [paying, setPaying] = useState<BillOccurrenceView | null>(null);
  const quick = useQuickPay();
  const [offset, setOffset] = useState(0);
  const month = addMonths(new Date(), offset);
  const range = { start: format(startOfMonth(month), "yyyy-MM-dd"), end: format(endOfMonth(month), "yyyy-MM-dd") };
  const { occurrences, isLoading } = useBillOccurrences(range);
  const { overdue } = useOverdueBills();
  const upcoming = useBillOccurrences({ start: todayISO(), end: format(addMonths(new Date(), 3), "yyyy-MM-dd") });

  const paid = occurrences.filter((o) => o.payment);
  const pending = occurrences.filter((o) => !o.payment);

  return (
    <>
      <PageHeader
        title="Contas mensais"
        subtitle="Contas que se repetem, com os próximos vencimentos gerados automaticamente."
        action={
          <Button
            size="lg"
            onClick={() => {
              setEditing(null);
              setOpen(true);
            }}
          >
            <Plus /> Nova conta
          </Button>
        }
      />
      {overdue.length > 0 && (
        <Panel
          className="mb-5 border-destructive/40"
          title={
            <span className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="size-5" /> Atrasadas ({overdue.length})
            </span>
          }
        >
          <p className="mb-3 text-sm text-muted-foreground">
            Contas de qualquer mês que venceram e ainda não foram marcadas como pagas. Se você já pagou, toque em "Pago".
          </p>
          <ul className="divide-y rounded-xl border">
            {overdue.map((o) => (
              <li key={o.bill.id + o.reference_month} className="flex flex-wrap items-center gap-3 p-3">
                <div className="min-w-0 flex-1">
                  <p className="font-semibold">{o.bill.name}</p>
                  <p className="text-xs text-muted-foreground first-letter:uppercase">
                    {monthLabel(o.reference_month)} · venceu {dateBR(o.due_date)}
                  </p>
                </div>
                <span className="font-bold tabular">{money(o.bill.expected_amount)}</span>
                <div className="flex items-center gap-1">
                  <Button size="sm" onClick={() => quick.payBill.mutate(o)} disabled={quick.busy}>
                    <Check /> Pago
                  </Button>
                  <Button size="icon-sm" variant="outline" aria-label="Pagar outro valor ou data" onClick={() => setPaying(o)}>
                    <Pencil />
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        </Panel>
      )}
      <div className="mb-4 flex items-center justify-between gap-2">
        <Button variant="outline" onClick={() => setOffset((o) => o - 1)}>
          ‹ Anterior
        </Button>
        <span className="font-display font-semibold first-letter:uppercase">{monthLabel(range.start)}</span>
        <Button variant="outline" onClick={() => setOffset((o) => o + 1)}>
          Próximo ›
        </Button>
      </div>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Previsto no mês" value={money(sum(occurrences, (o) => o.bill.expected_amount))} />
        <StatCard label="Pago" value={money(sum(paid, (o) => o.payment!.paid_amount))} tone="income" />
        <StatCard label="Pendente" value={money(sum(pending, (o) => o.bill.expected_amount))} tone="brand" />
        <StatCard label="Atrasadas (todas)" value={String(overdue.length)} tone="expense" />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_340px]">
        <Panel title="Vencimentos do mês">
          {isLoading ? (
            <LoadingBlock />
          ) : occurrences.length === 0 ? (
            <EmptyState icon={<CalendarClock />} title="Nenhuma conta neste mês" action={<Button onClick={() => setOpen(true)}>Cadastrar conta</Button>} />
          ) : (
            <ul className="divide-y rounded-xl border">
              {occurrences.map((o) => (
                <li key={o.bill.id + o.reference_month} className="flex flex-wrap items-center gap-3 p-3">
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold">{o.bill.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {o.bill.category} · vence {dateBR(o.due_date)}
                      {o.payment && ` · pago ${money(o.payment.paid_amount)} em ${dateBR(o.payment.paid_on)}`}
                    </p>
                  </div>
                  <span className="font-bold tabular">{money(o.bill.expected_amount)}</span>
                  <StatusBadge status={o.status} />
                  {o.payment ? (
                    <ConfirmDelete
                      title="Desmarcar pagamento?"
                      description="A conta voltará a ficar pendente neste mês."
                      confirmLabel="Desmarcar"
                      trigger={
                        <Button variant="ghost" size="icon-sm" aria-label="Desfazer">
                          <Undo2 />
                        </Button>
                      }
                      onConfirm={() => delPay.mutate(o.payment!.id)}
                    />
                  ) : (
                    <div className="flex items-center gap-1">
                      <Button size="sm" onClick={() => quick.payBill.mutate(o)} disabled={quick.busy}>
                        <Check /> Pago
                      </Button>
                      <Button size="icon-sm" variant="outline" aria-label="Pagar outro valor ou data" onClick={() => setPaying(o)}>
                        <Pencil />
                      </Button>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          )}
        </Panel>
        <div className="space-y-5">
          <Panel title="Próximos 3 meses">
            {upcoming.occurrences.filter((o) => !o.payment).length === 0 ? (
              <p className="text-sm text-muted-foreground">Nada pendente.</p>
            ) : (
              <ul className="space-y-2 text-sm">
                {upcoming.occurrences
                  .filter((o) => !o.payment)
                  .slice(0, 8)
                  .map((o) => (
                    <li key={o.bill.id + o.reference_month} className="flex justify-between gap-2">
                      <span>
                        {dateBR(o.due_date)} · {o.bill.name}
                      </span>
                      <span className="tabular font-medium">{money(o.bill.expected_amount)}</span>
                    </li>
                  ))}
              </ul>
            )}
          </Panel>
          <Panel title="Contas cadastradas">
            {(bills.data ?? []).length === 0 ? (
              <p className="text-sm text-muted-foreground">Nenhuma conta ainda.</p>
            ) : (
              <ul className="space-y-2">
                {(bills.data ?? []).map((b) => (
                  <li key={b.id} className="flex items-center gap-2 text-sm">
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-semibold">
                        {b.name} {!b.active && <span className="text-xs font-normal text-muted-foreground">(inativa)</span>}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {INTERVALS.find((i) => i.value === b.interval_months)?.label} · dia {b.due_day} · {money(b.expected_amount)}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon-sm"
                      aria-label="Editar"
                      onClick={() => {
                        setEditing(b);
                        setOpen(true);
                      }}
                    >
                      <Pencil />
                    </Button>
                    <ConfirmDelete title="Excluir esta conta?" description="O histórico de pagamentos dela também será excluído." onConfirm={() => delBill.mutate(b.id)} />
                  </li>
                ))}
              </ul>
            )}
          </Panel>
        </div>
      </div>
      <div className="mt-5">
        <MonthChecklist title="Tudo que vence no mês (contas e parcelas)" />
      </div>
      <BillForm open={open} onOpenChange={setOpen} record={editing} />
      <BillPayDialog occ={paying} onClose={() => setPaying(null)} />
    </>
  );
}

function BillPayDialog({ occ, onClose }: { occ: BillOccurrenceView | null; onClose: () => void }) {
  const insert = useInsert("bill_payments", "Conta marcada como paga");
  const [id, setId] = useState(newId());
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(todayISO());
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    if (!occ) return;
    setId(newId());
    setAmount(String(occ.bill.expected_amount).replace(".", ","));
    setDate(todayISO());
    setError(null);
  }, [occ]);

  function submit() {
    if (!occ) return;
    const v = parseMoney(amount);
    if (!(v > 0)) return setError("Informe o valor pago");
    insert.mutate(
      { id, bill_id: occ.bill.id, reference_month: occ.reference_month, paid_amount: v, paid_on: date, is_demo: occ.bill.is_demo },
      { onSuccess: onClose },
    );
  }

  return (
    <FormDialog
      open={!!occ}
      onOpenChange={(o) => !o && onClose()}
      title={`Pagar ${occ?.bill.name ?? ""}`}
      description={occ ? `Vencimento ${dateBR(occ.due_date)}` : undefined}
      onSubmit={submit}
      pending={insert.isPending}
      submitLabel="Confirmar pagamento"
    >
      <div className="grid grid-cols-2 gap-3">
        <Field label="Valor efetivamente pago" error={error ?? undefined}>
          <MoneyInput value={amount} onChange={(e) => setAmount(e.target.value)} />
        </Field>
        <Field label="Data do pagamento">
          <TextInput type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </Field>
      </div>
    </FormDialog>
  );
}
