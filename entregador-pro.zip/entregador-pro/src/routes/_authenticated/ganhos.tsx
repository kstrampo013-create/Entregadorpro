import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Clock, Gauge, Pencil, Plus, Route as RouteIcon, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ConfirmDelete, EmptyState, LoadingBlock, PageHeader, Panel, StatCard, TextInput } from "@/components/common";
import { NativeSelect } from "@/components/native-select";
import { EarningForm } from "@/components/forms/earning-form";
import { useDelete, useTable } from "@/hooks/use-data";
import type { EntryShortcut, Earning } from "@/lib/db";
import { ShortcutChips } from "@/components/shortcuts";
import { inRange, periodRange, perHour, perKm, sum } from "@/lib/finance";
import { dateBR, dateLong, km, money, number, todayISO } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/ganhos")({
  head: () => ({
    meta: [
      { title: "Ganhos — Entregador Pro" },
      { name: "description", content: "Registre ganhos por aplicativo, com horas e quilômetros." },
      { property: "og:title", content: "Ganhos — Entregador Pro" },
      { property: "og:description", content: "Controle de ganhos de entregas." },
    ],
  }),
  component: EarningsPage,
});

function EarningsPage() {
  const { data = [], isLoading } = useTable("earnings");
  const del = useDelete("earnings", "Ganho excluído");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Earning | null>(null);
  const [preset, setPreset] = useState<EntryShortcut | null>(null);
  const [month, setMonth] = useState(todayISO().slice(0, 7));
  const [source, setSource] = useState("");
  const today = todayISO();

  const day = periodRange("dia", today);
  const week = periodRange("semana", today);
  const monthNow = periodRange("mes", today);
  const monthRows = data.filter((e) => inRange(e.date, monthNow));
  const monthKm = sum(monthRows, (e) => e.km);
  const monthHours = sum(monthRows, (e) => e.hours);
  const monthTotal = sum(monthRows, (e) => e.amount);

  const sources = useMemo(() => Array.from(new Set(data.map((e) => e.source))).sort(), [data]);
  const filtered = data.filter((e) => (!month || e.date.startsWith(month)) && (!source || e.source === source));
  const groups = useMemo(() => {
    const m = new Map<string, Earning[]>();
    filtered.forEach((e) => m.set(e.date, [...(m.get(e.date) ?? []), e]));
    return Array.from(m.entries()).sort((a, b) => b[0].localeCompare(a[0]));
  }, [filtered]);

  const openNew = () => {
    setEditing(null);
    setPreset(null);
    setOpen(true);
  };

  return (
    <>
      <PageHeader
        title="Ganhos"
        subtitle="Tudo o que entrou, por aplicativo ou trabalho particular."
        action={
          <Button size="lg" onClick={openNew}>
            <Plus /> Novo ganho
          </Button>
        }
      />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Hoje" value={money(sum(data.filter((e) => inRange(e.date, day)), (e) => e.amount))} tone="income" icon={<TrendingUp />} />
        <StatCard label="Semana" value={money(sum(data.filter((e) => inRange(e.date, week)), (e) => e.amount))} tone="income" icon={<TrendingUp />} />
        <StatCard label="Mês" value={money(monthTotal)} tone="brand" hint={`${km(monthKm)} · ${number(monthHours)} h`} />
        <StatCard
          label="Média do mês"
          value={perKm(monthTotal, monthKm) != null ? `${money(perKm(monthTotal, monthKm))}/km` : "—"}
          hint={perHour(monthTotal, monthHours) != null ? `${money(perHour(monthTotal, monthHours))}/hora` : "Informe km e horas"}
          icon={<Gauge />}
        />
      </div>

      <div className="mt-5 rounded-2xl border bg-card p-4 shadow-soft empty:hidden">
        <ShortcutChips
          kind="earning"
          onPick={(sc) => {
            setEditing(null);
            setPreset(sc);
            setOpen(true);
          }}
        />
      </div>
      <Panel className="mt-5">
        <div className="mb-4 grid grid-cols-2 gap-2 sm:flex">
          <TextInput type="month" value={month} onChange={(e) => setMonth(e.target.value)} className="sm:w-48" aria-label="Mês" />
          <NativeSelect value={source} onChange={(e) => setSource(e.target.value)} className="sm:w-48" aria-label="Fonte">
            <option value="">Todas as fontes</option>
            {sources.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </NativeSelect>
        </div>
        {isLoading ? (
          <LoadingBlock />
        ) : groups.length === 0 ? (
          <EmptyState icon={<TrendingUp />} title="Nenhum ganho neste filtro" text="Registre seus ganhos do dia para ver seus totais." action={<Button onClick={openNew}>Registrar ganho</Button>} />
        ) : (
          <div className="space-y-5">
            {groups.map(([date, rows]) => (
              <div key={date}>
                <div className="mb-2 flex items-baseline justify-between text-sm">
                  <span className="font-semibold first-letter:uppercase">{dateLong(date)}</span>
                  <span className="font-bold text-income tabular">{money(sum(rows, (r) => r.amount))}</span>
                </div>
                <ul className="divide-y rounded-xl border">
                  {rows.map((e) => (
                    <li key={e.id} className="flex items-center gap-3 p-3">
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-semibold">
                          {e.source}
                          {e.is_demo && <span className="ml-2 rounded bg-muted px-1.5 text-[10px] font-bold uppercase text-muted-foreground">demo</span>}
                        </p>
                        <p className="flex flex-wrap gap-x-3 text-xs text-muted-foreground">
                          <span>{dateBR(e.date)}</span>
                          {e.hours != null && (
                            <span className="inline-flex items-center gap-1">
                              <Clock className="size-3" />
                              {number(e.hours)} h
                            </span>
                          )}
                          {e.km != null && (
                            <span className="inline-flex items-center gap-1">
                              <RouteIcon className="size-3" />
                              {km(e.km)}
                            </span>
                          )}
                          {e.notes && <span className="truncate">{e.notes}</span>}
                        </p>
                      </div>
                      <span className="font-bold text-income tabular">{money(e.amount)}</span>
                      <Button
                        variant="ghost"
                        size="icon-sm"
                        aria-label="Editar"
                        onClick={() => {
                          setEditing(e);
                          setPreset(null);
                          setOpen(true);
                        }}
                      >
                        <Pencil />
                      </Button>
                      <ConfirmDelete title="Excluir este ganho?" description={`${e.source} · ${money(e.amount)} em ${dateBR(e.date)}`} onConfirm={() => del.mutate(e.id)} />
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        )}
      </Panel>
      <EarningForm open={open} onOpenChange={setOpen} record={editing} preset={preset} />
    </>
  );
}
