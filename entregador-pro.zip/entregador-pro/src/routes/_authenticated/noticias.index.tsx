import { useMemo, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { AlertTriangle, ExternalLink, Loader2, Newspaper, RefreshCw, Search, Square, Volume2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { EmptyState, LoadingBlock, Panel, TextInput } from "@/components/common";
import { NativeSelect } from "@/components/native-select";
import { NelsHeader } from "@/components/nels/nels-nav";
import { newsKeys, useJobState, useNewsItems, usePrefs, type NewsItem } from "@/hooks/use-news";
import { CITIES, localDate, NEWS_SOURCES, normalizeText, TOPICS, topicLabel } from "@/lib/news";
import { refreshNews } from "@/lib/nels.functions";
import { speak } from "@/lib/thassi-client";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/noticias/")({
  head: () => ({
    meta: [
      { title: "Nels Nere — Notícias do Sul Fluminense" },
      { name: "description", content: "Notícias recentes de Volta Redonda, Barra Mansa, Resende e região, com link para a fonte." },
      { property: "og:title", content: "Nels Nere — Notícias do Sul Fluminense" },
      { property: "og:description", content: "Notícias regionais verificáveis, filtradas por cidade, assunto e fonte." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: NewsPage,
});

type Period = "hoje" | "24h" | "7d";

function when(n: NewsItem) {
  const iso = n.published_at ?? n.fetched_at;
  return formatDistanceToNow(new Date(iso), { addSuffix: true, locale: ptBR });
}

function NewsPage() {
  const { data = [], isLoading, error } = useNewsItems();
  const prefs = usePrefs();
  const job = useJobState();
  const qc = useQueryClient();
  const refresh = useServerFn(refreshNews);
  const [refreshing, setRefreshing] = useState(false);
  const [city, setCity] = useState("");
  const [topic, setTopic] = useState("");
  const [source, setSource] = useState("");
  const [period, setPeriod] = useState<Period>("24h");
  const [query, setQuery] = useState("");
  const [onlyMine, setOnlyMine] = useState(true);
  const [speaking, setSpeaking] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const myCities = prefs.data?.cities ?? [];
  const sourcesInData = useMemo(() => {
    const m = new Map<string, string>();
    for (const n of data) m.set(n.source_id, n.source_name);
    for (const s of NEWS_SOURCES) m.set(s.id, s.name);
    return [...m.entries()].sort((a, b) => a[1].localeCompare(b[1]));
  }, [data]);

  const filtered = useMemo(() => {
    const now = Date.now();
    const today = localDate(new Date());
    const q = query.trim() ? normalizeText(query).trim() : "";
    return data.filter((n) => {
      const iso = n.published_at ?? n.fetched_at;
      if (period === "hoje" && localDate(new Date(iso)) !== today) return false;
      if (period === "24h" && now - new Date(iso).getTime() > 24 * 3600_000) return false;
      if (city) {
        if (!n.cities.includes(city)) return false;
      } else if (onlyMine && myCities.length && !n.cities.some((c) => myCities.includes(c))) return false;
      if (topic && !n.topics.includes(topic)) return false;
      if (source && n.source_id !== source) return false;
      if (q && !normalizeText(`${n.title} ${n.summary ?? ""}`).includes(q)) return false;
      return true;
    });
  }, [data, period, city, topic, source, query, onlyMine, myCities]);

  async function onRefresh() {
    setRefreshing(true);
    try {
      const r = await refresh();
      if (r.recent) toast.info("As fontes foram lidas há poucos minutos. Mostrando o mais recente.");
      else toast.success(r.inserted ? `${r.inserted} notícia(s) nova(s)` : "Nenhuma notícia nova nas fontes agora");
      if (r.failed.length) toast.warning(`${r.failed.length} fonte(s) não responderam desta vez.`);
      await qc.invalidateQueries({ queryKey: newsKeys.items });
      await qc.invalidateQueries({ queryKey: newsKeys.job });
    } catch {
      toast.error("Não consegui atualizar agora. Verifique sua internet.");
    } finally {
      setRefreshing(false);
    }
  }

  async function listen(n: NewsItem) {
    abortRef.current?.abort();
    if (speaking === n.id) {
      setSpeaking(null);
      return;
    }
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setSpeaking(n.id);
    try {
      await speak(`${n.title}. ${n.summary ?? ""} Fonte: ${n.source_name}.`, ctrl.signal);
    } catch (e) {
      if (!ctrl.signal.aborted) toast.error(e instanceof Error ? e.message : "Não consegui ler agora.");
    } finally {
      if (abortRef.current === ctrl) setSpeaking(null);
    }
  }

  const lastIngest = job.data?.last_ingest_at;

  return (
    <>
      <NelsHeader
        subtitle={
          lastIngest
            ? `Fontes lidas ${formatDistanceToNow(new Date(lastIngest), { addSuffix: true, locale: ptBR })}`
            : "Notícias do Sul Fluminense"
        }
        action={
          <Button onClick={onRefresh} disabled={refreshing} variant="outline" className="h-11 rounded-xl">
            {refreshing ? <Loader2 className="size-4 animate-spin" /> : <RefreshCw className="size-4" />}
            Gerar notícias
          </Button>
        }
      />

      <Panel className="mb-4 space-y-3">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <TextInput
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar: Dutra, vagas, chuva…"
            className="pl-9"
            aria-label="Buscar notícias"
          />
        </div>
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
          <NativeSelect value={city} onChange={(e) => setCity(e.target.value)} aria-label="Cidade">
            <option value="">{onlyMine && myCities.length ? "Minhas cidades" : "Todas as cidades"}</option>
            {[...CITIES].sort((a, b) => a.localeCompare(b)).map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </NativeSelect>
          <NativeSelect value={topic} onChange={(e) => setTopic(e.target.value)} aria-label="Assunto">
            <option value="">Todos os assuntos</option>
            {TOPICS.map((t) => (
              <option key={t.id} value={t.id}>
                {t.label}
              </option>
            ))}
          </NativeSelect>
          <NativeSelect value={source} onChange={(e) => setSource(e.target.value)} aria-label="Fonte">
            <option value="">Todas as fontes</option>
            {sourcesInData.map(([id, name]) => (
              <option key={id} value={id}>
                {name}
              </option>
            ))}
          </NativeSelect>
          <NativeSelect value={period} onChange={(e) => setPeriod(e.target.value as Period)} aria-label="Período">
            <option value="hoje">Hoje</option>
            <option value="24h">Últimas 24 horas</option>
            <option value="7d">Últimos 7 dias</option>
          </NativeSelect>
        </div>
        {myCities.length > 0 && !city && (
          <label className="flex items-center gap-2 text-sm text-muted-foreground">
            <input type="checkbox" checked={onlyMine} onChange={(e) => setOnlyMine(e.target.checked)} className="size-4 accent-primary" />
            Só minhas cidades ({myCities.join(", ")})
          </label>
        )}
      </Panel>

      {isLoading ? (
        <LoadingBlock />
      ) : error ? (
        <EmptyState icon={<AlertTriangle />} title="Não consegui carregar as notícias" text="Verifique sua internet e tente de novo." />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<Newspaper />}
          title={data.length ? "Nada com esses filtros" : "Ainda não há notícias coletadas"}
          text={data.length ? "Tente outro período, cidade ou assunto." : "Toque em Gerar notícias para buscar as notícias agora."}
          action={
            !data.length ? (
              <Button onClick={onRefresh} disabled={refreshing}>
                Gerar notícias
              </Button>
            ) : undefined
          }
        />
      ) : (
        <>
          <p className="mb-2 text-sm text-muted-foreground">
            {filtered.length} notícia{filtered.length === 1 ? "" : "s"}
          </p>
          <ul className="space-y-3">
            {filtered.slice(0, 150).map((n) => (
              <li key={n.id}>
                <article className={cn("rounded-2xl border bg-card p-4 shadow-soft", n.is_alert && "border-warning/70")}>
                  <div className="mb-1.5 flex flex-wrap items-center gap-1.5 text-xs">
                    {n.is_alert && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-warning px-2 py-0.5 font-bold text-warning-foreground">
                        <AlertTriangle className="size-3" /> Alerta
                      </span>
                    )}
                    {n.cities.slice(0, 3).map((c) => (
                      <span key={c} className="rounded-full bg-secondary px-2 py-0.5 font-semibold text-secondary-foreground">
                        {c}
                      </span>
                    ))}
                    {n.topics.slice(0, 2).map((t) => (
                      <span key={t} className="rounded-full border px-2 py-0.5 text-muted-foreground">
                        {topicLabel(t)}
                      </span>
                    ))}
                  </div>
                  <h2 className="font-display text-base font-semibold leading-snug">
                    <a href={n.url} target="_blank" rel="noopener noreferrer" className="hover:text-primary hover:underline">
                      {n.title}
                    </a>
                  </h2>
                  {n.summary && <p className="mt-1.5 line-clamp-3 text-sm text-muted-foreground">{n.summary}</p>}
                  <div className="mt-3 flex items-center justify-between gap-2 text-xs text-muted-foreground">
                    <span className="min-w-0 truncate">
                      <strong className="text-foreground">{n.source_name}</strong> · {when(n)}
                      {n.origin === "google" && " · via Google Notícias"}
                    </span>
                    <div className="flex shrink-0 gap-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-9"
                        onClick={() => listen(n)}
                        aria-label={speaking === n.id ? "Parar leitura" : "Ouvir na voz da Thassi"}
                      >
                        {speaking === n.id ? <Square className="size-4" /> : <Volume2 className="size-4" />}
                      </Button>
                      <Button asChild size="sm" variant="outline" className="h-9">
                        <a href={n.url} target="_blank" rel="noopener noreferrer">
                          Abrir <ExternalLink className="size-3.5" />
                        </a>
                      </Button>
                    </div>
                  </div>
                </article>
              </li>
            ))}
          </ul>
        </>
      )}
    </>
  );
}
