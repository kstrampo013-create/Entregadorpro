import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Search, Wallet } from "lucide-react";
import { addDays, format } from "date-fns";
import { Button } from "@/components/ui/button";
import { EmptyState, LoadingBlock, PageHeader, Panel, StatCard, StatusBadge, TextInput } from "@/components/common";
import { NativeSelect } from "@/components/native-select";
import { PayInstallmentDialog } from "@/components/forms/pay-installment-dialog";
import { useContracts } from "@/hooks/use-derived";
import type { Installment } from "@/lib/db";
import { remainingOf } from "@/lib/finance";
import { dateBR, money, todayISO } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/carteira")({
  head: () => ({
    meta: [
      { title: "Carteira — Entregador Pro" },
      { name: "description", content: "Tudo o que você tem a receber de vendas e empréstimos." },
      { property: "og:title", content: "Carteira — Entregador Pro" },
      { property: "og:description", content: "Valores a receber." },
    ],
  }),
  component: WalletPage,
});

function WalletPage() {
  const { contracts, isLoading } = useContracts();
  const [type, setType] = useState<"todos" | "sale" | "loan">("todos");
  const [status, setStatus] = useState<"abertos" | "atrasado" | "em_dia" | "quitado" | "todos">("abertos");
  const [due, setDue] = useState<"todos" | "7" | "30" | "vencidos">("todos");
  const [q, setQ] = useState("");
  const [paying, setPaying] = useState<{ inst: Installment; label: string } | null>(null);
  const today = todayISO();
  const in7 = format(addDays(new Date(), 7), "yyyy-MM-dd");
  const in30 = format(addDays(new Date(), 30), "yyyy-MM-dd");

  const open = contracts.filter((c) => c.summary.status !== "quitado");
  const totalRemaining = open.reduce((s, c) => s + c.summary.remaining, 0);
  const overdue = contracts.flatMap((c) => c.installments).filter((i) => remainingOf(i) > 0 && i.due_date < today);
  const next7 = contracts.flatMap((c) => c.installments).filter((i) => remainingOf(i) > 0 && i.due_date >= today && i.due_date <= in7);

  const rows = contracts
    .filter((c) => type === "todos" || c.kind === type)
    .filter((c) => (status === "todos" ? true : status === "abertos" ? c.summary.status !== "quitado" : c.summary.status === status))
    .filter((c) => !q || c.name.toLowerCase().includes(q.toLowerCase()))
    .filter((c) => {
      if (due === "todos") return true;
      const n = c.summary.nextDue;
      if (!n) return false;
      if (due === "vencidos") return n < today;
      return n >= today && n <= (due === "7" ? in7 : in30);
    })
    .sort((a, b) => (a.summary.nextDue ?? "9999").localeCompare(b.summary.nextDue ?? "9999"));

  return (
    <>
      <PageHeader title="Carteira" subtitle="Valores a receber de vendas e empréstimos, atualizados a cada pagamento." />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Total a receber" value={money(totalRemaining)} tone="brand" icon={<Wallet />} />
        <StatCard label="Em atraso" value={money(overdue.reduce((s, i) => s + remainingOf(i), 0))} tone="expense" hint={`${overdue.length} parcela(s)`} />
        <StatCard label="Próximos 7 dias" value={money(next7.reduce((s, i) => s + remainingOf(i), 0))} hint={`${next7.length} parcela(s)`} />
        <StatCard label="Já recebido" value={money(contracts.reduce((s, c) => s + c.summary.received, 0))} tone="income" />
      </div>

      <Panel className="mt-5">
        <div className="mb-4 grid grid-cols-2 gap-2 lg:grid-cols-4">
          <div className="relative col-span-2 lg:col-span-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <TextInput placeholder="Buscar cliente…" value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
          </div>
          <NativeSelect value={type} onChange={(e) => setType(e.target.value as typeof type)} aria-label="Tipo">
            <option value="todos">Vendas e empréstimos</option>
            <option value="sale">Só vendas</option>
            <option value="loan">Só empréstimos</option>
          </NativeSelect>
          <NativeSelect value={status} onChange={(e) => setStatus(e.target.value as typeof status)} aria-label="Situação">
            <option value="abertos">Em aberto</option>
            <option value="atrasado">Atrasados</option>
            <option value="em_dia">Em dia</option>
            <option value="quitado">Quitados</option>
            <option value="todos">Todas as situações</option>
          </NativeSelect>
          <NativeSelect value={due} onChange={(e) => setDue(e.target.value as typeof due)} aria-label="Vencimento" className="col-span-2 lg:col-span-1">
            <option value="todos">Qualquer vencimento</option>
            <option value="vencidos">Vencidos</option>
            <option value="7">Próximos 7 dias</option>
            <option value="30">Próximos 30 dias</option>
          </NativeSelect>
        </div>

        {isLoading ? (
          <LoadingBlock />
        ) : rows.length === 0 ? (
          <EmptyState icon={<Wallet />} title="Nada a mostrar" text="Crie vendas parceladas ou empréstimos para ver seus recebíveis aqui." />
        ) : (
          <>
            {/* Mobile cards */}
            <ul className="space-y-3 md:hidden">
              {rows.map((c) => {
                const next = c.installments.find((i) => remainingOf(i) > 0);
                return (
                  <li key={c.kind + c.id} className="rounded-xl border p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="truncate font-semibold">{c.name}</p>
                        <p className="text-xs text-muted-foreground">{c.kind === "sale" ? "Venda" : "Empréstimo"} · {c.description}</p>
                      </div>
                      <StatusBadge status={c.summary.status} />
                    </div>
                    <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
                      <Metric label="Original" value={money(c.summary.original)} />
                      <Metric label="Recebido" value={money(c.summary.received)} />
                      <Metric label="Saldo" value={money(c.summary.remaining)} strong />
                    </div>
                    <div className="mt-3 flex items-center justify-between gap-2">
                      <span className="text-xs text-muted-foreground">
                        {next ? `Próx. ${dateBR(next.due_date)} · ${c.summary.pendingCount} pendente(s)` : "Quitado"}
                      </span>
                      <div className="flex gap-2">
                        {next && (
                          <Button size="sm" variant="soft" onClick={() => setPaying({ inst: next, label: c.name })}>
                            Receber
                          </Button>
                        )}
                        <DetailLink kind={c.kind} id={c.id} />
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
            {/* Desktop table */}
            <div className="hidden overflow-x-auto md:block">
              <table className="w-full text-sm">
                <thead className="text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <tr className="border-b">
                    <th className="py-2 pr-3">Cliente / devedor</th>
                    <th className="py-2 pr-3">Origem</th>
                    <th className="py-2 pr-3 text-right">Original</th>
                    <th className="py-2 pr-3 text-right">Recebido</th>
                    <th className="py-2 pr-3 text-right">Saldo</th>
                    <th className="py-2 pr-3">Próx. venc.</th>
                    <th className="py-2 pr-3 text-center">Pend.</th>
                    <th className="py-2 pr-3">Situação</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {rows.map((c) => {
                    const next = c.installments.find((i) => remainingOf(i) > 0);
                    return (
                      <tr key={c.kind + c.id} className="border-b last:border-0">
                        <td className="py-3 pr-3 font-semibold">{c.name}</td>
                        <td className="py-3 pr-3">{c.kind === "sale" ? "Venda" : "Empréstimo"}</td>
                        <td className="py-3 pr-3 text-right tabular">{money(c.summary.original)}</td>
                        <td className="py-3 pr-3 text-right tabular text-income">{money(c.summary.received)}</td>
                        <td className="py-3 pr-3 text-right font-bold tabular">{money(c.summary.remaining)}</td>
                        <td className="py-3 pr-3">{dateBR(c.summary.nextDue)}</td>
                        <td className="py-3 pr-3 text-center">{c.summary.pendingCount}</td>
                        <td className="py-3 pr-3">
                          <StatusBadge status={c.summary.status} />
                        </td>
                        <td className="py-3 text-right">
                          <div className="flex justify-end gap-2">
                            {next && (
                              <Button size="sm" variant="soft" onClick={() => setPaying({ inst: next, label: c.name })}>
                                Receber
                              </Button>
                            )}
                            <DetailLink kind={c.kind} id={c.id} />
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </Panel>
      <PayInstallmentDialog installment={paying?.inst ?? null} label={paying?.label} onOpenChange={(o) => !o && setPaying(null)} />
    </>
  );
}

function Metric({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="rounded-lg bg-muted px-2 py-1.5">
      <p className="text-muted-foreground">{label}</p>
      <p className={strong ? "font-bold tabular" : "font-medium tabular"}>{value}</p>
    </div>
  );
}

function DetailLink({ kind, id }: { kind: "sale" | "loan"; id: string }) {
  return (
    <Button size="sm" variant="outline" asChild>
      {kind === "sale" ? <Link to="/vendas/$id" params={{ id }}>Ver</Link> : <Link to="/emprestimos/$id" params={{ id }}>Ver</Link>}
    </Button>
  );
}
