import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { CheckCircle2, ExternalLink, Loader2, Send, XCircle } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Field, LoadingBlock, Panel, TextInput } from "@/components/common";
import { NelsHeader, TogglePills } from "@/components/nels/nels-nav";
import { supabase } from "@/integrations/supabase/client";
import { usePrefs, useSavePrefs, useSourceStatus } from "@/hooks/use-news";
import { CITIES, NEWS_SOURCES, TOPICS } from "@/lib/news";
import { createTelegramLink, getTelegramStatus, sendTelegramTest } from "@/lib/nels.functions";

export const Route = createFileRoute("/_authenticated/noticias/ajustes")({
  head: () => ({
    meta: [
      { title: "Ajustes do Nels Nere — cidades, boletins e Telegram" },
      { name: "description", content: "Escolha cidades, assuntos, horários dos boletins e notificações no Telegram." },
      { property: "og:title", content: "Ajustes do Nels Nere" },
      { property: "og:description", content: "Personalize as notícias e os boletins da Thassi." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SettingsPage,
});

const CITY_OPTIONS = [...CITIES].sort((a, b) => a.localeCompare(b)).map((c) => ({ value: c as string, label: c as string }));
const TOPIC_OPTIONS = TOPICS.map((t) => ({ value: t.id, label: t.label }));

function SettingsPage() {
  const prefs = usePrefs();
  const save = useSavePrefs();
  const p = prefs.data;

  if (prefs.isLoading || !p) return <LoadingBlock />;

  return (
    <>
      <NelsHeader subtitle="Suas cidades, assuntos, boletins e Telegram" />
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title="Cidades que você acompanha">
          <p className="mb-3 text-sm text-muted-foreground">Usadas nos boletins e no filtro “Minhas cidades”. Sem nenhuma marcada, vale a região toda.</p>
          <TogglePills label="Cidades" options={CITY_OPTIONS} value={p.cities} onChange={(cities) => save.mutate({ cities })} />
        </Panel>
        <Panel title="Assuntos preferidos">
          <p className="mb-3 text-sm text-muted-foreground">Os boletins dão prioridade a esses assuntos. Sem nenhum marcado, entram todos.</p>
          <TogglePills label="Assuntos" options={TOPIC_OPTIONS} value={p.topics} onChange={(topics) => save.mutate({ topics })} />
        </Panel>


        <TelegramPanel />
        <SourcesPanel />
      </div>
    </>
  );
}

function SlotRow({
  label,
  enabled,
  time,
  onEnabled,
  onTime,
}: {
  label: string;
  enabled: boolean;
  time: string;
  onEnabled: (v: boolean) => void;
  onTime: (v: string) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl border p-3">
      <label className="flex items-center gap-3 font-semibold">
        <Switch checked={enabled} onCheckedChange={onEnabled} aria-label={label} />
        {label}
      </label>
      <TextInput
        type="time"
        defaultValue={time}
        disabled={!enabled}
        aria-label={`Horário do ${label.toLowerCase()}`}
        className="h-11 w-28"
        onBlur={(e) => e.target.value && e.target.value !== time && onTime(e.target.value)}
      />
    </div>
  );
}

function TelegramPanel() {
  const qc = useQueryClient();
  const prefs = usePrefs();
  const save = useSavePrefs();
  const statusFn = useServerFn(getTelegramStatus);
  const linkFn = useServerFn(createTelegramLink);
  const testFn = useServerFn(sendTelegramTest);
  const status = useQuery({ queryKey: ["news", "telegram"], queryFn: () => statusFn(), staleTime: 30_000 });
  const [code, setCode] = useState<{ code: string; link: string } | null>(null);
  const [busy, setBusy] = useState<"link" | "test" | "off" | null>(null);
  const p = prefs.data;

  async function connect() {
    setBusy("link");
    try {
      const r = await linkFn();
      if (!r.ok) {
        toast.error(r.error);
        return;
      }
      setCode({ code: r.code, link: r.link });
      window.open(r.link, "_blank", "noopener");
    } finally {
      setBusy(null);
    }
  }

  async function test() {
    setBusy("test");
    try {
      const r = await testFn({ data: {} });
      if (r.ok) toast.success("Mensagem de teste enviada!");
      else toast.error(r.error);
    } finally {
      setBusy(null);
    }
  }

  async function disconnect() {
    setBusy("off");
    const { error } = await supabase.from("telegram_links").delete().neq("chat_id", 0);
    setBusy(null);
    if (error) toast.error("Não consegui desconectar.");
    else toast.success("Telegram desconectado");
    setCode(null);
    await qc.invalidateQueries({ queryKey: ["news", "telegram"] });
  }

  const s = status.data;
  return (
    <Panel title="Telegram">
      {status.isLoading ? (
        <LoadingBlock />
      ) : !s?.configured ? (
        <div className="rounded-xl border border-warning/60 bg-warning/10 p-3 text-sm">
          <p className="font-semibold">O bot do Telegram ainda não está ligado a este app.</p>
          <p className="mt-1 text-muted-foreground">
            Assim que o bot for conectado, você poderá receber os boletins e alertas urgentes aqui no Telegram.
          </p>
        </div>
      ) : s.link ? (
        <div className="space-y-4">
          <p className="flex items-center gap-2 text-sm">
            <CheckCircle2 className="size-5 text-success" />
            Conectado{s.link.tg_name ? ` como ${s.link.tg_name}` : ""}
            {s.link.tg_username ? ` (@${s.link.tg_username})` : ""}
          </p>
          {p && (
            <div className="space-y-3">
              <label className="flex items-center justify-between gap-3 rounded-xl border p-3 font-semibold">
                Receber os boletins
                <Switch checked={p.tg_bulletins} onCheckedChange={(v) => save.mutate({ tg_bulletins: v })} />
              </label>
              <label className="flex items-center justify-between gap-3 rounded-xl border p-3 font-semibold">
                Alertas urgentes (acidentes, interdições, chuva forte…)
                <Switch checked={p.tg_alerts} onCheckedChange={(v) => save.mutate({ tg_alerts: v })} />
              </label>
              {p.tg_alerts && (
                <>
                  <Field label="Alertas só destes assuntos (opcional)">
                    <TogglePills label="Assuntos dos alertas" options={TOPIC_OPTIONS} value={p.tg_topics} onChange={(tg_topics) => save.mutate({ tg_topics })} />
                  </Field>
                  <div className="grid grid-cols-2 gap-3">
                    <Field label="Alertas a partir de">
                      <TextInput
                        type="time"
                        defaultValue={p.tg_from.slice(0, 5)}
                        onBlur={(e) => e.target.value && save.mutate({ tg_from: e.target.value })}
                      />
                    </Field>
                    <Field label="Até">
                      <TextInput
                        type="time"
                        defaultValue={p.tg_until.slice(0, 5)}
                        onBlur={(e) => e.target.value && save.mutate({ tg_until: e.target.value })}
                      />
                    </Field>
                  </div>
                </>
              )}
            </div>
          )}
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" className="h-10" onClick={test} disabled={busy !== null}>
              {busy === "test" ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
              Enviar teste
            </Button>
            <Button variant="ghost" className="h-10 text-destructive" onClick={disconnect} disabled={busy !== null}>
              Desconectar
            </Button>
          </div>
        </div>
      ) : (
        <div className="space-y-3 text-sm">
          <p className="text-muted-foreground">
            Toque no botão, o Telegram vai abrir a conversa com o bot <strong>@{s.bot}</strong>. Depois é só tocar em <strong>Iniciar</strong>.
          </p>
          <Button onClick={connect} disabled={busy !== null} className="h-11">
            {busy === "link" ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
            Conectar Telegram
          </Button>
          {code && (
            <div className="rounded-xl border bg-secondary/40 p-3">
              <p>
                Se o Telegram não abriu,{" "}
                <a href={code.link} target="_blank" rel="noopener noreferrer" className="font-semibold text-primary underline">
                  toque aqui <ExternalLink className="inline size-3" />
                </a>{" "}
                ou envie para o bot: <code className="font-mono font-bold">/start {code.code}</code>
              </p>
              <p className="mt-1 text-xs text-muted-foreground">O código vale por 15 minutos.</p>
              <Button size="sm" variant="outline" className="mt-2" onClick={() => qc.invalidateQueries({ queryKey: ["news", "telegram"] })}>
                Já conectei
              </Button>
            </div>
          )}
        </div>
      )}
    </Panel>
  );
}

function SourcesPanel() {
  const { data = [], isLoading } = useSourceStatus();
  const byId = new Map(data.map((s) => [s.source_id, s]));
  return (
    <Panel title="Fontes de notícias">
      {isLoading ? (
        <LoadingBlock />
      ) : (
        <ul className="divide-y text-sm">
          {NEWS_SOURCES.map((src) => {
            const st = byId.get(src.id);
            return (
              <li key={src.id} className="flex items-center justify-between gap-2 py-2">
                <a href={src.site} target="_blank" rel="noopener noreferrer" className="min-w-0 truncate font-medium hover:underline">
                  {src.name}
                </a>
                <span className="flex shrink-0 items-center gap-1 text-xs text-muted-foreground">
                  {!st ? (
                    "ainda não lida"
                  ) : st.ok ? (
                    <>
                      <CheckCircle2 className="size-4 text-success" />
                      {st.last_ok_at ? formatDistanceToNow(new Date(st.last_ok_at), { addSuffix: true, locale: ptBR }) : "ok"}
                    </>
                  ) : (
                    <>
                      <XCircle className="size-4 text-destructive" /> sem resposta
                    </>
                  )}
                </span>
              </li>
            );
          })}
        </ul>
      )}
    </Panel>
  );
}
