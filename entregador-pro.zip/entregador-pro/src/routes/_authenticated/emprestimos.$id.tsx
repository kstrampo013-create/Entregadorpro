import { createFileRoute } from "@tanstack/react-router";
import { ContractDetail } from "@/components/contract-views";

export const Route = createFileRoute("/_authenticated/emprestimos/$id")({
  head: () => ({
    meta: [
      { title: "Detalhes do empréstimo — Entregador Pro" },
      { name: "description", content: "Parcelas, pagamentos e saldo do empréstimo." },
      { property: "og:title", content: "Detalhes do empréstimo — Entregador Pro" },
      { property: "og:description", content: "Parcelas e pagamentos." },
    ],
  }),
  component: LoanDetailPage,
});

function LoanDetailPage() {
  const { id } = Route.useParams();
  return <ContractDetail kind="loan" id={id} />;
}
