import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { addMonths, eachDayOfInterval, endOfMonth, endOfWeek, format, isSameMonth, startOfMonth, startOfWeek } from "date-fns";
import { ChevronLeft, ChevronRight, Plus, Target } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageHeader, Panel, StatusBadge } from "@/components/common";
import { TaskForm } from "@/components/forms/task-form";
import { sortTasks, TaskRow } from "@/components/task-list";
import { useBillOccurrences, useContracts, useGoals } from "@/hooks/use-derived";
import { useTable } from "@/hooks/use-data";
import type { Task } from "@/lib/db";
import { dailyResults, goalDayTarget, goalPeriod, installmentStatus, isGoalWorkDay, remainingOf } from "@/lib/finance";
import { dateLong, monthLabel, money, todayISO } from "@/lib/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/calendario")({
  head: () => ({
    meta: [
      { title: "Calendário — ganho real do dia e tarefas | Entregador Pro" },
      { name: "description", content: "Todos os dias do mês com o ganho real (ganhos menos gastos), tarefas, contas e vencimentos." },
      { property: "og:title", content: "Calendário — Entregador Pro" },
      { property: "og:description", content: "Ganho real de cada dia, tarefas e compromissos do mês." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CalendarPage,
});

type EventStatus = "pago" | "pendente" | "atrasado" | "prevista" | "recebido" | "parcial";
interface CalEvent {
  date: string;
  title: string;
  kind: string;
  amount: number;
  status: EventStatus;
}

const DOT: Record<EventStatus, string> = {
  pago: "bg-success",
  recebido: "bg-success",
  parcial: "bg-highlight",
  pendente: "bg-chart-4",
  prevista: "bg-chart-4",
  atrasado: "bg-destructive",
};

function CalendarPage() {
  const [offset, setOffset] = useState(0);
  const [selected, setSelected] = useState(todayISO());
  const today = todayISO();
  const month = addMonths(new Date(), offset);
  const gridStart = startOfWeek(startOfMonth(month), { weekStartsOn: 1 });
  const gridEnd = endOfWeek(endOfMonth(month), { weekStartsOn: 1 });
  const range = { start: format(gridStart, "yyyy-MM-dd"), end: format(gridEnd, "yyyy-MM-dd") };

  const { contracts } = useContracts();
  const { occurrences } = useBillOccurrences(range);
  const expenses = useTable("expenses");
  const earnings = useTable("earnings");
  const payments = useTable("installment_payments");
  const tasks = useTable("tasks");
  const { goals } = useGoals();
  const [taskOpen, setTaskOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  const results = useMemo(
    () => dailyResults(earnings.data ?? [], expenses.data ?? [], range, today),
    [earnings.data, expenses.data, range.start, range.end, today],
  );
  const monthRange = { start: format(startOfMonth(month), "yyyy-MM-dd"), end: format(endOfMonth(month), "yyyy-MM-dd") };
  const monthTotals = useMemo(() => {
    let earned = 0;
    let spent = 0;
    for (const [d, r] of results) {
      if (d < monthRange.start || d > monthRange.end) continue;
      earned += Math.round(r.earned * 100);
      spent += Math.round(r.spent * 100);
    }
    return { earned: earned / 100, spent: spent / 100, net: (earned - spent) / 100 };
  }, [results, monthRange.start, monthRange.end]);
  const tasksByDate = useMemo(() => {
    const m = new Map<string, Task[]>();
    for (const t of sortTasks(tasks.data ?? [])) m.set(t.due_date, [...(m.get(t.due_date) ?? []), t]);
    return m;
  }, [tasks.data]);

  const events = useMemo(() => {
    const out: CalEvent[] = [];
    const instInfo = new Map<string, string>();
    for (const c of contracts) {
      for (const i of c.installments) {
        instInfo.set(i.id, `${c.name} · parcela ${i.number}`);
        if (i.due_date < range.start || i.due_date > range.end) continue;
        const st = installmentStatus(i, today);
        out.push({
          date: i.due_date,
          title: `${c.name} · parcela ${i.number}/${c.installments.length}`,
          kind: c.kind === "sale" ? "Vencimento de venda" : "Vencimento de empréstimo",
          amount: st === "pago" ? Number(i.amount) : remainingOf(i),
          status: st,
        });
      }
    }
    for (const o of occurrences) {
      out.push({ date: o.due_date, title: o.bill.name, kind: "Conta pessoal", amount: Number(o.payment?.paid_amount ?? o.bill.expected_amount), status: o.status });
    }
    for (const e of expenses.data ?? []) {
      if (e.date < range.start || e.date > range.end) continue;
      out.push({ date: e.date, title: e.description, kind: e.date > today ? "Despesa prevista" : "Despesa", amount: Number(e.amount), status: e.date > today ? "prevista" : "pago" });
    }
    for (const p of payments.data ?? []) {
      if (p.paid_on < range.start || p.paid_on > range.end) continue;
      out.push({ date: p.paid_on, title: instInfo.get(p.installment_id) ?? "Recebimento", kind: "Pagamento recebido", amount: Number(p.amount), status: "recebido" });
    }
    return out;
  }, [contracts, occurrences, expenses.data, payments.data, range.start, range.end, today]);

  const byDate = useMemo(() => {
    const m = new Map<string, CalEvent[]>();
    events.forEach((e) => m.set(e.date, [...(m.get(e.date) ?? []), e]));
    return m;
  }, [events]);

  const days = eachDayOfInterval({ start: gridStart, end: gridEnd });
  /** For each day: what each active goal asks for (future work days) — summed for the cell. */
  const goalTargets = useMemo(() => {
    const m = new Map<string, number>();
    for (const d of days) {
      const iso = format(d, "yyyy-MM-dd");
      let total = 0;
      for (const g of goals) {
        if (!g.goal.active) continue;
        const t = goalDayTarget(g.goal, g.values, iso, today);
        if (t != null) total += Math.round(t * 100);
      }
      if (total > 0) m.set(iso, total / 100);
    }
    return m;
  }, [goals, range.start, range.end, today]); // eslint-disable-line react-hooks/exhaustive-deps
  const dayGoals = goals
    .filter((g) => g.goal.active && goalPeriod(g.goal, selected))
    .map((g) => ({
      view: g,
      work: isGoalWorkDay(g.goal, selected),
      target: goalDayTarget(g.goal, g.values, selected, today),
      done: g.values.get(selected) ?? 0,
    }));
  const dayEvents = byDate.get(selected) ?? [];
  const dayTasks = tasksByDate.get(selected) ?? [];
  const dayResult = results.get(selected);

  return (
    <>
      <PageHeader
        title="Calendário"
        subtitle="Cada dia mostra o ganho real (ganhos menos gastos). Toque em um dia para ver detalhes e tarefas."
        action={
          <Button onClick={() => { setEditingTask(null); setTaskOpen(true); }} className="h-11 rounded-xl">
            <Plus /> Tarefa
          </Button>
        }
      />
      <div className="grid gap-5 lg:grid-cols-[1fr_380px]">
        <Panel>
          <div className="mb-4 flex items-center justify-between">
            <Button variant="ghost" size="icon" onClick={() => setOffset((o) => o - 1)} aria-label="Mês anterior">
              <ChevronLeft />
            </Button>
            <div className="text-center">
              <p className="font-display text-lg font-bold first-letter:uppercase">{monthLabel(format(month, "yyyy-MM-dd"))}</p>
              {offset !== 0 && (
                <button className="text-xs font-semibold text-primary" onClick={() => { setOffset(0); setSelected(today); }}>
                  Voltar para hoje
                </button>
              )}
            </div>
            <Button variant="ghost" size="icon" onClick={() => setOffset((o) => o + 1)} aria-label="Próximo mês">
              <ChevronRight />
            </Button>
          </div>
          <div className="mb-4 grid grid-cols-3 gap-2 text-center">
            <MonthStat label="Ganhos" value={money(monthTotals.earned)} />
            <MonthStat label="Gastos" value={money(monthTotals.spent)} />
            <MonthStat
              label="Ganho real"
              value={money(monthTotals.net)}
              className={monthTotals.net < 0 ? "text-destructive" : "text-success"}
            />
          </div>
          <div className="grid grid-cols-7 gap-1 text-center text-xs font-semibold text-muted-foreground">
            {["S", "T", "Q", "Q", "S", "S", "D"].map((d, i) => (
              <div key={i} className="py-1">
                {d}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {days.map((d) => {
              const iso = format(d, "yyyy-MM-dd");
              const evs = byDate.get(iso) ?? [];
              const statuses = Array.from(new Set(evs.map((e) => e.status))).slice(0, 3);
              const r = results.get(iso);
              const openTasks = (tasksByDate.get(iso) ?? []).filter((t) => !t.done).length;
              const isSel = iso === selected;
              const goalTarget = goalTargets.get(iso);
              return (
                <button
                  key={iso}
                  onClick={() => setSelected(iso)}
                  aria-label={`${format(d, "dd/MM")}${r ? `, ganho real ${money(r.net)}` : ""}${openTasks ? `, ${openTasks} tarefa(s)` : ""}${goalTarget ? `, meta do dia ${money(goalTarget)}` : ""}`}
                  className={cn(
                    "flex min-h-16 flex-col items-center justify-start gap-0.5 rounded-xl p-1 pt-1.5 text-sm transition sm:min-h-20",
                    !isSameMonth(d, month) && "opacity-40",
                    iso === selected ? "bg-primary text-primary-foreground" : "hover:bg-accent",
                    iso === today && iso !== selected && "ring-2 ring-primary",
                  )}
                >
                  <span className="font-semibold tabular">{format(d, "d")}</span>
                  {r && (
                    <span
                      className={cn(
                        "max-w-full truncate text-[10px] font-bold leading-none tabular sm:text-xs",
                        isSel ? "text-primary-foreground" : r.net < 0 ? "text-destructive" : "text-success",
                      )}
                    >
                      {compact(r.net)}
                    </span>
                  )}
                  {goalTarget != null && (
                    <span
                      className={cn(
                        "max-w-full truncate rounded px-0.5 text-[10px] font-bold leading-tight tabular sm:text-xs",
                        isSel ? "bg-primary-foreground/20 text-primary-foreground" : "bg-highlight/40 text-highlight-foreground",
                      )}
                    >
                      {compact(goalTarget).slice(1)}
                    </span>
                  )}
                  <span className="flex gap-0.5">
                    {openTasks > 0 && <span className={cn("size-1.5 rounded-full bg-chart-5", isSel && "ring-1 ring-primary-foreground")} />}
                    {statuses.map((s) => (
                      <span key={s} className={cn("size-1.5 rounded-full", DOT[s], isSel && "ring-1 ring-primary-foreground")} />
                    ))}
                  </span>
                </button>
              );
            })}
          </div>
          <div className="mt-4 flex flex-wrap gap-3 text-xs text-muted-foreground">
            <span className="font-bold text-success">+120</span>
            <span>ganho real do dia</span>
            <span className="inline-flex items-center gap-1.5">
              <span className="rounded bg-highlight/40 px-1 font-bold text-highlight-foreground">198</span> meta do dia
            </span>
            <Legend c="bg-chart-5" l="Tarefa" />
            <Legend c="bg-success" l="Pago / recebido" />
            <Legend c="bg-chart-4" l="Pendente / previsto" />
            <Legend c="bg-highlight" l="Parcial" />
            <Legend c="bg-destructive" l="Atrasado" />
          </div>
        </Panel>
        <Panel title={<span className="block first-letter:uppercase">{dateLong(selected)}</span>}>
          <div className="mb-4 rounded-xl border bg-secondary/40 p-3">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Resultado do dia</p>
            <div className="grid grid-cols-3 gap-2 text-center">
              <MonthStat label="Ganhos" value={money(dayResult?.earned ?? 0)} />
              <MonthStat label="Gastos" value={money(dayResult?.spent ?? 0)} />
              <MonthStat
                label="Ganho real"
                value={money(dayResult?.net ?? 0)}
                className={(dayResult?.net ?? 0) < 0 ? "text-destructive" : "text-success"}
              />
            </div>
          </div>
          {dayGoals.length > 0 && (
            <div className="mb-4">
              <div className="mb-2 flex items-center justify-between">
                <p className="text-sm font-semibold">Metas</p>
                <Button size="sm" variant="link" asChild className="h-auto p-0">
                  <Link to="/metas">Ver metas</Link>
                </Button>
              </div>
              <ul className="space-y-2">
                {dayGoals.map(({ view, work, target, done }) => (
                  <li key={view.goal.id}>
                    <Link
                      to="/metas/$id"
                      params={{ id: view.goal.id }}
                      className="flex items-center gap-3 rounded-xl border p-3 transition hover:bg-accent"
                    >
                      <Target className="size-4 shrink-0 text-highlight-foreground" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold">{view.goal.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {!work
                            ? "Folga nesta meta"
                            : target != null
                              ? selected === today
                                ? `Já feito hoje: ${money(done)}`
                                : "Precisa fazer neste dia"
                              : selected < today
                                ? `Feito: ${money(done)}`
                                : "Meta já batida"}
                        </p>
                      </div>
                      {work && target != null && <span className="text-sm font-bold tabular">{money(target)}</span>}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}
          <div className="mb-4">
            <div className="mb-2 flex items-center justify-between">
              <p className="text-sm font-semibold">Tarefas</p>
              <Button size="sm" variant="outline" onClick={() => { setEditingTask(null); setTaskOpen(true); }}>
                <Plus /> Adicionar
              </Button>
            </div>
            {dayTasks.length === 0 ? (
              <p className="text-sm text-muted-foreground">Nenhuma tarefa neste dia.</p>
            ) : (
              <ul className="space-y-2">
                {dayTasks.map((t) => (
                  <TaskRow key={t.id} task={t} onEdit={(x) => { setEditingTask(x); setTaskOpen(true); }} />
                ))}
              </ul>
            )}
          </div>
          <p className="mb-2 text-sm font-semibold">Compromissos e gastos</p>
          {dayEvents.length === 0 ? (
            <p className="text-sm text-muted-foreground">Nenhum compromisso neste dia.</p>
          ) : (
            <ul className="space-y-2">
              {dayEvents.map((e, i) => (
                <li key={i} className="flex items-center gap-3 rounded-xl border p-3">
                  <span className={cn("size-2.5 shrink-0 rounded-full", DOT[e.status])} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{e.title}</p>
                    <p className="text-xs text-muted-foreground">{e.kind}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold tabular">{money(e.amount)}</p>
                    <StatusBadge status={e.status} />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
      <TaskForm open={taskOpen} onOpenChange={setTaskOpen} record={editingTask} defaultDate={selected} />
    </>
  );
}

/** Short value for a calendar cell: +190, −60, +1,2 mil. */
function compact(n: number) {
  const sign = n < 0 ? "−" : "+";
  const a = Math.abs(n);
  if (a >= 1000) return `${sign}${(a / 1000).toLocaleString("pt-BR", { maximumFractionDigits: 1 })} mil`;
  return `${sign}${Math.round(a)}`;
}

function MonthStat({ label, value, className }: { label: string; value: string; className?: string }) {
  return (
    <div className="min-w-0">
      <p className="text-[11px] text-muted-foreground">{label}</p>
      <p className={cn("truncate text-sm font-bold tabular", className)}>{value}</p>
    </div>
  );
}

function Legend({ c, l }: { c: string; l: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className={cn("size-2 rounded-full", c)} /> {l}
    </span>
  );
}

