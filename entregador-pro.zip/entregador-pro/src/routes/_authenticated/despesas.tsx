import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Pencil, Plus, Receipt } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ConfirmDelete, EmptyState, LoadingBlock, PageHeader, Panel, StatCard, StatusBadge, TextInput } from "@/components/common";
import { NativeSelect } from "@/components/native-select";
import { ExpenseForm } from "@/components/forms/expense-form";
import { useDelete, useTable } from "@/hooks/use-data";
import type { EntryShortcut, Expense } from "@/lib/db";
import { ShortcutChips } from "@/components/shortcuts";
import { inRange, periodRange, sum } from "@/lib/finance";
import { dateBR, money, todayISO } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/despesas")({
  head: () => ({
    meta: [
      { title: "Despesas — Entregador Pro" },
      { name: "description", content: "Combustível, manutenção, alimentação e outras despesas do trabalho." },
      { property: "og:title", content: "Despesas — Entregador Pro" },
      { property: "og:description", content: "Controle de despesas de entregador." },
    ],
  }),
  component: ExpensesPage,
});

function ExpensesPage() {
  const { data = [], isLoading } = useTable("expenses");
  const earnings = useTable("earnings");
  const del = useDelete("expenses", "Despesa excluída");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Expense | null>(null);
  const [preset, setPreset] = useState<EntryShortcut | null>(null);
  const [month, setMonth] = useState(todayISO().slice(0, 7));
  const [category, setCategory] = useState("");
  const today = todayISO();
  const monthNow = periodRange("mes", today);
  const monthExpenses = sum(data.filter((e) => inRange(e.date, monthNow)), (e) => e.amount);
  const monthEarnings = sum((earnings.data ?? []).filter((e) => inRange(e.date, monthNow)), (e) => e.amount);

  const categories = useMemo(() => Array.from(new Set(data.map((e) => e.category))).sort(), [data]);
  const filtered = data.filter((e) => (!month || e.date.startsWith(month)) && (!category || e.category === category));
  const byCategory = useMemo(() => {
    const m = new Map<string, number>();
    filtered.forEach((e) => m.set(e.category, (m.get(e.category) ?? 0) + Number(e.amount)));
    return Array.from(m.entries()).sort((a, b) => b[1] - a[1]);
  }, [filtered]);
  const filteredTotal = sum(filtered, (e) => e.amount);

  const openNew = () => {
    setEditing(null);
    setPreset(null);
    setOpen(true);
  };

  return (
    <>
      <PageHeader
        title="Despesas"
        subtitle="Gastos do trabalho descontados dos seus ganhos."
        action={
          <Button size="lg" onClick={openNew}>
            <Plus /> Nova despesa
          </Button>
        }
      />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Hoje" value={money(sum(data.filter((e) => e.date === today), (e) => e.amount))} tone="expense" icon={<Receipt />} />
        <StatCard label="Semana" value={money(sum(data.filter((e) => inRange(e.date, periodRange("semana", today))), (e) => e.amount))} tone="expense" icon={<Receipt />} />
        <StatCard label="Despesas do mês" value={money(monthExpenses)} tone="expense" />
        <StatCard label="Lucro líquido do mês" value={money(monthEarnings - monthExpenses)} tone="brand" hint={`Ganhos ${money(monthEarnings)}`} />
      </div>

      <div className="mt-5 rounded-2xl border bg-card p-4 shadow-soft empty:hidden">
        <ShortcutChips
          kind="expense"
          onPick={(sc) => {
            setEditing(null);
            setPreset(sc);
            setOpen(true);
          }}
        />
      </div>
      <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_300px]">
        <Panel>
          <div className="mb-4 grid grid-cols-2 gap-2 sm:flex">
            <TextInput type="month" value={month} onChange={(e) => setMonth(e.target.value)} className="sm:w-48" aria-label="Mês" />
            <NativeSelect value={category} onChange={(e) => setCategory(e.target.value)} className="sm:w-56" aria-label="Categoria">
              <option value="">Todas as categorias</option>
              {categories.map((c) => (
                <option key={c}>{c}</option>
              ))}
            </NativeSelect>
          </div>
          {isLoading ? (
            <LoadingBlock />
          ) : filtered.length === 0 ? (
            <EmptyState icon={<Receipt />} title="Nenhuma despesa neste filtro" action={<Button onClick={openNew}>Registrar despesa</Button>} />
          ) : (
            <ul className="divide-y rounded-xl border">
              {filtered.map((e) => (
                <li key={e.id} className="flex items-center gap-3 p-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold">{e.description}</p>
                    <p className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                      <span>{dateBR(e.date)}</span>
                      <span className="rounded-full bg-muted px-2 py-0.5 font-medium">{e.category}</span>
                      {e.date > today && <StatusBadge status="prevista" />}
                      {e.is_demo && <span className="rounded bg-muted px-1.5 text-[10px] font-bold uppercase">demo</span>}
                    </p>
                  </div>
                  <span className="font-bold text-expense tabular">{money(e.amount)}</span>
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    aria-label="Editar"
                    onClick={() => {
                      setEditing(e);
                      setPreset(null);
                      setOpen(true);
                    }}
                  >
                    <Pencil />
                  </Button>
                  <ConfirmDelete title="Excluir esta despesa?" description={`${e.description} · ${money(e.amount)}`} onConfirm={() => del.mutate(e.id)} />
                </li>
              ))}
            </ul>
          )}
        </Panel>
        <Panel title="Por categoria">
          {byCategory.length === 0 ? (
            <p className="text-sm text-muted-foreground">Sem dados no filtro.</p>
          ) : (
            <div className="space-y-3">
              {byCategory.map(([c, v]) => (
                <div key={c}>
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">{c}</span>
                    <span className="tabular">{money(v)}</span>
                  </div>
                  <div className="mt-1 h-2 overflow-hidden rounded-full bg-muted">
                    <div className="h-full rounded-full bg-expense" style={{ width: `${filteredTotal ? (v / filteredTotal) * 100 : 0}%` }} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </Panel>
      </div>
      <ExpenseForm open={open} onOpenChange={setOpen} record={editing} preset={preset} />
    </>
  );
}
