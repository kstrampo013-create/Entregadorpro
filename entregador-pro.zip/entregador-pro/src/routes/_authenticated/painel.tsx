import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { addDays, format, parseISO, subDays, subMonths, subWeeks } from "date-fns";
import { ptBR } from "date-fns/locale";
import { AlertTriangle, BellRing, CalendarClock, Check, Gauge, HandCoins, ListTodo, MessageCircle, Plus, Receipt, Route as RouteIcon, ShoppingBag, Target, TrendingUp, Wallet } from "lucide-react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Button } from "@/components/ui/button";
import { PageHeader, Panel, SegmentedControl, StatCard } from "@/components/common";
import { EarningForm } from "@/components/forms/earning-form";
import { ExpenseForm } from "@/components/forms/expense-form";
import { ContractForm } from "@/components/forms/contract-form";
import { MonthChecklist } from "@/components/month-checklist";
import { ThassiAvatar } from "@/components/nels/nels-nav";
import { sortTasks } from "@/components/task-list";
import { useBillOccurrences, useContracts, useGoals, useOverdueBills } from "@/hooks/use-derived";
import { useQuickPay } from "@/hooks/use-quick-pay";
import { useTable } from "@/hooks/use-data";
import { useProfile } from "@/hooks/use-auth";
import { inRange, periodRange, perKm, remainingOf, sum, type PeriodKind } from "@/lib/finance";
import { dateBR, km, money, todayISO } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/painel")({
  head: () => ({
    meta: [
      { title: "Painel — Entregador Pro" },
      { name: "description", content: "Resumo dos seus ganhos, despesas, lucro e valores a receber." },
      { property: "og:title", content: "Painel — Entregador Pro" },
      { property: "og:description", content: "Seu resumo financeiro." },
    ],
  }),
  component: Dashboard,
});

const PERIOD_LABEL: Record<PeriodKind, string> = { dia: "hoje", semana: "nesta semana", mes: "neste mês" };

function Dashboard() {
  const [period, setPeriod] = useState<PeriodKind>("dia");
  const [dialog, setDialog] = useState<"earning" | "expense" | "sale" | "loan" | null>(null);
  const { data: profile } = useProfile();
  const earnings = useTable("earnings").data ?? [];
  const expenses = useTable("expenses").data ?? [];
  const payments = useTable("installment_payments").data ?? [];
  const tasks = useTable("tasks").data ?? [];
  const { contracts } = useContracts();
  const today = todayISO();
  const range = periodRange(period, today);
  const week = periodRange("semana", today);
  const month = periodRange("mes", today);
  const bills = useBillOccurrences({ start: format(subMonths(parseISO(today), 3), "yyyy-MM-dd"), end: month.end });
  const { overdue: overdueBills } = useOverdueBills();
  const { goals } = useGoals();
  const quick = useQuickPay();

  const pEarn = earnings.filter((e) => inRange(e.date, range));
  const earnTotal = sum(pEarn, (e) => e.amount);
  const expTotal = sum(expenses.filter((e) => inRange(e.date, range) && e.date <= today), (e) => e.amount);
  const kmTotal = sum(pEarn, (e) => e.km);
  const ppk = perKm(earnTotal, kmTotal);

  const receivedIn = (r: { start: string; end: string }) =>
    sum(earnings.filter((e) => inRange(e.date, r)), (e) => e.amount) + sum(payments.filter((p) => inRange(p.paid_on, r)), (p) => p.amount);
  const salesRemaining = sum(contracts.filter((c) => c.kind === "sale"), (c) => c.summary.remaining);
  const loansRemaining = sum(contracts.filter((c) => c.kind === "loan"), (c) => c.summary.remaining);
  const pendingBills = bills.occurrences.filter((o) => !o.payment);
  const pendingBillsTotal = sum(pendingBills, (o) => o.bill.expected_amount);

  const in3 = format(addDays(parseISO(today), 3), "yyyy-MM-dd");
  const allInst = contracts.flatMap((c) => c.installments.map((i) => ({ i, c })));
  const overdueInst = allInst.filter(({ i }) => remainingOf(i) > 0 && i.due_date < today);
  const soonInst = allInst.filter(({ i }) => remainingOf(i) > 0 && i.due_date >= today && i.due_date <= in3);
  const soonBills = pendingBills.filter((o) => o.due_date >= today && o.due_date <= in3);

  const chart = useMemo(() => {
    const ref = parseISO(today);
    const buckets =
      period === "dia"
        ? Array.from({ length: 7 }, (_, k) => {
            const d = format(subDays(ref, 6 - k), "yyyy-MM-dd");
            return { label: format(parseISO(d), "EEE", { locale: ptBR }), r: { start: d, end: d } };
          })
        : period === "semana"
          ? Array.from({ length: 8 }, (_, k) => {
              const r = periodRange("semana", format(subWeeks(ref, 7 - k), "yyyy-MM-dd"));
              return { label: format(parseISO(r.start), "dd/MM"), r };
            })
          : Array.from({ length: 6 }, (_, k) => {
              const r = periodRange("mes", format(subMonths(ref, 5 - k), "yyyy-MM-dd"));
              return { label: format(parseISO(r.start), "MMM", { locale: ptBR }), r };
            });
    return buckets.map((b) => ({
      label: b.label,
      Ganhos: sum(earnings.filter((e) => inRange(e.date, b.r)), (e) => e.amount),
      Despesas: sum(expenses.filter((e) => inRange(e.date, b.r)), (e) => e.amount),
    }));
  }, [earnings, expenses, period, today]);

  const first = profile?.full_name?.split(" ")[0];
  const todayTasks = sortTasks(tasks.filter((t) => !t.done && t.due_date === today));
  const alerts = overdueInst.length + overdueBills.length + soonInst.length + soonBills.length;
  const activeGoals = goals.filter((g) => g.goal.active && g.progress.status === "em_andamento");
  const goalsTodayMissing = activeGoals.reduce((s, g) => s + Math.round(g.progress.todayMissing * 100), 0) / 100;

  return (
    <>
      <PageHeader
        title={first ? `Olá, ${first}!` : "Seu painel"}
        subtitle={`Resumo ${PERIOD_LABEL[period]} · ${dateBR(today)}`}
        action={
          <SegmentedControl
            value={period}
            onChange={setPeriod}
            options={[
              { value: "dia", label: "Dia" },
              { value: "semana", label: "Semana" },
              { value: "mes", label: "Mês" },
            ]}
          />
        }
      />

      <div className="mb-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <Link
          to="/noticias/thassi"
          className="flex items-center gap-3 rounded-2xl border border-primary/30 bg-primary/5 p-3 shadow-soft transition active:scale-[0.99]"
        >
          <ThassiAvatar className="size-12" />
          <span className="min-w-0 flex-1">
            <span className="block font-display font-bold">Fale com a Thassi</span>
            <span className="block truncate text-sm text-muted-foreground">Notícias da região por texto ou voz</span>
          </span>
          <MessageCircle className="size-5 shrink-0 text-primary" />
        </Link>
        <Link to="/tarefas" className="flex items-center gap-3 rounded-2xl border bg-card p-3 shadow-soft transition active:scale-[0.99]">
          <span className="grid size-12 shrink-0 place-items-center rounded-full bg-accent/30 text-accent-foreground">
            <ListTodo className="size-5" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block font-display font-bold">Tarefas de hoje</span>
            <span className="block truncate text-sm text-muted-foreground">
              {todayTasks.length === 0
                ? "Nada marcado para hoje"
                : todayTasks
                    .slice(0, 2)
                    .map((t) => `${t.due_time ? `${t.due_time.slice(0, 5)} ` : ""}${t.title}`)
                    .join(" · ")}
            </span>
          </span>
          {todayTasks.length > 0 && (
            <span className="rounded-full bg-primary px-2 py-0.5 text-xs font-bold text-primary-foreground">{todayTasks.length}</span>
          )}
        </Link>
        <Link to="/metas" className="flex items-center gap-3 rounded-2xl border bg-card p-3 shadow-soft transition active:scale-[0.99]">
          <span className="grid size-12 shrink-0 place-items-center rounded-full bg-highlight/30 text-highlight-foreground">
            <Target className="size-5" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block font-display font-bold">Metas de hoje</span>
            <span className="block truncate text-sm text-muted-foreground">
              {goals.length === 0
                ? "Crie sua meta do mês"
                : activeGoals.length === 0
                  ? "Nenhuma meta em andamento"
                  : goalsTodayMissing > 0
                    ? `Falta ${money(goalsTodayMissing)} hoje`
                    : activeGoals.some((g) => g.progress.todayIsWorkDay)
                      ? "Meta de hoje batida!"
                      : "Hoje é folga"}
            </span>
          </span>
        </Link>
      </div>

      {alerts > 0 && (
        <div className="mb-5 space-y-2">
          {overdueBills.length > 0 && (
            <div className="rounded-2xl border border-destructive/30 bg-destructive/10 p-4 text-sm">
              <div className="mb-2 flex items-center gap-3">
                <AlertTriangle className="size-5 shrink-0 text-destructive" />
                <b className="flex-1">
                  {overdueBills.length === 1 ? "1 conta sua atrasada" : `${overdueBills.length} contas suas atrasadas`} (
                  {money(sum(overdueBills, (o) => o.bill.expected_amount))})
                </b>
                <Link to="/contas" className="text-xs font-semibold text-destructive underline-offset-2 hover:underline">
                  Ver contas
                </Link>
              </div>
              <ul className="space-y-1.5">
                {overdueBills.slice(0, 4).map((o) => (
                  <li key={o.bill.id + o.reference_month} className="flex items-center gap-2 rounded-xl bg-card/70 px-3 py-2">
                    <span className="min-w-0 flex-1">
                      <span className="block truncate font-semibold">{o.bill.name}</span>
                      <span className="block text-xs text-muted-foreground">venceu {dateBR(o.due_date)}</span>
                    </span>
                    <span className="font-bold tabular">{money(o.bill.expected_amount)}</span>
                    <Button size="sm" onClick={() => quick.payBill.mutate(o)} disabled={quick.busy}>
                      <Check /> Pago
                    </Button>
                  </li>
                ))}
              </ul>
              {overdueBills.length > 4 && <p className="mt-2 text-xs">e mais {overdueBills.length - 4} em Contas mensais.</p>}
            </div>
          )}
          {overdueInst.length > 0 && (
            <Link to="/carteira" className="flex items-center gap-3 rounded-2xl border border-destructive/30 bg-destructive/10 p-4 text-sm">
              <AlertTriangle className="size-5 shrink-0 text-destructive" />
              <span>
                <b>Para receber em atraso:</b> {overdueInst.length} parcela(s) ({money(sum(overdueInst, ({ i }) => remainingOf(i)))})
              </span>
            </Link>
          )}
          {(soonInst.length > 0 || soonBills.length > 0) && (
            <Link to="/calendario" className="flex items-center gap-3 rounded-2xl border border-warning/40 bg-warning/10 p-4 text-sm">
              <BellRing className="size-5 shrink-0 text-warning" />
              <span>
                <b>Vence em até 3 dias:</b> {soonInst.length > 0 && `${soonInst.length} recebimento(s)`}
                {soonInst.length > 0 && soonBills.length > 0 && " e "}
                {soonBills.length > 0 && `${soonBills.length} conta(s): ${soonBills.map((o) => o.bill.name).join(", ")}`}
              </span>
            </Link>
          )}
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">
        <StatCard label={`Lucro líquido ${PERIOD_LABEL[period]}`} value={money(earnTotal - expTotal)} tone="brand" className="col-span-2 lg:col-span-1" hint={`${money(earnTotal)} − ${money(expTotal)}`} />
        <StatCard label="Ganhos" value={money(earnTotal)} tone="income" icon={<TrendingUp />} />
        <StatCard label="Despesas" value={money(expTotal)} tone="expense" icon={<Receipt />} />
        <StatCard label="Km rodados" value={km(kmTotal)} icon={<RouteIcon />} />
        <StatCard label="Ganho por km" value={ppk != null ? money(ppk) : "—"} icon={<Gauge />} hint={ppk == null ? "Informe km nos ganhos" : undefined} />
        <StatCard label="Recebido na semana" value={money(receivedIn(week))} hint="Ganhos + parcelas recebidas" tone="income" />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_340px]">
        <Panel title="Ganhos x despesas">
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart} margin={{ top: 4, right: 4, left: -16, bottom: 0 }}>
                <CartesianGrid vertical={false} stroke="var(--color-border)" />
                <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={12} stroke="var(--color-muted-foreground)" />
                <YAxis tickLine={false} axisLine={false} fontSize={11} stroke="var(--color-muted-foreground)" />
                <Tooltip
                  formatter={(v: number) => money(v)}
                  cursor={{ fill: "var(--color-muted)" }}
                  contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 12, color: "var(--color-popover-foreground)" }}
                />
                <Bar dataKey="Ganhos" fill="var(--color-income)" radius={[6, 6, 0, 0]} />
                <Bar dataKey="Despesas" fill="var(--color-expense)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Panel>
        <Panel title="Ações rápidas">
          <div className="grid grid-cols-2 gap-2">
            <QuickAction icon={<TrendingUp />} label="Ganho" onClick={() => setDialog("earning")} />
            <QuickAction icon={<Receipt />} label="Despesa" onClick={() => setDialog("expense")} />
            <QuickAction icon={<ShoppingBag />} label="Venda" onClick={() => setDialog("sale")} />
            <QuickAction icon={<HandCoins />} label="Empréstimo" onClick={() => setDialog("loan")} />
          </div>
        </Panel>
      </div>

      <div className="mt-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Recebido no mês" value={money(receivedIn(month))} tone="income" />
        <StatCard label="Vendas a receber" value={money(salesRemaining)} icon={<ShoppingBag />} />
        <StatCard label="Empréstimos a receber" value={money(loansRemaining)} icon={<Wallet />} />
        <StatCard label="Contas pendentes" value={money(pendingBillsTotal)} icon={<CalendarClock />} hint={`${pendingBills.length} até o fim do mês`} tone="highlight" />
      </div>

      <div className="mt-5">
        <MonthChecklist />
      </div>

      <Panel className="mt-5" title="Próximos recebimentos" action={<Button variant="link" asChild><Link to="/carteira">Ver carteira</Link></Button>}>
        {allInst.filter(({ i }) => remainingOf(i) > 0).length === 0 ? (
          <p className="text-sm text-muted-foreground">Nenhum valor a receber. Cadastre uma venda ou empréstimo.</p>
        ) : (
          <ul className="divide-y">
            {allInst
              .filter(({ i }) => remainingOf(i) > 0)
              .sort((a, b) => a.i.due_date.localeCompare(b.i.due_date))
              .slice(0, 5)
              .map(({ i, c }) => (
                <li key={i.id} className="flex items-center justify-between gap-3 py-2.5 text-sm">
                  <div className="min-w-0">
                    <p className="truncate font-semibold">{c.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {c.kind === "sale" ? "Venda" : "Empréstimo"} · parcela {i.number} · {dateBR(i.due_date)}
                    </p>
                  </div>
                  <span className={i.due_date < today ? "font-bold text-destructive tabular" : "font-bold tabular"}>{money(remainingOf(i))}</span>
                </li>
              ))}
          </ul>
        )}
      </Panel>

      <EarningForm open={dialog === "earning"} onOpenChange={(o) => !o && setDialog(null)} />
      <ExpenseForm open={dialog === "expense"} onOpenChange={(o) => !o && setDialog(null)} />
      <ContractForm kind="sale" open={dialog === "sale"} onOpenChange={(o) => !o && setDialog(null)} />
      <ContractForm kind="loan" open={dialog === "loan"} onOpenChange={(o) => !o && setDialog(null)} />
    </>
  );
}

function QuickAction({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex min-h-20 flex-col items-center justify-center gap-1.5 rounded-xl border bg-secondary/50 text-sm font-semibold transition hover:bg-secondary [&_svg]:size-5 [&_svg]:text-primary"
    >
      <span className="flex items-center gap-1">
        <Plus className="!size-3.5" />
        {icon}
      </span>
      {label}
    </button>
  );
}
