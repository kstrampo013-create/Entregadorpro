import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Loader2, MessageCircle, Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { ConfirmDelete, EmptyState, LoadingBlock } from "@/components/common";
import { NelsHeader } from "@/components/nels/nels-nav";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { createThread, newsKeys, useThreads } from "@/hooks/use-news";

export const Route = createFileRoute("/_authenticated/noticias/thassi/")({
  head: () => ({
    meta: [
      { title: "Thassi — Conversas | Nels Nere" },
      { name: "description", content: "Pergunte à Thassi sobre as notícias do Sul Fluminense, por texto ou voz." },
      { property: "og:title", content: "Thassi — assistente de notícias do Nels Nere" },
      { property: "og:description", content: "Converse com a Thassi sobre notícias de Volta Redonda e região." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ThreadsPage,
});

function ThreadsPage() {
  const { user } = useAuth();
  const { data = [], isLoading } = useThreads();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [creating, setCreating] = useState(false);

  async function start() {
    if (!user) return;
    setCreating(true);
    try {
      const id = await createThread(user.id);
      await qc.invalidateQueries({ queryKey: newsKeys.threads });
      navigate({ to: "/noticias/thassi/$threadId", params: { threadId: id } });
    } catch {
      toast.error("Não consegui abrir uma nova conversa. Tente de novo.");
      setCreating(false);
    }
  }

  async function remove(id: string) {
    const { error } = await supabase.from("chat_threads").delete().eq("id", id);
    if (error) toast.error("Não consegui apagar a conversa.");
    else toast.success("Conversa apagada");
    await qc.invalidateQueries({ queryKey: newsKeys.threads });
  }

  return (
    <>
      <NelsHeader
        subtitle="Converse com a Thassi por texto ou voz"
        action={
          <Button onClick={start} disabled={creating} className="h-11 rounded-xl">
            {creating ? <Loader2 className="size-4 animate-spin" /> : <Plus className="size-4" />}
            Nova conversa
          </Button>
        }
      />
      {isLoading ? (
        <LoadingBlock />
      ) : data.length === 0 ? (
        <EmptyState
          icon={<MessageCircle />}
          title="Nenhuma conversa ainda"
          text="Pergunte, por exemplo: “Como está o trânsito na Dutra hoje?” ou “O que aconteceu em Barra Mansa?”"
          action={
            <Button onClick={start} disabled={creating}>
              Começar a conversar
            </Button>
          }
        />
      ) : (
        <ul className="space-y-2">
          {data.map((t) => (
            <li key={t.id} className="flex items-center gap-2 rounded-2xl border bg-card p-2 pl-4 shadow-soft">
              <Link
                to="/noticias/thassi/$threadId"
                params={{ threadId: t.id }}
                className="min-w-0 flex-1 py-2"
              >
                <p className="truncate font-semibold">{t.title}</p>
                <p className="text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(t.updated_at), { addSuffix: true, locale: ptBR })}
                </p>
              </Link>
              <ConfirmDelete title="Apagar esta conversa?" onConfirm={() => remove(t.id)} />
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
