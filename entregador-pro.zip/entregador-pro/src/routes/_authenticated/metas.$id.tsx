import { useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation } from "@tanstack/react-query";
import { addMonths, eachDayOfInterval, endOfMonth, endOfWeek, format, isSameMonth, parseISO, startOfMonth, startOfWeek } from "date-fns";
import { toast } from "sonner";
import { Archive, ArchiveRestore, ArrowLeft, ChevronLeft, ChevronRight, Pencil, PiggyBank } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ConfirmDelete, EmptyState, Field, FormDialog, LoadingBlock, MoneyInput, PageHeader, Panel, StatCard, TextInput } from "@/components/common";
import { BASIS_LABEL, GoalForm, WEEKDAYS } from "@/components/forms/goal-form";
import { GOAL_STATUS_LABEL, ProgressBar, todayLine } from "@/components/goal-card";
import { supabase } from "@/integrations/supabase/client";
import { useDelete, useInsert, useInvalidateAll, useTable, useUpdate } from "@/hooks/use-data";
import { useGoals } from "@/hooks/use-derived";
import { errorMessage, newId, type Goal } from "@/lib/db";
import { goalDayTarget, goalPeriod, isGoalWorkDay, toggleGoalDay, type GoalBasis } from "@/lib/finance";
import { dateBR, monthLabel, money, parseMoney, todayISO } from "@/lib/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/metas/$id")({
  head: () => ({
    meta: [
      { title: "Detalhes da meta — Entregador Pro" },
      { name: "description", content: "Progresso da meta, dias de trabalho e quanto fazer em cada dia." },
      { property: "og:title", content: "Detalhes da meta — Entregador Pro" },
      { property: "og:description", content: "Progresso e calendário da meta." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: GoalDetailPage,
});

function GoalDetailPage() {
  const { id } = Route.useParams();
  const { goals, isLoading } = useGoals();
  const view = goals.find((g) => g.goal.id === id);
  const navigate = useNavigate();
  const del = useDelete("goals", "Meta excluída");
  const update = useUpdate("goals");
  const [editing, setEditing] = useState(false);

  if (isLoading) return <LoadingBlock />;
  if (!view)
    return (
      <EmptyState
        title="Meta não encontrada"
        text="Ela pode ter sido excluída."
        action={
          <Button asChild>
            <Link to="/metas">Ver metas</Link>
          </Button>
        }
      />
    );

  const { goal: g, progress: p } = view;
  const t = todayLine(view);

  return (
    <>
      <Button variant="ghost" asChild className="mb-2 -ml-2">
        <Link to="/metas">
          <ArrowLeft /> Metas
        </Link>
      </Button>
      <PageHeader
        title={g.name}
        subtitle={
          g.kind === "mensal"
            ? `Meta mensal de ${money(g.target_amount)} · conta: ${BASIS_LABEL[g.basis as GoalBasis].toLowerCase()}`
            : `${money(g.target_amount)} de ${dateBR(g.start_date)} a ${dateBR(g.end_date)} · conta: ${BASIS_LABEL[g.basis as GoalBasis].toLowerCase()}`
        }
        action={
          <div className="flex gap-1">
            <Button variant="outline" size="icon" aria-label="Editar meta" onClick={() => setEditing(true)}>
              <Pencil />
            </Button>
            <Button
              variant="outline"
              size="icon"
              aria-label={g.active ? "Arquivar meta" : "Reativar meta"}
              onClick={() => update.mutate({ id: g.id, values: { active: !g.active } })}
            >
              {g.active ? <Archive /> : <ArchiveRestore />}
            </Button>
            <ConfirmDelete
              title="Excluir esta meta?"
              description="Os valores guardados nela também serão apagados. Seus ganhos e gastos não mudam."
              onConfirm={() => del.mutate(g.id, { onSuccess: () => navigate({ to: "/metas" }) })}
            />
          </div>
        }
      />

      <Panel className="mb-5">
        <div className="mb-1.5 flex items-baseline justify-between gap-2">
          <span className="font-display text-2xl font-bold tabular">{money(p.achieved)}</span>
          <span className="text-sm text-muted-foreground tabular">
            de {money(p.target)} · {p.pct}%
          </span>
        </div>
        <ProgressBar pct={p.pct} className="h-3" />
        <p className="mt-2 text-xs text-muted-foreground first-letter:uppercase">
          {g.kind === "mensal" ? monthLabel(p.period.start) : `${dateBR(p.period.start)} a ${dateBR(p.period.end)}`} · {GOAL_STATUS_LABEL[p.status]}
        </p>
        <p
          className={cn(
            "mt-3 rounded-xl px-3 py-2.5 font-semibold",
            t.tone === "ok" && "bg-success/12 text-success",
            t.tone === "todo" && "bg-highlight/25 text-highlight-foreground",
            t.tone === "muted" && "bg-muted text-muted-foreground",
          )}
        >
          {t.text}
          {p.todayIsWorkDay && p.todayDone > 0 && p.todayMissing > 0 && <span className="font-normal"> · já fez {money(p.todayDone)}</span>}
        </p>
      </Panel>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Por dia de trabalho" value={p.perDay != null ? money(p.perDay) : "—"} tone="brand" hint={`${p.workDaysLeft} de ${p.workDays} dias restantes`} />
        <StatCard label="Falta" value={money(p.remaining)} tone="highlight" />
        {g.kind === "objetivo" ? (
          <StatCard label="Por mês" value={p.perMonth != null ? money(p.perMonth) : "—"} hint={`${p.monthsLeft} mês(es) restante(s)`} />
        ) : (
          <StatCard label="Meta do mês" value={money(p.target)} hint={`até ${dateBR(p.period.end)}`} />
        )}
        <StatCard label="Já feito" value={money(p.achieved)} tone="income" />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_360px]">
        <WorkDaysCalendar goal={g} values={view.values} />
        <div className="space-y-5">
          {g.basis === "guardado" ? (
            <Contributions goal={g} />
          ) : (
            <Panel title="Como a meta se atualiza">
              <p className="text-sm text-muted-foreground">
                {g.basis === "lucro"
                  ? "Conta o ganho real de cada dia: seus ganhos menos os gastos já feitos. É só lançar normalmente em Ganhos e Despesas."
                  : "Conta todos os ganhos que você lançar em Ganhos. Os gastos não entram."}
              </p>
              <p className="mt-2 text-sm text-muted-foreground">
                Se um dia render menos, o valor dos próximos dias aumenta. Se render mais, ele diminui.
              </p>
            </Panel>
          )}
          <Panel title="Dias de trabalho">
            <p className="text-sm">
              Normalmente:{" "}
              <b>{WEEKDAYS.filter((d) => g.work_weekdays.includes(d.value)).map((d) => d.label.slice(0, 3)).join(", ") || "nenhum dia"}</b>
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              {g.extra_days.length} dia(s) extra marcados · {g.off_days.length} folga(s) marcadas
            </p>
          </Panel>
        </div>
      </div>
      <GoalForm open={editing} onOpenChange={setEditing} record={g} />
    </>
  );
}

/** Month grid: tap a day to mark it as work day or day off. Future work days show what must be made that day. */
function WorkDaysCalendar({ goal, values }: { goal: Goal; values: Map<string, number> }) {
  const today = todayISO();
  const invalidate = useInvalidateAll();
  const initialOffset = useMemo(() => {
    const start = parseISO(goal.start_date);
    const now = new Date();
    return start > now ? (start.getFullYear() - now.getFullYear()) * 12 + start.getMonth() - now.getMonth() : 0;
  }, [goal.start_date]);
  const [offset, setOffset] = useState(initialOffset);
  const [days, setDays] = useState({ extra_days: goal.extra_days, off_days: goal.off_days });
  const pending = useRef(0);
  useEffect(() => {
    if (pending.current === 0) setDays({ extra_days: goal.extra_days, off_days: goal.off_days });
  }, [goal.extra_days, goal.off_days]);

  const save = useMutation({
    mutationFn: async (next: { extra_days: string[]; off_days: string[] }) => {
      const { error } = await supabase.from("goals").update(next).eq("id", goal.id);
      if (error) throw error;
    },
    onSettled: () => {
      pending.current -= 1;
      if (pending.current === 0) invalidate();
    },
    onError: (e) => toast.error(errorMessage(e)),
  });

  const local = { ...goal, ...days };
  const month = addMonths(new Date(), offset);
  const grid = eachDayOfInterval({ start: startOfWeek(startOfMonth(month), { weekStartsOn: 1 }), end: endOfWeek(endOfMonth(month), { weekStartsOn: 1 }) });

  function toggle(date: string) {
    const next = toggleGoalDay(local, date);
    setDays(next);
    pending.current += 1;
    save.mutate(next);
  }

  return (
    <Panel
      title="Calendário da meta"
      action={
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon-sm" aria-label="Mês anterior" onClick={() => setOffset((o) => o - 1)}>
            <ChevronLeft />
          </Button>
          <span className="inline-block min-w-28 text-center text-sm font-semibold first-letter:uppercase">{monthLabel(format(month, "yyyy-MM-dd"))}</span>
          <Button variant="ghost" size="icon-sm" aria-label="Próximo mês" onClick={() => setOffset((o) => o + 1)}>
            <ChevronRight />
          </Button>
        </div>
      }
    >
      <p className="mb-3 text-sm text-muted-foreground">Toque em um dia para marcar se vai trabalhar ou folgar. O valor de cada dia se ajusta sozinho.</p>
      <div className="grid grid-cols-7 gap-1 text-center text-xs font-semibold text-muted-foreground">
        {["S", "T", "Q", "Q", "S", "S", "D"].map((d, i) => (
          <div key={i} className="py-1">
            {d}
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {grid.map((d) => {
          const iso = format(d, "yyyy-MM-dd");
          const inGoal = !!goalPeriod(local, iso);
          const work = inGoal && isGoalWorkDay(local, iso);
          const target = inGoal ? goalDayTarget(local, values, iso, today) : null;
          const done = values.get(iso);
          const past = iso < today;
          return (
            <button
              key={iso}
              type="button"
              disabled={!inGoal}
              onClick={() => toggle(iso)}
              aria-pressed={work}
              aria-label={`${format(d, "dd/MM")}: ${work ? "dia de trabalho" : "folga"}${target != null ? `, fazer ${money(target)}` : ""}${done != null ? `, feito ${money(done)}` : ""}`}
              className={cn(
                "flex min-h-16 flex-col items-center justify-start gap-0.5 rounded-xl border p-1 pt-1.5 text-sm transition sm:min-h-20",
                !isSameMonth(d, month) && "opacity-40",
                !inGoal && "cursor-default border-transparent opacity-30",
                inGoal && work && "border-primary/40 bg-primary/10",
                inGoal && !work && "border-dashed bg-transparent",
                iso === today && "ring-2 ring-primary",
              )}
            >
              <span className={cn("font-semibold tabular", !work && inGoal && "text-muted-foreground")}>{format(d, "d")}</span>
              {target != null && <span className="max-w-full truncate rounded bg-highlight/40 px-1 text-[10px] font-bold leading-tight text-highlight-foreground tabular sm:text-xs">{compact(target)}</span>}
              {done != null && (past || iso === today) && (
                <span className={cn("max-w-full truncate text-[10px] font-bold leading-none tabular sm:text-xs", done < 0 ? "text-destructive" : "text-success")}>
                  {done < 0 ? "−" : "+"}
                  {compact(Math.abs(done))}
                </span>
              )}
              {inGoal && !work && <span className="text-[9px] text-muted-foreground sm:text-[10px]">folga</span>}
            </button>
          );
        })}
      </div>
      <div className="mt-4 flex flex-wrap gap-3 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1.5">
          <span className="rounded bg-highlight/40 px-1 font-bold text-highlight-foreground">198</span> precisa fazer no dia
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="font-bold text-success">+120</span> já feito
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="size-3 rounded border border-primary/40 bg-primary/10" /> dia de trabalho
        </span>
      </div>
    </Panel>
  );
}

function compact(n: number) {
  if (n >= 1000) return `${(n / 1000).toLocaleString("pt-BR", { maximumFractionDigits: 1 })} mil`;
  return String(Math.ceil(n));
}

function Contributions({ goal }: { goal: Goal }) {
  const all = useTable("goal_contributions").data ?? [];
  const mine = all.filter((c) => c.goal_id === goal.id).sort((a, b) => b.date.localeCompare(a.date));
  const del = useDelete("goal_contributions", "Valor removido");
  const insert = useInsert("goal_contributions", "Valor guardado na meta");
  const [open, setOpen] = useState(false);
  const [id, setId] = useState(newId());
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(todayISO());
  const [notes, setNotes] = useState("");
  const [error, setError] = useState<string | null>(null);

  function start() {
    setId(newId());
    setAmount("");
    setDate(todayISO());
    setNotes("");
    setError(null);
    setOpen(true);
  }
  function submit() {
    const v = parseMoney(amount);
    if (!(v > 0)) return setError("Informe o valor guardado");
    insert.mutate({ id, goal_id: goal.id, amount: v, date, notes: notes.trim() || null }, { onSuccess: () => setOpen(false) });
  }

  return (
    <Panel
      title="Dinheiro guardado"
      action={
        <Button size="sm" onClick={start}>
          <PiggyBank /> Guardar
        </Button>
      }
    >
      {mine.length === 0 ? (
        <p className="text-sm text-muted-foreground">Toque em "Guardar" sempre que separar um valor para esta meta.</p>
      ) : (
        <ul className="divide-y">
          {mine.map((c) => (
            <li key={c.id} className="flex items-center gap-2 py-2 text-sm">
              <div className="min-w-0 flex-1">
                <p className="font-semibold tabular">{money(c.amount)}</p>
                <p className="truncate text-xs text-muted-foreground">
                  {dateBR(c.date)}
                  {c.notes && ` · ${c.notes}`}
                </p>
              </div>
              <ConfirmDelete title="Remover este valor?" onConfirm={() => del.mutate(c.id)} />
            </li>
          ))}
        </ul>
      )}
      <FormDialog open={open} onOpenChange={setOpen} title={`Guardar para ${goal.name}`} onSubmit={submit} pending={insert.isPending} submitLabel="Guardar">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Valor" error={error ?? undefined}>
            <MoneyInput value={amount} onChange={(e) => setAmount(e.target.value)} autoFocus />
          </Field>
          <Field label="Data">
            <TextInput type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
        </div>
        <Field label="Observação (opcional)">
          <TextInput value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={500} />
        </Field>
      </FormDialog>
    </Panel>
  );
}
