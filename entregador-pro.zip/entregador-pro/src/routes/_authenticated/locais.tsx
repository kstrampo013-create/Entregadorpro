import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { MapPin, Pencil, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ConfirmDelete, EmptyState, LoadingBlock, PageHeader, TextInput } from "@/components/common";
import { WorkplaceForm } from "@/components/forms/workplace-form";
import { supabase } from "@/integrations/supabase/client";
import { useDelete, useTable } from "@/hooks/use-data";
import { PHOTO_BUCKET, useSignedUrls } from "@/hooks/use-photos";
import type { Workplace } from "@/lib/db";
import { sum } from "@/lib/finance";
import { dateBR, money } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/locais")({
  head: () => ({
    meta: [
      { title: "Locais de trabalho — Entregador Pro" },
      { name: "description", content: "Cadastre os locais onde você trabalha, com foto e aplicativo usado." },
      { property: "og:title", content: "Locais de trabalho — Entregador Pro" },
      { property: "og:description", content: "Seus pontos de trabalho." },
    ],
  }),
  component: WorkplacesPage,
});

function WorkplacesPage() {
  const { data = [], isLoading } = useTable("workplaces");
  const earnings = useTable("earnings");
  const del = useDelete("workplaces", "Local excluído");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Workplace | null>(null);
  const [q, setQ] = useState("");
  const photos = useSignedUrls(data.map((w) => w.photo_path).filter((p): p is string => !!p));
  const shown = data.filter((w) => !q || `${w.name} ${w.address ?? ""} ${w.app_used ?? ""}`.toLowerCase().includes(q.toLowerCase()));

  function remove(w: Workplace) {
    del.mutate(w.id, {
      onSuccess: () => {
        if (w.photo_path) supabase.storage.from(PHOTO_BUCKET).remove([w.photo_path]);
      },
    });
  }

  return (
    <>
      <PageHeader
        title="Locais de trabalho"
        subtitle="Onde você costuma rodar. Vincule ganhos a um local para comparar resultados."
        action={
          <Button
            size="lg"
            onClick={() => {
              setEditing(null);
              setOpen(true);
            }}
          >
            <Plus /> Novo local
          </Button>
        }
      />
      {data.length > 3 && <TextInput placeholder="Buscar local…" value={q} onChange={(e) => setQ(e.target.value)} className="mb-4 max-w-sm" />}
      {isLoading ? (
        <LoadingBlock />
      ) : shown.length === 0 ? (
        <EmptyState icon={<MapPin />} title="Nenhum local salvo" text="Adicione seu primeiro ponto de trabalho com foto." action={<Button onClick={() => setOpen(true)}>Adicionar local</Button>} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {shown.map((w) => {
            const url = w.photo_path ? photos.data?.[w.photo_path] : null;
            const rows = (earnings.data ?? []).filter((e) => e.workplace_id === w.id);
            return (
              <article key={w.id} className="overflow-hidden rounded-2xl border bg-card shadow-soft">
                <div className="aspect-video bg-muted">
                  {url ? (
                    <img src={url} alt={w.name} loading="lazy" className="h-full w-full object-cover" />
                  ) : (
                    <div className="grid h-full place-items-center text-muted-foreground">
                      <MapPin className="size-8" />
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h3 className="truncate font-semibold">{w.name}</h3>
                      {w.address && <p className="truncate text-sm text-muted-foreground">{w.address}</p>}
                    </div>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="icon-sm"
                        aria-label="Editar"
                        onClick={() => {
                          setEditing(w);
                          setOpen(true);
                        }}
                      >
                        <Pencil />
                      </Button>
                      <ConfirmDelete title="Excluir este local?" description="Os ganhos vinculados continuam salvos, só perdem o vínculo." onConfirm={() => remove(w)} />
                    </div>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2 text-xs">
                    {w.app_used && <span className="rounded-full bg-secondary px-2 py-0.5 font-medium text-secondary-foreground">{w.app_used}</span>}
                    {w.start_date && <span className="rounded-full bg-muted px-2 py-0.5">Desde {dateBR(w.start_date)}</span>}
                    <span className="rounded-full bg-muted px-2 py-0.5">
                      {rows.length} ganhos · {money(sum(rows, (r) => r.amount))}
                    </span>
                  </div>
                  {w.notes && <p className="mt-2 text-sm text-muted-foreground">{w.notes}</p>}
                </div>
              </article>
            );
          })}
        </div>
      )}
      <WorkplaceForm open={open} onOpenChange={setOpen} record={editing} />
    </>
  );
}
