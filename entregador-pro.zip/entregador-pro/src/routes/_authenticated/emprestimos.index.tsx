import { createFileRoute } from "@tanstack/react-router";
import { ContractList } from "@/components/contract-views";

export const Route = createFileRoute("/_authenticated/emprestimos/")({
  head: () => ({
    meta: [
      { title: "Empréstimos — Entregador Pro" },
      { name: "description", content: "Controle dinheiro emprestado, juros opcionais e pagamentos." },
      { property: "og:title", content: "Empréstimos — Entregador Pro" },
      { property: "og:description", content: "Empréstimos e parcelas." },
    ],
  }),
  component: () => <ContractList kind="loan" />,
});
