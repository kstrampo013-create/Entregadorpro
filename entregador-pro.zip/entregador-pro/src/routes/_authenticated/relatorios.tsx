import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { differenceInCalendarDays, format, parseISO, subDays } from "date-fns";
import { ArrowDownRight, ArrowUpRight, FileDown, FileSpreadsheet, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Field, PageHeader, Panel, StatusBadge, TextInput } from "@/components/common";
import { computeBillOccurrences, useContracts } from "@/hooks/use-derived";
import { useTable } from "@/hooks/use-data";
import { inRange, periodRange, perKm, previousPeriod, remainingOf, sum, type Range } from "@/lib/finance";
import { dateBR, km, money, todayISO } from "@/lib/format";
import { downloadCSV, downloadPDF } from "@/lib/export";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/relatorios")({
  head: () => ({
    meta: [
      { title: "Calculadora e relatórios — Entregador Pro" },
      { name: "description", content: "Totais por período, comparação entre semanas e meses e exportação em PDF ou CSV." },
      { property: "og:title", content: "Calculadora e relatórios — Entregador Pro" },
      { property: "og:description", content: "Relatórios financeiros do entregador." },
    ],
  }),
  component: ReportsPage,
});

type Preset = "semana" | "semana_ant" | "mes" | "mes_ant" | "custom";

function ReportsPage() {
  const today = todayISO();
  const [preset, setPreset] = useState<Preset>("semana");
  const [custom, setCustom] = useState<Range>(periodRange("mes", today));
  const [compare, setCompare] = useState(true);
  const [busy, setBusy] = useState(false);
  const [earnSel, setEarnSel] = useState<string[]>([]);
  const [expSel, setExpSel] = useState<string[]>([]);

  const range: Range =
    preset === "semana"
      ? periodRange("semana", today)
      : preset === "semana_ant"
        ? previousPeriod("semana", today)
        : preset === "mes"
          ? periodRange("mes", today)
          : preset === "mes_ant"
            ? previousPeriod("mes", today)
            : custom;

  const prevRange: Range = useMemo(() => {
    if (preset === "semana" || preset === "semana_ant") return previousPeriod("semana", range.start);
    if (preset === "mes" || preset === "mes_ant") return previousPeriod("mes", range.start);
    const days = differenceInCalendarDays(parseISO(range.end), parseISO(range.start)) + 1;
    const end = subDays(parseISO(range.start), 1);
    return { start: format(subDays(end, days - 1), "yyyy-MM-dd"), end: format(end, "yyyy-MM-dd") };
  }, [preset, range.start, range.end]);

  const earnings = useTable("earnings").data ?? [];
  const expenses = useTable("expenses").data ?? [];
  const payments = useTable("installment_payments").data ?? [];
  const bills = useTable("bills").data ?? [];
  const billPayments = useTable("bill_payments").data ?? [];
  const { contracts } = useContracts();

  const earnTopics = useMemo(() => Array.from(new Set(earnings.map((e) => e.source))).sort(), [earnings]);
  const expTopics = useMemo(() => Array.from(new Set(expenses.map((e) => e.category))).sort(), [expenses]);
  const topicFilterOn = earnSel.length > 0 || expSel.length > 0;

  function compute(r: Range) {
    const e = earnings.filter((x) => inRange(x.date, r) && (earnSel.length === 0 || earnSel.includes(x.source)));
    const x = expenses.filter((y) => inRange(y.date, r) && (expSel.length === 0 || expSel.includes(y.category)));
    const p = payments.filter((y) => inRange(y.paid_on, r));
    const earn = sum(e, (y) => y.amount);
    const exp = sum(x, (y) => y.amount);
    const kmT = sum(e, (y) => y.km);
    const dueInPeriod = contracts.flatMap((c) => c.installments).filter((i) => inRange(i.due_date, r));
    return {
      e,
      x,
      p,
      earn,
      exp,
      net: earn - exp,
      km: kmT,
      ppk: perKm(earn, kmT),
      received: sum(p, (y) => y.amount),
      dueRemaining: sum(dueInPeriod, (i) => remainingOf(i)),
    };
  }

  const cur = compute(range);
  const prev = compute(prevRange);
  const totalRemaining = sum(contracts, (c) => c.summary.remaining);
  const allEarnInRange = earnings.filter((x) => inRange(x.date, range));
  const allExpInRange = expenses.filter((x) => inRange(x.date, range));
  const earnByTopic = earnTopics
    .map((t) => {
      const rows = allEarnInRange.filter((e) => e.source === t);
      const total = sum(rows, (e) => e.amount);
      const kmT = sum(rows, (e) => e.km);
      return { topic: t, count: rows.length, total, km: kmT, ppk: perKm(total, kmT) };
    })
    .filter((t) => t.count > 0)
    .sort((a, b) => b.total - a.total);
  const expByTopic = expTopics
    .map((t) => {
      const rows = allExpInRange.filter((e) => e.category === t);
      return { topic: t, count: rows.length, total: sum(rows, (e) => e.amount) };
    })
    .filter((t) => t.count > 0)
    .sort((a, b) => b.total - a.total);
  const toggle = (list: string[], set: (v: string[]) => void, t: string) => set(list.includes(t) ? list.filter((x) => x !== t) : [...list, t]);
  const periodBills = computeBillOccurrences(bills, billPayments, range, today);

  const rows: { label: string; cur: number | null; prev: number | null; fmt: (n: number | null) => string; good: "up" | "down" }[] = [
    { label: "Ganhos", cur: cur.earn, prev: prev.earn, fmt: (n) => money(n), good: "up" },
    { label: "Despesas", cur: cur.exp, prev: prev.exp, fmt: (n) => money(n), good: "down" },
    { label: "Lucro líquido", cur: cur.net, prev: prev.net, fmt: (n) => money(n), good: "up" },
    { label: "Km rodados", cur: cur.km, prev: prev.km, fmt: (n) => km(n), good: "up" },
    { label: "Ganho por km", cur: cur.ppk, prev: prev.ppk, fmt: (n) => (n == null ? "—" : money(n)), good: "up" },
    { label: "Recebido de clientes", cur: cur.received, prev: prev.received, fmt: (n) => money(n), good: "up" },
    { label: "A receber (vencendo no período)", cur: cur.dueRemaining, prev: prev.dueRemaining, fmt: (n) => money(n), good: "down" },
  ];

  const label = `${dateBR(range.start)} a ${dateBR(range.end)}`;

  function exportCSV() {
    const lines: unknown[][] = [
      ...cur.e.map((e) => ["Ganho", dateBR(e.date), e.source, "", Number(e.amount), e.km ?? "", e.hours ?? "", e.notes ?? ""]),
      ...cur.x.map((e) => ["Despesa", dateBR(e.date), e.description, e.category, -Number(e.amount), "", "", e.notes ?? ""]),
      ...cur.p.map((p) => ["Recebimento de parcela", dateBR(p.paid_on), p.notes ?? "", "", Number(p.amount), "", "", ""]),
    ];
    downloadCSV(`entregador-pro_${range.start}_${range.end}.csv`, ["Tipo", "Data", "Descrição/Fonte", "Categoria", "Valor (R$)", "Km", "Horas", "Observações"], lines);
  }

  async function exportPDF() {
    setBusy(true);
    try {
      await downloadPDF(
        `entregador-pro_${range.start}_${range.end}.pdf`,
        "Entregador Pro — Relatório",
        `Período: ${label}${topicFilterOn ? ` · Tópicos: ${[...earnSel, ...expSel].join(", ")}` : ""}`,
        [...rows.map((r) => [r.label, r.fmt(r.cur)] as [string, string]), ["Total ainda a receber (geral)", money(totalRemaining)], ["Contas no período", `${periodBills.length} (${money(sum(periodBills, (o) => o.bill.expected_amount))})`]],
        [
          { title: "Ganhos por tópico", head: ["Tópico", "Lançamentos", "Km", "Total"], body: earnByTopic.map((t) => [t.topic, t.count, t.km || "", money(t.total)]) },
          { title: "Gastos por tópico", head: ["Tópico", "Lançamentos", "Total"], body: expByTopic.map((t) => [t.topic, t.count, money(t.total)]) },
          { title: "Ganhos", head: ["Data", "Fonte", "Km", "Valor"], body: cur.e.map((e) => [dateBR(e.date), e.source, e.km ?? "", money(e.amount)]) },
          { title: "Despesas", head: ["Data", "Descrição", "Categoria", "Valor"], body: cur.x.map((e) => [dateBR(e.date), e.description, e.category, money(e.amount)]) },
          { title: "Contas do período", head: ["Vencimento", "Conta", "Previsto", "Situação"], body: periodBills.map((o) => [dateBR(o.due_date), o.bill.name, money(o.bill.expected_amount), o.payment ? `Pago ${money(o.payment.paid_amount)}` : o.status]) },
        ],
      );
    } catch {
      toast.error("Não foi possível gerar o PDF");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <PageHeader
        title="Calculadora"
        subtitle="Escolha um período para ver totais, comparar e exportar."
        action={
          <>
            <Button variant="outline" onClick={exportCSV}>
              <FileSpreadsheet /> CSV
            </Button>
            <Button onClick={exportPDF} disabled={busy}>
              {busy ? <Loader2 className="animate-spin" /> : <FileDown />} PDF
            </Button>
          </>
        }
      />
      <Panel>
        <div className="flex flex-wrap gap-2">
          {(
            [
              ["semana", "Esta semana"],
              ["semana_ant", "Semana passada"],
              ["mes", "Este mês"],
              ["mes_ant", "Mês passado"],
              ["custom", "Personalizado"],
            ] as [Preset, string][]
          ).map(([k, l]) => (
            <Button key={k} size="sm" variant={preset === k ? "default" : "outline"} onClick={() => setPreset(k)}>
              {l}
            </Button>
          ))}
        </div>
        {preset === "custom" && (
          <div className="mt-4 grid grid-cols-2 gap-3 sm:max-w-md">
            <Field label="De">
              <TextInput type="date" value={custom.start} onChange={(e) => setCustom((c) => ({ ...c, start: e.target.value }))} />
            </Field>
            <Field label="Até">
              <TextInput type="date" value={custom.end} onChange={(e) => setCustom((c) => ({ ...c, end: e.target.value }))} />
            </Field>
          </div>
        )}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2 text-sm">
          <span className="font-semibold">{label}</span>
          <label className="flex items-center gap-2">
            <input type="checkbox" className="size-4 accent-[var(--color-primary)]" checked={compare} onChange={(e) => setCompare(e.target.checked)} />
            Comparar com {dateBR(prevRange.start)} a {dateBR(prevRange.end)}
          </label>
        </div>
      </Panel>

      <Panel className="mt-5" title="Filtrar por tópico" action={topicFilterOn ? <Button variant="ghost" size="sm" onClick={() => { setEarnSel([]); setExpSel([]); }}>Limpar filtros</Button> : undefined}>
        <p className="mb-3 text-xs text-muted-foreground">Escolha tópicos para calcular só o que quiser. Sem seleção, entram todos.</p>
        <TopicChips label="Ganhos (fonte)" topics={earnTopics} selected={earnSel} onToggle={(t) => toggle(earnSel, setEarnSel, t)} tone="income" />
        <div className="h-3" />
        <TopicChips label="Gastos (categoria)" topics={expTopics} selected={expSel} onToggle={(t) => toggle(expSel, setExpSel, t)} tone="expense" />
      </Panel>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <Panel title="Ganhos por tópico">
          {earnByTopic.length === 0 ? (
            <p className="text-sm text-muted-foreground">Sem ganhos no período.</p>
          ) : (
            <TopicTable
              rows={earnByTopic.map((t) => ({ topic: t.topic, sub: `${t.count} lanç.${t.km ? ` · ${km(t.km)}` : ""}${t.ppk != null ? ` · ${money(t.ppk)}/km` : ""}`, total: t.total }))}
              selected={earnSel}
              onToggle={(t) => toggle(earnSel, setEarnSel, t)}
              tone="income"
            />
          )}
        </Panel>
        <Panel title="Gastos por tópico">
          {expByTopic.length === 0 ? (
            <p className="text-sm text-muted-foreground">Sem gastos no período.</p>
          ) : (
            <TopicTable rows={expByTopic.map((t) => ({ topic: t.topic, sub: `${t.count} lanç.`, total: t.total }))} selected={expSel} onToggle={(t) => toggle(expSel, setExpSel, t)} tone="expense" />
          )}
        </Panel>
      </div>

      <Panel className="mt-5" title={topicFilterOn ? "Resultado (com filtro de tópicos)" : "Resultado"}>
        <ul className="divide-y">
          {rows.map((r) => {
            const diff = r.cur != null && r.prev != null ? r.cur - r.prev : null;
            const pct = diff != null && r.prev ? Math.round((diff / Math.abs(r.prev)) * 100) : null;
            const positive = diff != null && (r.good === "up" ? diff > 0 : diff < 0);
            return (
              <li key={r.label} className="flex flex-wrap items-center justify-between gap-2 py-3">
                <span className="text-sm text-muted-foreground">{r.label}</span>
                <div className="flex items-center gap-3">
                  {compare && <span className="text-xs text-muted-foreground tabular">antes {r.fmt(r.prev)}</span>}
                  <span className={cn("font-display text-lg font-bold tabular", r.label === "Lucro líquido" && (cur.net >= 0 ? "text-income" : "text-expense"))}>{r.fmt(r.cur)}</span>
                  {compare && diff != null && diff !== 0 && (
                    <span className={cn("inline-flex items-center rounded-full px-2 py-0.5 text-xs font-bold", positive ? "bg-success/12 text-success" : "bg-destructive/12 text-destructive")}>
                      {diff > 0 ? <ArrowUpRight className="size-3" /> : <ArrowDownRight className="size-3" />}
                      {pct != null ? `${Math.abs(pct)}%` : ""}
                    </span>
                  )}
                </div>
              </li>
            );
          })}
          <li className="flex items-center justify-between gap-2 py-3">
            <span className="text-sm text-muted-foreground">Total ainda a receber (geral)</span>
            <span className="font-display text-lg font-bold tabular">{money(totalRemaining)}</span>
          </li>
        </ul>
      </Panel>

      <Panel className="mt-5" title="Contas que vencem no período">
        {periodBills.length === 0 ? (
          <p className="text-sm text-muted-foreground">Nenhuma conta recorrente no período.</p>
        ) : (
          <ul className="divide-y">
            {periodBills.map((o) => (
              <li key={o.bill.id + o.reference_month} className="flex items-center justify-between gap-2 py-2.5 text-sm">
                <span>
                  {dateBR(o.due_date)} · <b>{o.bill.name}</b>
                </span>
                <span className="flex items-center gap-2">
                  <span className="tabular">{money(o.payment?.paid_amount ?? o.bill.expected_amount)}</span>
                  <StatusBadge status={o.status} />
                </span>
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </>
  );
}

function TopicChips({ label, topics, selected, onToggle, tone }: { label: string; topics: string[]; selected: string[]; onToggle: (t: string) => void; tone: "income" | "expense" }) {
  if (topics.length === 0) return <p className="text-sm text-muted-foreground">{label}: nenhum tópico ainda.</p>;
  return (
    <div>
      <p className="mb-2 text-sm font-semibold">{label}</p>
      <div className="flex flex-wrap gap-2">
        {topics.map((t) => {
          const on = selected.includes(t);
          return (
            <button
              key={t}
              type="button"
              onClick={() => onToggle(t)}
              aria-pressed={on}
              className={cn(
                "min-h-9 rounded-full border px-3 text-sm font-medium transition",
                on ? (tone === "income" ? "border-income bg-income text-primary-foreground" : "border-expense bg-expense text-destructive-foreground") : "bg-card hover:bg-accent",
              )}
            >
              {t}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function TopicTable({ rows, selected, onToggle, tone }: { rows: { topic: string; sub: string; total: number }[]; selected: string[]; onToggle: (t: string) => void; tone: "income" | "expense" }) {
  const total = rows.reduce((s, r) => s + r.total, 0);
  return (
    <ul className="space-y-3">
      {rows.map((r) => {
        const on = selected.length === 0 || selected.includes(r.topic);
        return (
          <li key={r.topic}>
            <button type="button" onClick={() => onToggle(r.topic)} className={cn("w-full text-left transition", !on && "opacity-40")}>
              <div className="flex items-baseline justify-between gap-2 text-sm">
                <span className="font-semibold">{r.topic}</span>
                <span className={cn("font-bold tabular", tone === "income" ? "text-income" : "text-expense")}>{money(r.total)}</span>
              </div>
              <div className="mt-1 h-2 overflow-hidden rounded-full bg-muted">
                <div className={cn("h-full rounded-full", tone === "income" ? "bg-income" : "bg-expense")} style={{ width: `${total ? (r.total / total) * 100 : 0}%` }} />
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                {r.sub} · {total ? Math.round((r.total / total) * 100) : 0}%
              </p>
            </button>
          </li>
        );
      })}
    </ul>
  );
}
