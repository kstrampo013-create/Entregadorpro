import { useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type ToolUIPart, type UIMessage } from "ai";
import { ArrowLeft, Loader2, Mic, Square, Volume2, VolumeX } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { EmptyState, LoadingBlock } from "@/components/common";
import { ThassiAvatar } from "@/components/nels/nels-nav";
import { Conversation, ConversationContent, ConversationEmptyState, ConversationScrollButton } from "@/components/ai-elements/conversation";
import { Message, MessageActions, MessageContent, MessageResponse } from "@/components/ai-elements/message";
import {
  PromptInput,
  PromptInputBody,
  PromptInputButton,
  PromptInputFooter,
  PromptInputSubmit,
  PromptInputTextarea,
  PromptInputTools,
} from "@/components/ai-elements/prompt-input";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { Tool, ToolContent, ToolHeader, ToolInput, ToolOutput } from "@/components/ai-elements/tool";
import { supabase } from "@/integrations/supabase/client";
import { newsKeys } from "@/hooks/use-news";
import { authHeaders, recordWav, speak, transcribe } from "@/lib/thassi-client";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/noticias/thassi/$threadId")({
  head: () => ({
    meta: [
      { title: "Conversa com a Thassi | Nels Nere" },
      { name: "description", content: "Pergunte à Thassi sobre as notícias do Sul Fluminense." },
      { property: "og:title", content: "Conversa com a Thassi" },
      { property: "og:description", content: "Assistente de notícias regionais com voz feminina." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ThreadPage,
});

const TOOL_TITLES: Record<string, string> = {
  "tool-buscar_noticias": "Procurou nas fontes regionais",
  "tool-buscar_no_google": "Procurou no Google Notícias",
  "tool-pesquisar_google": "Pesquisou no Google",
};

const SUGGESTIONS = [
  "Quais as principais notícias de hoje em Volta Redonda?",
  "Tem algo sobre trânsito na Dutra hoje?",
  "O que aconteceu em Barra Mansa esta semana?",
  "Tem vagas de emprego na região?",
];

function ThreadPage() {
  const { threadId } = Route.useParams();
  const q = useQuery({
    queryKey: newsKeys.messages(threadId),
    staleTime: Infinity,
    gcTime: 0,
    queryFn: async () => {
      const [{ data: thread, error: tErr }, { data: rows, error: mErr }] = await Promise.all([
        supabase.from("chat_threads").select("id, title").eq("id", threadId).maybeSingle(),
        supabase.from("chat_messages").select("message_id, role, parts").eq("thread_id", threadId).order("created_at"),
      ]);
      if (tErr) throw tErr;
      if (mErr) throw mErr;
      if (!thread) return null;
      const messages = (rows ?? []).map(
        (r) => ({ id: r.message_id, role: r.role as UIMessage["role"], parts: r.parts as UIMessage["parts"] }) satisfies UIMessage,
      );
      return { thread, messages };
    },
  });

  if (q.isLoading) return <LoadingBlock />;
  if (q.error) return <EmptyState title="Não consegui abrir a conversa" text="Verifique sua internet e tente de novo." />;
  if (!q.data)
    return (
      <EmptyState
        title="Conversa não encontrada"
        action={
          <Button asChild>
            <Link to="/noticias/thassi">Ver conversas</Link>
          </Button>
        }
      />
    );
  return <ChatView key={threadId} threadId={threadId} title={q.data.thread.title} initial={q.data.messages} />;
}

function textOf(m: UIMessage) {
  return m.parts
    .filter((p): p is { type: "text"; text: string } => p.type === "text")
    .map((p) => p.text)
    .join("\n");
}

function ChatView({ threadId, title, initial }: { threadId: string; title: string; initial: UIMessage[] }) {
  const qc = useQueryClient();
  const [voiceReplies, setVoiceReplies] = useState(false);
  const voiceRef = useRef(false);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const speakAbort = useRef<AbortController | null>(null);
  const [mic, setMic] = useState<"idle" | "recording" | "transcribing">("idle");
  const recorder = useRef<Awaited<ReturnType<typeof recordWav>> | null>(null);

  useEffect(() => {
    const on = localStorage.getItem("thassi-voice") !== "0";
    setVoiceReplies(on);
    voiceRef.current = on;
    return () => {
      speakAbort.current?.abort();
      recorder.current?.cancel();
    };
  }, []);

  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/thassi/chat",
        prepareSendMessagesRequest: async ({ id, messages }) => ({
          body: { threadId: id, messages },
          headers: await authHeaders(),
        }),
      }),
    [],
  );

  const { messages, sendMessage, status, stop, error, regenerate } = useChat({
    id: threadId,
    messages: initial,
    transport,
    onFinish: ({ message }) => {
      void qc.invalidateQueries({ queryKey: newsKeys.threads });
      if (voiceRef.current && message.role === "assistant") void listen(message);
    },
  });

  async function listen(m: UIMessage) {
    speakAbort.current?.abort();
    if (speakingId === m.id) {
      setSpeakingId(null);
      return;
    }
    const text = textOf(m);
    if (!text.trim()) return;
    const ctrl = new AbortController();
    speakAbort.current = ctrl;
    setSpeakingId(m.id);
    try {
      await speak(text, ctrl.signal);
    } catch (e) {
      if (!ctrl.signal.aborted) toast.error(e instanceof Error ? e.message : "Não consegui falar agora.");
    } finally {
      if (speakAbort.current === ctrl) setSpeakingId(null);
    }
  }

  function toggleVoice() {
    const next = !voiceReplies;
    setVoiceReplies(next);
    voiceRef.current = next;
    localStorage.setItem("thassi-voice", next ? "1" : "0");
    if (!next) speakAbort.current?.abort();
    toast.info(next ? "A Thassi vai responder falando." : "Respostas só em texto.");
  }

  async function toggleMic() {
    if (mic === "transcribing") return;
    if (mic === "idle") {
      speakAbort.current?.abort();
      try {
        recorder.current = await recordWav();
        setMic("recording");
      } catch {
        toast.error("Não consegui usar o microfone. Permita o acesso nas configurações do navegador.");
      }
      return;
    }
    const rec = recorder.current;
    recorder.current = null;
    if (!rec) return setMic("idle");
    setMic("transcribing");
    try {
      const file = await rec.stop();
      const text = await transcribe(file);
      if (!text) toast.info("Não entendi. Tente falar de novo.");
      else void sendMessage({ text });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Não consegui entender o áudio.");
    } finally {
      setMic("idle");
    }
  }

  const busy = status === "submitted" || status === "streaming";
  const last = messages[messages.length - 1];
  const waiting = busy && (!last || last.role === "user" || !textOf(last).trim());

  return (
    <div className="-mx-4 flex h-[calc(100dvh-9.5rem)] flex-col lg:mx-0 lg:h-[calc(100dvh-5rem)]">
      <div className="flex items-center gap-2 border-b px-4 pb-3">
        <Button asChild variant="ghost" size="icon" aria-label="Voltar às conversas">
          <Link to="/noticias/thassi">
            <ArrowLeft />
          </Link>
        </Button>
        <ThassiAvatar className="size-9" />
        <div className="min-w-0 flex-1">
          <p className="truncate font-display font-semibold leading-tight">{title}</p>
          <p className="text-xs text-muted-foreground">Thassi · notícias do Sul Fluminense</p>
        </div>
        <Button
          variant={voiceReplies ? "default" : "outline"}
          size="sm"
          className="h-10"
          onClick={toggleVoice}
          aria-pressed={voiceReplies}
        >
          {voiceReplies ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />}
          <span className="hidden sm:inline">{voiceReplies ? "Fala ligada" : "Fala desligada"}</span>
        </Button>
      </div>

      <Conversation className="min-h-0">
        <ConversationContent className="gap-6">
          {messages.length === 0 ? (
            <ConversationEmptyState>
              <ThassiAvatar className="size-20" />
              <div className="space-y-1">
                <h2 className="font-display text-lg font-semibold">Oi! Eu sou a Thassi.</h2>
                <p className="text-sm text-muted-foreground">
                  Pergunte sobre notícias da região. Respondo só com o que encontro nas fontes e mostro os links.
                </p>
              </div>
              <div className="flex flex-col gap-2 pt-2">
                {SUGGESTIONS.map((s) => (
                  <Button key={s} variant="outline" className="h-auto whitespace-normal py-2.5 text-left" onClick={() => sendMessage({ text: s })}>
                    {s}
                  </Button>
                ))}
              </div>
            </ConversationEmptyState>
          ) : (
            messages.map((m) => (
              <Message key={m.id} from={m.role}>
                <MessageContent className="group-[.is-user]:bg-primary group-[.is-user]:text-primary-foreground">
                  {m.parts.map((part, i) => {
                    if (part.type === "text")
                      return m.role === "assistant" ? (
                        <MessageResponse key={i} className="text-[15px] leading-relaxed [&_a]:font-semibold [&_a]:text-primary [&_a]:underline">
                          {part.text}
                        </MessageResponse>
                      ) : (
                        <p key={i} className="whitespace-pre-wrap text-[15px]">
                          {part.text}
                        </p>
                      );
                    if (part.type.startsWith("tool-")) {
                      const t = part as ToolUIPart;
                      return (
                        <Tool key={i} defaultOpen={false} className="mb-0">
                          <ToolHeader type={t.type} state={t.state} title={TOOL_TITLES[t.type] ?? "Pesquisa"} />
                          <ToolContent>
                            <ToolInput input={t.input} />
                            <ToolOutput output={t.output} errorText={t.errorText} />
                          </ToolContent>
                        </Tool>
                      );
                    }
                    return null;
                  })}
                </MessageContent>
                {m.role === "assistant" && textOf(m).trim() && !(busy && m.id === last?.id) && (
                  <MessageActions>
                    <Button variant="ghost" size="sm" className="h-9 text-muted-foreground" onClick={() => listen(m)}>
                      {speakingId === m.id ? <Square className="size-4" /> : <Volume2 className="size-4" />}
                      {speakingId === m.id ? "Parar" : "Ouvir"}
                    </Button>
                  </MessageActions>
                )}
              </Message>
            ))
          )}
          {waiting && (
            <Message from="assistant">
              <MessageContent>
                <Shimmer>Thassi está procurando nas fontes…</Shimmer>
              </MessageContent>
            </Message>
          )}
          {error && !busy && (
            <div className="rounded-xl border border-destructive/40 bg-destructive/5 p-3 text-sm">
              <p className="font-medium text-destructive">{error.message || "A Thassi não conseguiu responder."}</p>
              <Button size="sm" variant="outline" className="mt-2" onClick={() => regenerate()}>
                Tentar de novo
              </Button>
            </div>
          )}
        </ConversationContent>
        <ConversationScrollButton />
      </Conversation>

      <div className="px-3 pb-3 pt-2 lg:px-0">
        <PromptInput
          onSubmit={(msg) => {
            if (msg.text.trim()) void sendMessage({ text: msg.text });
          }}
        >
          <PromptInputBody>
            <PromptInputTextarea placeholder={mic === "recording" ? "Gravando… toque no microfone para enviar" : "Pergunte à Thassi…"} />
          </PromptInputBody>
          <PromptInputFooter>
            <PromptInputTools>
              <PromptInputButton
                onClick={toggleMic}
                disabled={mic === "transcribing" || busy}
                aria-label={mic === "recording" ? "Parar e enviar pergunta falada" : "Perguntar falando"}
                className={cn(mic === "recording" && "animate-pulse bg-destructive text-destructive-foreground hover:bg-destructive/90")}
              >
                {mic === "transcribing" ? <Loader2 className="size-4 animate-spin" /> : mic === "recording" ? <Square className="size-4" /> : <Mic className="size-4" />}
                <span className="text-xs">{mic === "recording" ? "Enviar áudio" : mic === "transcribing" ? "Ouvindo…" : "Falar"}</span>
              </PromptInputButton>
            </PromptInputTools>
            <PromptInputSubmit status={status} onStop={stop} aria-label={busy ? "Parar resposta" : "Enviar"} />
          </PromptInputFooter>
        </PromptInput>
      </div>
    </div>
  );
}
