import { createFileRoute } from "@tanstack/react-router";
import { ContractDetail } from "@/components/contract-views";

export const Route = createFileRoute("/_authenticated/vendas/$id")({
  head: () => ({
    meta: [
      { title: "Detalhes da venda — Entregador Pro" },
      { name: "description", content: "Parcelas, pagamentos e saldo da venda." },
      { property: "og:title", content: "Detalhes da venda — Entregador Pro" },
      { property: "og:description", content: "Parcelas e pagamentos." },
    ],
  }),
  component: SaleDetailPage,
});

function SaleDetailPage() {
  const { id } = Route.useParams();
  return <ContractDetail kind="sale" id={id} />;
}
