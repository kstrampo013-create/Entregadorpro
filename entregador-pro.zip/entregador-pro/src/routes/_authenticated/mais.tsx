import { createFileRoute, Link } from "@tanstack/react-router";
import { LogOut } from "lucide-react";
import { NAV_ITEMS, useSignOut } from "@/components/app-shell";
import { PageHeader } from "@/components/common";

export const Route = createFileRoute("/_authenticated/mais")({
  head: () => ({
    meta: [
      { title: "Menu — Entregador Pro" },
      { name: "description", content: "Todas as áreas do Entregador Pro." },
      { property: "og:title", content: "Menu — Entregador Pro" },
      { property: "og:description", content: "Navegação do app." },
    ],
  }),
  component: MorePage,
});

function MorePage() {
  const signOut = useSignOut();
  return (
    <>
      <PageHeader title="Menu" />
      <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">
        {NAV_ITEMS.map((item) => (
          <Link
            key={item.to}
            to={item.to}
            className="flex aspect-square flex-col items-center justify-center gap-2 rounded-2xl border bg-card p-2 text-center text-xs font-semibold shadow-soft transition active:scale-95"
          >
            <span className="grid size-11 place-items-center rounded-xl bg-secondary text-secondary-foreground">
              <item.icon className="size-5" />
            </span>
            {item.label}
          </Link>
        ))}
        <button
          onClick={signOut}
          className="flex aspect-square flex-col items-center justify-center gap-2 rounded-2xl border bg-card p-2 text-xs font-semibold text-destructive shadow-soft"
        >
          <span className="grid size-11 place-items-center rounded-xl bg-destructive/10">
            <LogOut className="size-5" />
          </span>
          Sair
        </button>
      </div>
    </>
  );
}
