import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ExternalLink, Loader2, Radio, Send, Sparkles, Volume2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { ConfirmDelete, EmptyState, LoadingBlock } from "@/components/common";
import { NelsHeader } from "@/components/nels/nels-nav";
import { supabase } from "@/integrations/supabase/client";
import { newsKeys, useBulletins, usePrefs, type Bulletin } from "@/hooks/use-news";
import { generateBulletinNow, getTelegramStatus, sendBulletinToTelegram } from "@/lib/nels.functions";
import { getBulletinAudioUrl } from "@/lib/thassi-client";

export const Route = createFileRoute("/_authenticated/noticias/boletins")({
  head: () => ({
    meta: [
      { title: "Boletins da Thassi | Nels Nere" },
      { name: "description", content: "Boletins de notícias do Sul Fluminense sob demanda, em texto e áudio." },
      { property: "og:title", content: "Boletins da Thassi — Nels Nere" },
      { property: "og:description", content: "Resumo das notícias da região, para ler ou ouvir." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: BulletinsPage,
});

type Item = { id: string; title: string; summary: string; source: string; url: string; published_at: string | null };

const SLOT: Record<string, string> = { manha: "Manhã", tarde: "Tarde", avulso: "Extra" };

function fmtDate(d: string) {
  const [y, m, day] = d.split("-");
  return `${day}/${m}/${y}`;
}

function BulletinsPage() {
  const { data = [], isLoading } = useBulletins();
  const prefs = usePrefs();
  const qc = useQueryClient();
  const generate = useServerFn(generateBulletinNow);
  const tgStatus = useServerFn(getTelegramStatus);
  const tg = useQuery({ queryKey: ["news", "telegram"], queryFn: () => tgStatus(), staleTime: 60_000 });
  const [creating, setCreating] = useState(false);

  async function makeNow() {
    setCreating(true);
    try {
      const r = await generate();
      if (!r.ok) toast.error(r.error);
      else toast.success("Boletim pronto!");
      await qc.invalidateQueries({ queryKey: newsKeys.bulletins });
    } catch {
      toast.error("Não consegui montar o boletim agora.");
    } finally {
      setCreating(false);
    }
  }


  return (
    <>
      <NelsHeader
        subtitle="Gerados só quando você tocar em Gerar agora"
        action={
          <Button onClick={makeNow} disabled={creating} className="h-11 rounded-xl">
            {creating ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
            {creating ? "Montando…" : "Gerar agora"}
          </Button>
        }
      />
      {isLoading ? (
        <LoadingBlock />
      ) : data.length === 0 ? (
        <EmptyState
          icon={<Radio />}
          title="Nenhum boletim ainda"
          text={"Toque em Gerar agora para criar um boletim."}
          action={
            <Button asChild variant="outline">
              <Link to="/noticias/ajustes">Escolher horários e cidades</Link>
            </Button>
          }
        />
      ) : (
        <ul className="space-y-4">
          {data.map((b) => (
            <li key={b.id}>
              <BulletinCard b={b} telegramLinked={!!tg.data?.link && tg.data.configured} />
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

function BulletinCard({ b, telegramLinked }: { b: Bulletin; telegramLinked: boolean }) {
  const qc = useQueryClient();
  const sendTg = useServerFn(sendBulletinToTelegram);
  const [audio, setAudio] = useState<string | null>(null);
  const [loadingAudio, setLoadingAudio] = useState(false);
  const [sending, setSending] = useState(false);
  const items = (Array.isArray(b.items) ? b.items : []) as unknown as Item[];

  async function listen() {
    setLoadingAudio(true);
    try {
      setAudio(await getBulletinAudioUrl(b.id));
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Não consegui preparar o áudio.");
    } finally {
      setLoadingAudio(false);
    }
  }

  async function toTelegram() {
    setSending(true);
    try {
      const r = await sendTg({ data: { id: b.id } });
      if (r.ok) toast.success("Enviado para o seu Telegram");
      else toast.error(r.error);
    } finally {
      setSending(false);
    }
  }

  async function remove() {
    const { error } = await supabase.from("bulletins").delete().eq("id", b.id);
    if (error) toast.error("Não consegui apagar.");
    await qc.invalidateQueries({ queryKey: newsKeys.bulletins });
  }

  return (
    <article className="rounded-2xl border bg-card p-4 shadow-soft">
      <div className="mb-2 flex items-start justify-between gap-2">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-primary">
            {SLOT[b.slot] ?? b.slot} · {fmtDate(b.bulletin_date)}
          </p>
          <h2 className="font-display text-lg font-bold leading-tight">{b.title}</h2>
          {b.cities.length > 0 && <p className="text-xs text-muted-foreground">{b.cities.join(", ")}</p>}
        </div>
        <ConfirmDelete title="Apagar este boletim?" onConfirm={remove} />
      </div>
      {b.intro && <p className="text-sm">{b.intro}</p>}
      {items.length > 0 ? (
        <ol className="mt-3 space-y-3">
          {items.map((it, i) => (
            <li key={it.id ?? i} className="border-l-2 border-accent pl-3">
              <a href={it.url} target="_blank" rel="noopener noreferrer" className="font-semibold leading-snug hover:text-primary hover:underline">
                {it.title}
              </a>
              {it.summary && <p className="mt-0.5 text-sm text-muted-foreground">{it.summary}</p>}
              <a
                href={it.url}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-1 inline-flex items-center gap-1 text-xs font-semibold text-primary"
              >
                {it.source} <ExternalLink className="size-3" />
              </a>
            </li>
          ))}
        </ol>
      ) : (
        <p className="mt-2 text-sm text-muted-foreground">Não houve notícias novas nas fontes nesse período.</p>
      )}
      {b.outro && <p className="mt-3 text-sm text-muted-foreground">{b.outro}</p>}

      {audio && (
        <audio src={audio} controls autoPlay className="mt-3 w-full">
          <track kind="captions" />
        </audio>
      )}
      <div className="mt-3 flex flex-wrap gap-2">
        {!audio && (
          <Button variant="outline" className="h-10" onClick={listen} disabled={loadingAudio}>
            {loadingAudio ? <Loader2 className="size-4 animate-spin" /> : <Volume2 className="size-4" />}
            {loadingAudio ? "Preparando a voz… (até 1 min)" : "Ouvir boletim"}
          </Button>
        )}
        {telegramLinked && (
          <Button variant="outline" className="h-10" onClick={toTelegram} disabled={sending}>
            {sending ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
            Enviar no Telegram
          </Button>
        )}
        {b.telegram_status === "sent" && <span className="self-center text-xs text-muted-foreground">✓ Enviado no Telegram</span>}
      </div>
    </article>
  );
}
