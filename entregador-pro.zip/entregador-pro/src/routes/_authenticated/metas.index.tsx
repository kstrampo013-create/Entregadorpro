import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { CalendarCheck2, Plus, Target } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EmptyState, LoadingBlock, PageHeader, Panel } from "@/components/common";
import { GoalForm } from "@/components/forms/goal-form";
import { GoalCard, todayLine } from "@/components/goal-card";
import { useGoals } from "@/hooks/use-derived";
import type { GoalKind } from "@/lib/finance";
import { money } from "@/lib/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/metas/")({
  head: () => ({
    meta: [
      { title: "Metas — quanto fazer por dia | Entregador Pro" },
      { name: "description", content: "Meta mensal e objetivos como reformar a casa, com quanto você precisa fazer em cada dia de trabalho." },
      { property: "og:title", content: "Metas — Entregador Pro" },
      { property: "og:description", content: "Acompanhe suas metas e saiba quanto fazer por dia." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: GoalsPage,
});

function GoalsPage() {
  const { goals, isLoading } = useGoals();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [kind, setKind] = useState<GoalKind>("mensal");
  const active = goals.filter((g) => g.goal.active);
  const archived = goals.filter((g) => !g.goal.active);
  const todayMissing = active.reduce((s, g) => s + Math.round(g.progress.todayMissing * 100), 0) / 100;

  function create(k: GoalKind) {
    setKind(k);
    setOpen(true);
  }

  return (
    <>
      <PageHeader
        title="Metas"
        subtitle="Quanto você precisa fazer em cada dia de trabalho para chegar lá."
        action={
          <Button size="lg" onClick={() => create("mensal")}>
            <Plus /> Nova meta
          </Button>
        }
      />
      {isLoading ? (
        <LoadingBlock />
      ) : goals.length === 0 ? (
        <Panel>
          <EmptyState
            icon={<Target />}
            title="Nenhuma meta ainda"
            text="Crie a sua meta do mês ou um objetivo, como reformar a casa, e veja quanto fazer por dia."
            action={
              <div className="flex flex-wrap justify-center gap-2">
                <Button onClick={() => create("mensal")}>
                  <CalendarCheck2 /> Meta do mês
                </Button>
                <Button variant="outline" onClick={() => create("objetivo")}>
                  <Target /> Objetivo com prazo
                </Button>
              </div>
            }
          />
        </Panel>
      ) : (
        <>
          {active.length > 0 && (
            <Panel className="mb-5" title="Hoje">
              <p className="mb-3 text-sm">
                {todayMissing > 0 ? (
                  <>
                    Para bater as metas de hoje ainda faltam <b className="tabular">{money(todayMissing)}</b>.
                  </>
                ) : (
                  "Nada pendente nas metas de hoje."
                )}
              </p>
              <ul className="space-y-1.5 text-sm">
                {active.map((g) => {
                  const t = todayLine(g);
                  return (
                    <li key={g.goal.id} className="flex justify-between gap-3">
                      <span className="truncate font-medium">{g.goal.name}</span>
                      <span className={cn("shrink-0 text-right", t.tone === "ok" ? "text-success" : t.tone === "muted" ? "text-muted-foreground" : "font-semibold")}>{t.text}</span>
                    </li>
                  );
                })}
              </ul>
            </Panel>
          )}
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {active.map((g) => (
              <GoalCard key={g.goal.id} view={g} />
            ))}
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => create("mensal")}>
              <CalendarCheck2 /> Nova meta do mês
            </Button>
            <Button variant="outline" onClick={() => create("objetivo")}>
              <Target /> Novo objetivo com prazo
            </Button>
          </div>
          {archived.length > 0 && (
            <>
              <h2 className="mb-3 mt-8 font-display text-lg font-bold">Arquivadas</h2>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {archived.map((g) => (
                  <GoalCard key={g.goal.id} view={g} />
                ))}
              </div>
            </>
          )}
        </>
      )}
      <GoalForm open={open} onOpenChange={setOpen} defaultKind={kind} onSaved={(id) => navigate({ to: "/metas/$id", params: { id } })} />
    </>
  );
}
