import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { Database, Download, KeyRound, Loader2, LogOut, Moon, Sparkles, Sun, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { ConfirmDelete, Field, PageHeader, Panel, TextInput } from "@/components/common";
import { PhoneVerification } from "@/components/phone-verification";
import { useSignOut } from "@/components/app-shell";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, useProfile } from "@/hooks/use-auth";
import { useInvalidateAll } from "@/hooks/use-data";
import { useTheme } from "@/hooks/use-theme";
import { errorMessage } from "@/lib/db";
import { downloadBackup } from "@/lib/export";
import { clearDemoData, loadDemoData } from "@/lib/demo";
import { formatPhoneBR, isValidPin, toE164BR } from "@/lib/phone";

export const Route = createFileRoute("/_authenticated/perfil")({
  head: () => ({
    meta: [
      { title: "Perfil — Entregador Pro" },
      { name: "description", content: "Seus dados, segurança, backup e preferências." },
      { property: "og:title", content: "Perfil — Entregador Pro" },
      { property: "og:description", content: "Dados da conta." },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const qc = useQueryClient();
  const invalidate = useInvalidateAll();
  const signOut = useSignOut();
  const { theme, setTheme } = useTheme();
  const [v, setV] = useState({ full_name: "", phone: "", email: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [pins, setPins] = useState({ current: "", next: "", next2: "" });
  const [pinBusy, setPinBusy] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => {
    if (profile) setV({ full_name: profile.full_name, phone: formatPhoneBR(profile.phone), email: user?.email ?? profile.email });
  }, [profile, user?.email]);

  async function saveProfile() {
    const schema = z.object({
      full_name: z.string().trim().min(3, "Informe seu nome completo").max(120),
      phone: z.string().refine((p) => toE164BR(p) !== null, "Telefone inválido"),
      email: z.string().trim().email("E-mail inválido"),
    });
    const parsed = schema.safeParse(v);
    if (!parsed.success) {
      const e: Record<string, string> = {};
      parsed.error.issues.forEach((i) => (e[String(i.path[0])] = i.message));
      return setErrors(e);
    }
    setErrors({});
    setSaving(true);
    try {
      const phone = toE164BR(parsed.data.phone)!;
      const phoneChanged = phone !== profile?.phone;
      const { error } = await supabase.from("profiles").update({ full_name: parsed.data.full_name, phone }).eq("id", user!.id);
      if (error) throw error;
      const email = parsed.data.email.toLowerCase();
      if (email !== user?.email) {
        const { error: e2 } = await supabase.auth.updateUser({ email });
        if (e2) throw e2;
        await supabase.from("profiles").update({ email }).eq("id", user!.id);
        toast.info("Enviamos uma confirmação para o novo e-mail.");
      }
      toast.success(phoneChanged ? "Dados salvos. Confirme o novo telefone." : "Dados salvos");
      qc.invalidateQueries({ queryKey: ["db", "profile"] });
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setSaving(false);
    }
  }

  async function changePin() {
    if (!isValidPin(pins.current)) {
      toast.error("Informe seu PIN atual");
      return;
    }
    if (!isValidPin(pins.next)) {
      toast.error("O novo PIN deve ter 6 números");
      return;
    }
    if (pins.next !== pins.next2) {
      toast.error("Os novos PINs não conferem");
      return;
    }
    setPinBusy(true);
    try {
      const { error: authErr } = await supabase.auth.signInWithPassword({ email: user!.email!, password: pins.current });
      if (authErr) throw new Error("PIN atual incorreto");
      const { error } = await supabase.auth.updateUser({ password: pins.next });
      if (error) throw error;
      toast.success("PIN alterado");
      setPins({ current: "", next: "", next2: "" });
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setPinBusy(false);
    }
  }

  async function run(key: string, fn: () => Promise<void>, ok: string) {
    setBusy(key);
    try {
      await fn();
      toast.success(ok);
      invalidate();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(null);
    }
  }

  const pinField = (k: keyof typeof pins, label: string) => (
    <Field label={label}>
      <TextInput type="password" inputMode="numeric" maxLength={6} value={pins[k]} onChange={(e) => setPins((s) => ({ ...s, [k]: e.target.value.replace(/\D/g, "") }))} />
    </Field>
  );

  return (
    <>
      <PageHeader title="Perfil" subtitle="Seus dados pessoais, segurança e preferências." />
      <div className="grid gap-5 lg:grid-cols-2">
        <Panel title="Dados pessoais">
          <form
            className="flex flex-col gap-4"
            onSubmit={(e) => {
              e.preventDefault();
              saveProfile();
            }}
          >
            <Field label="Nome completo" error={errors["full_name"]}>
              <TextInput value={v.full_name} onChange={(e) => setV((s) => ({ ...s, full_name: e.target.value }))} />
            </Field>
            <Field label="Telefone" error={errors["phone"]} hint="Ao trocar o telefone, ele precisa ser confirmado de novo.">
              <TextInput type="tel" value={v.phone} onChange={(e) => setV((s) => ({ ...s, phone: e.target.value }))} />
            </Field>
            <Field label="E-mail" error={errors["email"]}>
              <TextInput type="email" value={v.email} onChange={(e) => setV((s) => ({ ...s, email: e.target.value }))} />
            </Field>
            <Button type="submit" size="lg" disabled={saving}>
              {saving && <Loader2 className="animate-spin" />} Salvar dados
            </Button>
          </form>
        </Panel>

        <div className="space-y-5">
          <Panel title="Confirmação do telefone">
            <PhoneVerification />
          </Panel>
          <Panel title={<span className="flex items-center gap-2"><KeyRound className="size-4" /> Trocar PIN</span>}>
            <div className="grid grid-cols-3 gap-3">
              {pinField("current", "Atual")}
              {pinField("next", "Novo")}
              {pinField("next2", "Repita")}
            </div>
            <Button className="mt-4 w-full" variant="outline" size="lg" onClick={changePin} disabled={pinBusy}>
              {pinBusy && <Loader2 className="animate-spin" />} Alterar PIN
            </Button>
          </Panel>
        </div>

        <Panel title="Aparência">
          <div className="grid grid-cols-2 gap-2">
            <Button variant={theme === "light" ? "default" : "outline"} size="lg" onClick={() => setTheme("light")}>
              <Sun /> Claro
            </Button>
            <Button variant={theme === "dark" ? "default" : "outline"} size="lg" onClick={() => setTheme("dark")}>
              <Moon /> Escuro
            </Button>
          </div>
        </Panel>

        <Panel title={<span className="flex items-center gap-2"><Database className="size-4" /> Backup e dados de demonstração</span>}>
          <p className="mb-3 text-sm text-muted-foreground">Seus dados ficam salvos na nuvem e sincronizam entre aparelhos. Baixe uma cópia completa quando quiser.</p>
          <Button variant="outline" size="lg" className="w-full" disabled={busy !== null} onClick={() => run("backup", downloadBackup, "Backup baixado")}>
            {busy === "backup" ? <Loader2 className="animate-spin" /> : <Download />} Baixar backup completo (JSON)
          </Button>
          <div className="mt-4 rounded-xl bg-muted p-3 text-sm">
            <p className="font-semibold">Dados de demonstração</p>
            <p className="mb-3 text-muted-foreground">Exemplos marcados como “demo”, separados dos seus dados reais. Podem ser removidos a qualquer momento.</p>
            <div className="grid grid-cols-2 gap-2">
              <Button variant="soft" disabled={busy !== null} onClick={() => run("demo", loadDemoData, "Dados de demonstração carregados")}>
                {busy === "demo" ? <Loader2 className="animate-spin" /> : <Sparkles />} Carregar
              </Button>
              <ConfirmDelete
                title="Remover dados de demonstração?"
                description="Somente os registros marcados como demo serão apagados. Seus dados reais continuam."
                confirmLabel="Remover"
                trigger={
                  <Button variant="soft-destructive" disabled={busy !== null}>
                    {busy === "clear" ? <Loader2 className="animate-spin" /> : <Trash2 />} Remover
                  </Button>
                }
                onConfirm={() => run("clear", clearDemoData, "Dados de demonstração removidos")}
              />
            </div>
          </div>
        </Panel>
      </div>
      <Button variant="soft-destructive" size="lg" className="mt-6 w-full lg:w-auto" onClick={signOut}>
        <LogOut /> Sair da conta
      </Button>
    </>
  );
}
