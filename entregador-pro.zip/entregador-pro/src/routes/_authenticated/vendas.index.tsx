import { createFileRoute } from "@tanstack/react-router";
import { ContractList } from "@/components/contract-views";

export const Route = createFileRoute("/_authenticated/vendas/")({
  head: () => ({
    meta: [
      { title: "Vendas parceladas — Entregador Pro" },
      { name: "description", content: "Controle vendas a prazo com parcelas automáticas." },
      { property: "og:title", content: "Vendas parceladas — Entregador Pro" },
      { property: "og:description", content: "Vendas a prazo e parcelas." },
    ],
  }),
  component: () => <ContractList kind="sale" />,
});
