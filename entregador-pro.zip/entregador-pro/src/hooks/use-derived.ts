import { useMemo } from "react";
import { useTable } from "@/hooks/use-data";
import type { Bill, BillPayment, Goal, Installment } from "@/lib/db";
import {
  billOccurrences,
  billStatus,
  goalDailyValues,
  goalProgress,
  summarizeContract,
  type BillStatus,
  type GoalProgress,
  type Range,
  type WalletSummary,
} from "@/lib/finance";
import { todayISO } from "@/lib/format";

export interface Contract {
  kind: "sale" | "loan";
  id: string;
  name: string;
  phone: string | null;
  description: string;
  date: string;
  installments: Installment[];
  summary: WalletSummary;
  isDemo: boolean;
}

/** Sales + loans with their installments and wallet summary. Single source: the installments table. */
export function useContracts() {
  const sales = useTable("sales");
  const loans = useTable("loans");
  const inst = useTable("installments");
  const today = todayISO();

  const contracts = useMemo<Contract[]>(() => {
    const bySale = new Map<string, Installment[]>();
    const byLoan = new Map<string, Installment[]>();
    for (const i of inst.data ?? []) {
      if (i.sale_id) bySale.set(i.sale_id, [...(bySale.get(i.sale_id) ?? []), i]);
      if (i.loan_id) byLoan.set(i.loan_id, [...(byLoan.get(i.loan_id) ?? []), i]);
    }
    const sort = (a: Installment, b: Installment) => a.number - b.number;
    const out: Contract[] = [];
    for (const s of sales.data ?? []) {
      const list = (bySale.get(s.id) ?? []).sort(sort);
      out.push({
        kind: "sale",
        id: s.id,
        name: s.customer_name,
        phone: s.customer_phone,
        description: s.description,
        date: s.sale_date,
        installments: list,
        summary: summarizeContract(list, today),
        isDemo: s.is_demo,
      });
    }
    for (const l of loans.data ?? []) {
      const list = (byLoan.get(l.id) ?? []).sort(sort);
      out.push({
        kind: "loan",
        id: l.id,
        name: l.person_name,
        phone: l.person_phone,
        description: l.interest_rate ? `Empréstimo com ${String(l.interest_rate).replace(".", ",")}% de juros` : "Empréstimo sem juros",
        date: l.loan_date,
        installments: list,
        summary: summarizeContract(list, today),
        isDemo: l.is_demo,
      });
    }
    return out;
  }, [sales.data, loans.data, inst.data, today]);

  return {
    contracts,
    isLoading: sales.isLoading || loans.isLoading || inst.isLoading,
    error: sales.error || loans.error || inst.error,
  };
}

export interface BillOccurrenceView {
  bill: Bill;
  reference_month: string;
  due_date: string;
  payment: BillPayment | null;
  status: BillStatus;
}

export function computeBillOccurrences(bills: Bill[], payments: BillPayment[], range: Range, today: string): BillOccurrenceView[] {
  const pay = new Map(payments.map((p) => [`${p.bill_id}|${p.reference_month}`, p]));
  return bills
    .flatMap((b) =>
      billOccurrences(b, range).map((o) => {
        const p = pay.get(`${b.id}|${o.reference_month}`) ?? null;
        return { bill: b, reference_month: o.reference_month, due_date: o.due_date, payment: p, status: billStatus(o.due_date, !!p, today) };
      }),
    )
    .sort((a, b) => a.due_date.localeCompare(b.due_date));
}

export function useBillOccurrences(range: Range) {
  const bills = useTable("bills");
  const payments = useTable("bill_payments");
  const today = todayISO();
  const list = useMemo(
    () => computeBillOccurrences(bills.data ?? [], payments.data ?? [], range, today),
    [bills.data, payments.data, range.start, range.end, today], // eslint-disable-line react-hooks/exhaustive-deps
  );
  return { occurrences: list, isLoading: bills.isLoading || payments.isLoading };
}

/**
 * Every unpaid bill occurrence whose due date already passed, from any month since the bill started.
 * Used by the dashboard alert and the bills page so both always agree and the late item can be paid right there.
 */
export function useOverdueBills() {
  const today = todayISO();
  const { occurrences, isLoading } = useBillOccurrences({ start: "2000-01-01", end: today });
  return { overdue: occurrences.filter((o) => o.status === "atrasado"), isLoading };
}

export interface GoalView {
  goal: Goal;
  /** Amount that counts toward the goal on each day. */
  values: Map<string, number>;
  progress: GoalProgress;
}

/** Goals with their progress, updated from earnings, expenses and money set aside. */
export function useGoals() {
  const goals = useTable("goals");
  const earnings = useTable("earnings");
  const expenses = useTable("expenses");
  const contributions = useTable("goal_contributions");
  const today = todayISO();
  const list = useMemo<GoalView[]>(() => {
    const byGoal = new Map<string, { date: string; amount: number }[]>();
    for (const c of contributions.data ?? []) byGoal.set(c.goal_id, [...(byGoal.get(c.goal_id) ?? []), c]);
    return (goals.data ?? [])
      .map((g) => {
        const values = goalDailyValues(
          g.basis,
          { earnings: earnings.data ?? [], expenses: expenses.data ?? [], contributions: byGoal.get(g.id) ?? [] },
          today,
        );
        return { goal: g, values, progress: goalProgress(g, values, today) };
      })
      .sort((a, b) => Number(b.goal.active) - Number(a.goal.active) || a.goal.created_at.localeCompare(b.goal.created_at));
  }, [goals.data, earnings.data, expenses.data, contributions.data, today]);
  return { goals: list, isLoading: goals.isLoading || earnings.isLoading || expenses.isLoading || contributions.isLoading };
}
