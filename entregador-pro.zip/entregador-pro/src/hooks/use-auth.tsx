import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Profile } from "@/lib/db";

interface AuthState {
  session: Session | null;
  user: User | null;
  ready: boolean;
}

const AuthContext = createContext<AuthState>({ session: null, user: null, ready: false });

const EPHEMERAL_KEY = "ep-session-ephemeral";
const ALIVE_KEY = "ep-session-alive";

/** "Manter conectado" off: the session is dropped when the browser is closed. */
export function setKeepSignedIn(keep: boolean) {
  if (keep) localStorage.removeItem(EPHEMERAL_KEY);
  else localStorage.setItem(EPHEMERAL_KEY, "1");
  sessionStorage.setItem(ALIVE_KEY, "1");
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>({ session: null, user: null, ready: false });

  useEffect(() => {
    let active = true;
    (async () => {
      if (localStorage.getItem(EPHEMERAL_KEY) === "1" && !sessionStorage.getItem(ALIVE_KEY)) {
        await supabase.auth.signOut();
        localStorage.removeItem(EPHEMERAL_KEY);
      }
      const { data } = await supabase.auth.getSession();
      if (active) setState({ session: data.session, user: data.session?.user ?? null, ready: true });
    })();
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setState({ session, user: session?.user ?? null, ready: true });
    });
    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  return <AuthContext.Provider value={state}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}

export function useProfile() {
  const { user } = useAuth();
  return useQuery({
    queryKey: ["db", "profile", user?.id],
    enabled: !!user,
    queryFn: async (): Promise<Profile | null> => {
      const { data, error } = await supabase.from("profiles").select("*").eq("id", user!.id).maybeSingle();
      if (error) throw error;
      return data;
    },
  });
}
