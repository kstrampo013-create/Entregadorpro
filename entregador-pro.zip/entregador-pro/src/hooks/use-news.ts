import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesUpdate } from "@/integrations/supabase/types";
import { useAuth } from "@/hooks/use-auth";
import { errorMessage } from "@/lib/db";
import { getNewsItems, getSourceStatus, getJobState } from "@/lib/news-read.functions";

export type NewsItem = Tables<"news_items">;
export type NewsPrefs = Tables<"news_preferences">;
export type Bulletin = Tables<"bulletins">;
export type ChatThread = Tables<"chat_threads">;

export const newsKeys = {
  items: ["news", "items"] as const,
  prefs: (uid?: string) => ["news", "prefs", uid] as const,
  bulletins: ["news", "bulletins"] as const,
  sources: ["news", "sources"] as const,
  job: ["news", "job"] as const,
  threads: ["news", "threads"] as const,
  messages: (threadId: string) => ["news", "messages", threadId] as const,
};

/** Stories of the last 7 days (all sources). */
export function useNewsItems() {
  return useQuery({
    queryKey: newsKeys.items,
    staleTime: 60_000,
    refetchInterval: 5 * 60_000,
    queryFn: async () => {
      return (await getNewsItems()) as NewsItem[];
    },
  });
}

/** The user's Nels Nere settings; the row is created with the defaults (06:00 / 16:00) on first use. */
export function usePrefs() {
  const { user } = useAuth();
  return useQuery({
    queryKey: newsKeys.prefs(user?.id),
    enabled: !!user,
    queryFn: async (): Promise<NewsPrefs> => {
      const { data, error } = await supabase.from("news_preferences").select("*").eq("user_id", user!.id).maybeSingle();
      if (error) throw error;
      if (data) return data;
      const { error: insErr } = await supabase
        .from("news_preferences")
        .upsert({ user_id: user!.id }, { onConflict: "user_id", ignoreDuplicates: true });
      if (insErr) throw insErr;
      const again = await supabase.from("news_preferences").select("*").eq("user_id", user!.id).single();
      if (again.error) throw again.error;
      return again.data;
    },
  });
}

export function useSavePrefs() {
  const qc = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async (values: TablesUpdate<"news_preferences">) => {
      const { error } = await supabase
        .from("news_preferences")
        .update({ ...values, updated_at: new Date().toISOString() })
        .eq("user_id", user!.id);
      if (error) throw error;
    },
    onMutate: async (values) => {
      const key = newsKeys.prefs(user?.id);
      const prev = qc.getQueryData<NewsPrefs>(key);
      if (prev) qc.setQueryData(key, { ...prev, ...values });
      return { prev };
    },
    onError: (e, _v, ctx) => {
      if (ctx?.prev) qc.setQueryData(newsKeys.prefs(user?.id), ctx.prev);
      toast.error(errorMessage(e));
    },
    onSettled: () => qc.invalidateQueries({ queryKey: newsKeys.prefs(user?.id) }),
  });
}

export function useBulletins() {
  return useQuery({
    queryKey: newsKeys.bulletins,
    staleTime: 30_000,
    refetchInterval: 2 * 60_000,
    queryFn: async () => {
      const { data, error } = await supabase.from("bulletins").select("*").order("created_at", { ascending: false }).limit(30);
      if (error) throw error;
      return data;
    },
  });
}

export function useSourceStatus() {
  return useQuery({
    queryKey: newsKeys.sources,
    staleTime: 60_000,
    queryFn: async () => {
      return getSourceStatus();
    },
  });
}

export function useJobState() {
  return useQuery({
    queryKey: newsKeys.job,
    staleTime: 60_000,
    queryFn: async () => {
      return getJobState();
    },
  });
}

export function useThreads() {
  return useQuery({
    queryKey: newsKeys.threads,
    queryFn: async () => {
      const { data, error } = await supabase.from("chat_threads").select("*").order("updated_at", { ascending: false }).limit(100);
      if (error) throw error;
      return data;
    },
  });
}

export async function createThread(userId: string) {
  const id = crypto.randomUUID();
  const { error } = await supabase.from("chat_threads").insert({ id, user_id: userId });
  if (error) throw error;
  return id;
}
