import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { errorMessage, fetchAll, isDuplicate, type Insert, type Row, type TableName, type Update } from "@/lib/db";

export const dbKey = (table: TableName) => ["db", table] as const;

export function useTable<T extends TableName>(table: T) {
  return useQuery({
    queryKey: dbKey(table),
    queryFn: () => fetchAll(table),
    staleTime: 30_000,
  });
}

/** Invalidate every table: wallet, calendar and dashboard derive from several tables at once. */
export function useInvalidateAll() {
  const qc = useQueryClient();
  return () => qc.invalidateQueries({ queryKey: ["db"] });
}

export function useInsert<T extends TableName>(table: T, successMsg = "Salvo com sucesso") {
  const invalidate = useInvalidateAll();
  return useMutation({
    mutationFn: async (values: Insert<T>) => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { error } = await (supabase.from(table) as any).insert(values);
      if (error && !isDuplicate(error)) throw error;
    },
    onSuccess: () => {
      toast.success(successMsg);
      invalidate();
    },
    onError: (e) => toast.error(errorMessage(e)),
  });
}

export function useUpdate<T extends TableName>(table: T, successMsg = "Alterações salvas") {
  const invalidate = useInvalidateAll();
  return useMutation({
    mutationFn: async ({ id, values }: { id: string; values: Update<T> }) => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { error } = await (supabase.from(table) as any).update(values).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(successMsg);
      invalidate();
    },
    onError: (e) => toast.error(errorMessage(e)),
  });
}

export function useDelete(table: TableName, successMsg = "Excluído") {
  const invalidate = useInvalidateAll();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from(table).delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(successMsg);
      invalidate();
    },
    onError: (e) => toast.error(errorMessage(e)),
  });
}

export type { Row };
