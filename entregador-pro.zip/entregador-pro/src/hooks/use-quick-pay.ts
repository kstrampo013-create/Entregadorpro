import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useInvalidateAll } from "@/hooks/use-data";
import { errorMessage, isDuplicate, type Installment } from "@/lib/db";
import { remainingOf } from "@/lib/finance";
import { money, todayISO } from "@/lib/format";
import type { BillOccurrenceView } from "@/hooks/use-derived";

/** One-tap "mark as paid" for installments (full remaining balance) and monthly bills (expected amount). */
export function useQuickPay() {
  const invalidate = useInvalidateAll();
  const done = (msg: string) => () => {
    toast.success(msg);
    invalidate();
  };
  const fail = (e: unknown) => toast.error(errorMessage(e));

  const payInstallment = useMutation({
    mutationFn: async (i: Installment) => {
      const amount = remainingOf(i);
      if (amount <= 0) return;
      const { error } = await supabase
        .from("installment_payments")
        .insert({ installment_id: i.id, amount, paid_on: todayISO(), notes: "Marcada como paga", is_demo: i.is_demo });
      if (error) throw error;
    },
    onSuccess: done("Parcela marcada como paga"),
    onError: fail,
  });

  const unpayInstallment = useMutation({
    mutationFn: async (i: Installment) => {
      const { error } = await supabase.from("installment_payments").delete().eq("installment_id", i.id);
      if (error) throw error;
    },
    onSuccess: done("Parcela voltou a ficar em aberto"),
    onError: fail,
  });

  const payBill = useMutation({
    mutationFn: async (o: BillOccurrenceView) => {
      const { error } = await supabase.from("bill_payments").insert({
        bill_id: o.bill.id,
        reference_month: o.reference_month,
        paid_amount: Number(o.bill.expected_amount),
        paid_on: todayISO(),
        is_demo: o.bill.is_demo,
      });
      if (error && !isDuplicate(error)) throw error;
    },
    onSuccess: (_d, o) => done(`${o.bill.name} paga (${money(o.bill.expected_amount)})`)(),
    onError: fail,
  });

  const unpayBill = useMutation({
    mutationFn: async (o: BillOccurrenceView) => {
      if (!o.payment) return;
      const { error } = await supabase.from("bill_payments").delete().eq("id", o.payment.id);
      if (error) throw error;
    },
    onSuccess: done("Conta voltou a ficar pendente"),
    onError: fail,
  });

  const busy = payInstallment.isPending || unpayInstallment.isPending || payBill.isPending || unpayBill.isPending;
  return { payInstallment, unpayInstallment, payBill, unpayBill, busy };
}
