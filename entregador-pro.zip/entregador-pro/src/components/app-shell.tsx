import type { ReactNode } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import {
  CalendarDays,
  Calculator,
  CalendarClock,
  HandCoins,
  LayoutDashboard,
  ListTodo,
  LogOut,
  MapPin,
  MessageCircle,
  Menu,
  Moon,
  Newspaper,
  Receipt,
  ShoppingBag,
  Sun,
  Target,
  TrendingUp,
  UserRound,
  Wallet,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useTheme } from "@/hooks/use-theme";
import { useProfile } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/logo";
import { ThassiAvatar } from "@/components/nels/nels-nav";

export const NAV_ITEMS = [
  { to: "/painel", label: "Início", icon: LayoutDashboard },
  { to: "/ganhos", label: "Ganhos", icon: TrendingUp },
  { to: "/despesas", label: "Despesas", icon: Receipt },
  { to: "/vendas", label: "Vendas", icon: ShoppingBag },
  { to: "/emprestimos", label: "Empréstimos", icon: HandCoins },
  { to: "/carteira", label: "Carteira", icon: Wallet },
  { to: "/metas", label: "Metas", icon: Target },
  { to: "/calendario", label: "Calendário", icon: CalendarDays },
  { to: "/tarefas", label: "Tarefas", icon: ListTodo },
  { to: "/contas", label: "Contas mensais", icon: CalendarClock },
  { to: "/relatorios", label: "Calculadora", icon: Calculator },
  { to: "/locais", label: "Locais", icon: MapPin },
  { to: "/noticias", label: "Notícias", icon: Newspaper },
  { to: "/noticias/thassi", label: "Thassi", icon: MessageCircle },
  { to: "/perfil", label: "Perfil", icon: UserRound },
] as const;

const BOTTOM = [
  { to: "/painel", label: "Início", icon: LayoutDashboard },
  { to: "/ganhos", label: "Ganhos", icon: TrendingUp },
  { to: "/despesas", label: "Despesas", icon: Receipt },
  { to: "/carteira", label: "Carteira", icon: Wallet },
  { to: "/mais", label: "Mais", icon: Menu },
] as const;

export function useSignOut() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  return async () => {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };
}

export function ThemeToggle({ className }: { className?: string }) {
  const { theme, toggle } = useTheme();
  return (
    <Button variant="ghost" size="icon" onClick={toggle} aria-label="Alternar tema" className={className}>
      {theme === "dark" ? <Sun /> : <Moon />}
    </Button>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const signOut = useSignOut();
  const { data: profile } = useProfile();
  const first = profile?.full_name?.split(" ")[0];

  return (
    <div className="min-h-dvh bg-background">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col bg-sidebar text-sidebar-foreground lg:flex">
        <div className="flex items-center gap-3 px-5 py-6">
          <Logo className="size-10" />
          <div>
            <div className="font-display text-lg font-bold leading-tight">Entregador Pro</div>
            <div className="text-xs opacity-70">Seu dinheiro, organizado</div>
          </div>
        </div>
        <nav className="flex-1 space-y-1 overflow-y-auto px-3">
          {NAV_ITEMS.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium opacity-80 transition hover:bg-sidebar-accent hover:opacity-100"
              activeProps={{ className: "bg-sidebar-accent !opacity-100 text-sidebar-primary" }}
            >
              <item.icon className="size-[18px]" />
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2 border-t border-sidebar-border p-3">
          <div className="min-w-0 flex-1 truncate px-2 text-sm">{first ? `Olá, ${first}` : ""}</div>
          <ThemeToggle className="text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-foreground" />
          <Button
            variant="ghost"
            size="icon"
            onClick={signOut}
            aria-label="Sair"
            className="text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-foreground"
          >
            <LogOut />
          </Button>
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-20 flex items-center justify-between border-b bg-background/90 px-4 py-3 backdrop-blur lg:hidden">
        <Link to="/painel" className="flex items-center gap-2.5">
          <Logo className="size-8" />
          <span className="whitespace-nowrap font-display text-base font-bold">Entregador Pro</span>
        </Link>
        <div className="flex items-center gap-1">
          <Link
            to="/noticias/thassi"
            aria-label="Falar com a Thassi"
            className="flex items-center gap-1.5 rounded-full border bg-card p-1 text-sm font-semibold shadow-soft min-[400px]:pr-3"
          >
            <ThassiAvatar className="size-7 ring-1" />
            <span className="hidden min-[400px]:inline">Thassi</span>
          </Link>
          <ThemeToggle />
          <Button variant="ghost" size="icon" asChild aria-label="Perfil">
            <Link to="/perfil">
              <UserRound />
            </Link>
          </Button>
        </div>
      </header>

      <main className="pb-safe mx-auto max-w-6xl px-4 pt-5 lg:ml-64 lg:px-8 lg:pb-12 lg:pt-8 xl:mx-auto xl:pl-72">
        {children}
      </main>

      {/* Mobile bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t bg-card/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden">
        <div className="grid grid-cols-5">
          {BOTTOM.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="flex min-h-16 flex-col items-center justify-center gap-1 text-[11px] font-semibold text-muted-foreground"
              activeProps={{ className: "!text-primary" }}
            >
              <item.icon className="size-[22px]" />
              {item.label}
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
}
