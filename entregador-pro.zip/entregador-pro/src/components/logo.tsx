import { cn } from "@/lib/utils";

/** Brand mark: a road arrow in amber on deep green. */
export function Logo({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={cn("shrink-0", className)} aria-hidden="true">
      <rect width="48" height="48" rx="14" className="fill-primary" />
      <path d="M14 33 L24 13 L34 33 L24 27 Z" className="fill-highlight" />
      <circle cx="24" cy="37" r="2.2" className="fill-primary-foreground" />
    </svg>
  );
}
