import { Link } from "@tanstack/react-router";
import { MessageCircle, Newspaper, Radio, Settings2 } from "lucide-react";
import thassiAvatar from "@/assets/thassi-avatar.jpg";
import { cn } from "@/lib/utils";

const TABS = [
  { to: "/noticias", label: "Notícias", icon: Newspaper },
  { to: "/noticias/thassi", label: "Thassi", icon: MessageCircle },
  { to: "/noticias/boletins", label: "Boletins", icon: Radio },
  { to: "/noticias/ajustes", label: "Ajustes", icon: Settings2 },
] as const;

export function ThassiAvatar({ className }: { className?: string }) {
  return (
    <img
      src={thassiAvatar}
      alt="Thassi, assistente do Nels Nere"
      width={816}
      height={816}
      loading="lazy"
      className={cn("size-10 shrink-0 rounded-full object-cover ring-2 ring-accent/60", className)}
    />
  );
}

/** Header + tabs shared by every Nels Nere page. */
export function NelsHeader({ subtitle, action }: { subtitle: string; action?: React.ReactNode }) {
  return (
    <div className="mb-4 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <ThassiAvatar className="size-12" />
          <div className="min-w-0">
            <h1 className="font-display text-2xl font-bold leading-tight tracking-tight">
              Nels <span className="text-primary">Nere</span>
            </h1>
            <p className="truncate text-sm text-muted-foreground">{subtitle}</p>
          </div>
        </div>
        {action}
      </div>
      <nav className="-mx-1 flex gap-1 overflow-x-auto px-1 pb-1" aria-label="Seções do Nels Nere">
        {TABS.map((t) => (
          <Link
            key={t.to}
            to={t.to}
            activeOptions={{ exact: t.to === "/noticias", includeSearch: false }}
            className="inline-flex min-h-10 shrink-0 items-center gap-1.5 rounded-full border bg-card px-3.5 text-sm font-semibold text-muted-foreground transition-colors hover:bg-accent/40"
            activeProps={{ className: "!border-primary !bg-primary !text-primary-foreground" }}
          >
            <t.icon className="size-4" />
            {t.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}

export function TogglePills<T extends string>({
  options,
  value,
  onChange,
  label,
}: {
  options: { value: T; label: string }[];
  value: T[];
  onChange: (v: T[]) => void;
  label: string;
}) {
  return (
    <div className="flex flex-wrap gap-2" role="group" aria-label={label}>
      {options.map((o) => {
        const on = value.includes(o.value);
        return (
          <button
            key={o.value}
            type="button"
            aria-pressed={on}
            onClick={() => onChange(on ? value.filter((v) => v !== o.value) : [...value, o.value])}
            className={cn(
              "min-h-10 rounded-full border px-3.5 text-sm font-medium transition-colors",
              on ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:bg-accent/40",
            )}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}
