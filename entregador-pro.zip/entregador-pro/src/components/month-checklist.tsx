import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { addMonths, endOfMonth, format, startOfMonth } from "date-fns";
import { Check, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ConfirmDelete, Panel, SegmentedControl, StatusBadge } from "@/components/common";
import { useBillOccurrences, useContracts, type BillOccurrenceView } from "@/hooks/use-derived";
import { useQuickPay } from "@/hooks/use-quick-pay";
import type { Installment } from "@/lib/db";
import { installmentStatus, remainingOf, type BillStatus, type InstallmentStatus } from "@/lib/finance";
import { dateBR, monthLabel, money, todayISO } from "@/lib/format";
import { cn } from "@/lib/utils";

type Item =
  | { type: "bill"; key: string; due: string; title: string; sub: string; amount: number; status: BillStatus; paid: boolean; occ: BillOccurrenceView }
  | {
      type: "installment";
      key: string;
      due: string;
      title: string;
      sub: string;
      amount: number;
      status: InstallmentStatus;
      paid: boolean;
      inst: Installment;
      kind: "sale" | "loan";
      contractId: string;
    };

type Filter = "todos" | "contas" | "vendas" | "emprestimos";

/**
 * Everything due in a month — bills to pay and sale/loan installments to receive —
 * with a one-tap check to mark as paid (and uncheck to undo).
 */
export function MonthChecklist({ title = "Contas e parcelas do mês" }: { title?: string }) {
  const [offset, setOffset] = useState(0);
  const [filter, setFilter] = useState<Filter>("todos");
  const today = todayISO();
  const month = addMonths(new Date(), offset);
  const range = { start: format(startOfMonth(month), "yyyy-MM-dd"), end: format(endOfMonth(month), "yyyy-MM-dd") };
  const { occurrences } = useBillOccurrences(range);
  const { contracts } = useContracts();
  const q = useQuickPay();

  const items = useMemo<Item[]>(() => {
    const out: Item[] = occurrences.map((o) => ({
      type: "bill",
      key: `b-${o.bill.id}-${o.reference_month}`,
      due: o.due_date,
      title: o.bill.name,
      sub: `Conta · ${o.bill.category}`,
      amount: Number(o.payment?.paid_amount ?? o.bill.expected_amount),
      status: o.status,
      paid: !!o.payment,
      occ: o,
    }));
    for (const c of contracts) {
      for (const i of c.installments) {
        if (i.due_date < range.start || i.due_date > range.end) continue;
        const st = installmentStatus(i, today);
        out.push({
          type: "installment",
          key: `i-${i.id}`,
          due: i.due_date,
          title: c.name,
          sub: `${c.kind === "sale" ? "Venda" : "Empréstimo"} · parcela ${i.number}/${c.installments.length}`,
          amount: st === "pago" ? Number(i.amount) : remainingOf(i),
          status: st,
          paid: st === "pago",
          inst: i,
          kind: c.kind,
          contractId: c.id,
        });
      }
    }
    return out.sort((a, b) => Number(a.paid) - Number(b.paid) || a.due.localeCompare(b.due));
  }, [occurrences, contracts, range.start, range.end, today]);

  const shown = items.filter((it) =>
    filter === "todos" ? true : filter === "contas" ? it.type === "bill" : it.type === "installment" && it.kind === (filter === "vendas" ? "sale" : "loan"),
  );
  const doneCount = shown.filter((i) => i.paid).length;

  function check(it: Item) {
    if (it.type === "bill") q.payBill.mutate(it.occ);
    else q.payInstallment.mutate(it.inst);
  }
  function uncheck(it: Item) {
    if (it.type === "bill") q.unpayBill.mutate(it.occ);
    else q.unpayInstallment.mutate(it.inst);
  }

  return (
    <Panel
      title={title}
      action={
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon-sm" aria-label="Mês anterior" onClick={() => setOffset((o) => o - 1)}>
            <ChevronLeft />
          </Button>
          <span className="inline-block min-w-28 text-center text-sm font-semibold first-letter:uppercase">{monthLabel(range.start)}</span>
          <Button variant="ghost" size="icon-sm" aria-label="Próximo mês" onClick={() => setOffset((o) => o + 1)}>
            <ChevronRight />
          </Button>
        </div>
      }
    >
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div className="overflow-x-auto">
          <SegmentedControl
            value={filter}
            onChange={setFilter}
            options={[
              { value: "todos", label: "Tudo" },
              { value: "contas", label: "Contas" },
              { value: "vendas", label: "Vendas" },
              { value: "emprestimos", label: "Empréstimos" },
            ]}
          />
        </div>
        <span className="text-xs font-semibold text-muted-foreground">
          {doneCount}/{shown.length} pagos
        </span>
      </div>
      {shown.length === 0 ? (
        <p className="py-6 text-center text-sm text-muted-foreground">Nada vence neste mês.</p>
      ) : (
        <ul className="divide-y rounded-xl border">
          {shown.map((it) => (
            <li key={it.key} className={cn("flex items-center gap-3 p-3", it.paid && "bg-muted/40")}>
              {it.paid ? (
                <ConfirmDelete
                  title="Desmarcar como paga?"
                  description={
                    it.type === "bill"
                      ? "A conta volta a ficar pendente neste mês."
                      : "Todos os pagamentos registrados nesta parcela serão desfeitos."
                  }
                  confirmLabel="Desmarcar"
                  onConfirm={() => uncheck(it)}
                  trigger={
                    <button
                      aria-label={`Desmarcar ${it.title}`}
                      disabled={q.busy}
                      className="grid size-9 shrink-0 place-items-center rounded-full bg-success text-success-foreground"
                    >
                      <Check className="size-5" />
                    </button>
                  }
                />
              ) : (
                <button
                  aria-label={`Marcar ${it.title} como paga`}
                  disabled={q.busy}
                  onClick={() => check(it)}
                  className="size-9 shrink-0 rounded-full border-2 border-input transition hover:border-primary hover:bg-primary/10 disabled:opacity-50"
                />
              )}
              <div className="min-w-0 flex-1">
                <p className={cn("truncate font-semibold", it.paid && "text-muted-foreground line-through")}>
                  {it.type === "installment" ? (
                    it.kind === "sale" ? (
                      <Link to="/vendas/$id" params={{ id: it.contractId }} className="hover:underline">
                        {it.title}
                      </Link>
                    ) : (
                      <Link to="/emprestimos/$id" params={{ id: it.contractId }} className="hover:underline">
                        {it.title}
                      </Link>
                    )
                  ) : (
                    it.title
                  )}
                </p>
                <p className="truncate text-xs text-muted-foreground">
                  {it.sub} · {dateBR(it.due)}
                </p>
              </div>
              <div className="flex shrink-0 flex-col items-end gap-1">
                <span className={cn("text-sm font-bold tabular", it.type === "installment" ? "text-income" : "text-expense")}>
                  {it.type === "installment" ? "+" : "−"}
                  {money(it.amount)}
                </span>
                <StatusBadge status={it.status} />
              </div>
            </li>
          ))}
        </ul>
      )}
      <p className="mt-3 text-xs text-muted-foreground">
        Toque no círculo para marcar como paga com o valor total na data de hoje. Para valor parcial ou outra data, abra a venda, o empréstimo ou a conta.
      </p>
    </Panel>
  );
}
