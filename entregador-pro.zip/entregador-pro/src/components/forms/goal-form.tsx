import { useEffect, useState } from "react";
import { format, startOfMonth } from "date-fns";
import { z } from "zod";
import { Field, FormDialog, MoneyInput, SegmentedControl, TextArea, TextInput } from "@/components/common";
import { useInsert, useUpdate } from "@/hooks/use-data";
import { newId, type Goal } from "@/lib/db";
import { goalEndDate, type DurationUnit, type GoalBasis, type GoalKind } from "@/lib/finance";
import { dateBR, money, parseMoney, todayISO } from "@/lib/format";
import { cn } from "@/lib/utils";

export const WEEKDAYS = [
  { value: 1, short: "S", label: "Segunda" },
  { value: 2, short: "T", label: "Terça" },
  { value: 3, short: "Q", label: "Quarta" },
  { value: 4, short: "Q", label: "Quinta" },
  { value: 5, short: "S", label: "Sexta" },
  { value: 6, short: "S", label: "Sábado" },
  { value: 0, short: "D", label: "Domingo" },
] as const;

export const BASIS_LABEL: Record<GoalBasis, string> = {
  lucro: "Ganho real (ganhos − gastos)",
  ganhos: "Só os ganhos",
  guardado: "Dinheiro que eu guardar",
};

const schema = z
  .object({
    name: z.string().trim().min(1, "Dê um nome para a meta").max(80, "Use até 80 letras"),
    kind: z.enum(["mensal", "objetivo"]),
    target_amount: z.number({ message: "Informe o valor" }).positive("Informe um valor maior que zero"),
    basis: z.enum(["lucro", "ganhos", "guardado"]),
    start_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Escolha a data de início"),
    end_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable(),
    work_weekdays: z.array(z.number().int().min(0).max(6)),
    notes: z.string().trim().max(1000).nullable(),
  })
  .refine((v) => v.kind === "mensal" || !!v.end_date, { path: ["end_date"], message: "Informe o prazo" })
  .refine((v) => !v.end_date || v.end_date >= v.start_date, { path: ["end_date"], message: "O fim deve ser depois do início" });

export function GoalForm({
  open,
  onOpenChange,
  record,
  defaultKind = "mensal",
  onSaved,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  record?: Goal | null | undefined;
  defaultKind?: GoalKind;
  onSaved?: (id: string) => void;
}) {
  const insert = useInsert("goals", "Meta salva");
  const update = useUpdate("goals", "Meta atualizada");
  const [id, setId] = useState(newId());
  const [kind, setKind] = useState<GoalKind>(defaultKind);
  const [name, setName] = useState("");
  const [amount, setAmount] = useState("");
  const [basis, setBasis] = useState<GoalBasis>("lucro");
  const [start, setStart] = useState(todayISO());
  const [end, setEnd] = useState("");
  const [duration, setDuration] = useState("");
  const [unit, setUnit] = useState<DurationUnit>("meses");
  const [weekdays, setWeekdays] = useState<number[]>([1, 2, 3, 4, 5, 6]);
  const [notes, setNotes] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!open) return;
    const k = (record?.kind as GoalKind | undefined) ?? defaultKind;
    setErrors({});
    setId(record?.id ?? newId());
    setKind(k);
    setName(record?.name ?? "");
    setAmount(record ? String(record.target_amount).replace(".", ",") : "");
    setBasis((record?.basis as GoalBasis | undefined) ?? (k === "mensal" ? "lucro" : "guardado"));
    setStart(record?.start_date ?? (k === "mensal" ? format(startOfMonth(new Date()), "yyyy-MM-dd") : todayISO()));
    setEnd(record?.end_date ?? "");
    setDuration("");
    setUnit("meses");
    setWeekdays(record?.work_weekdays ?? [1, 2, 3, 4, 5, 6]);
    setNotes(record?.notes ?? "");
  }, [open, record, defaultKind]);

  function changeKind(k: GoalKind) {
    setKind(k);
    if (!record) {
      setBasis(k === "mensal" ? "lucro" : "guardado");
      setStart(k === "mensal" ? format(startOfMonth(new Date()), "yyyy-MM-dd") : todayISO());
    }
  }

  function applyDuration(nextDuration: string, nextUnit: DurationUnit, nextStart = start) {
    const n = Number(nextDuration);
    if (Number.isInteger(n) && n >= 1 && n <= 3650 && nextStart) setEnd(goalEndDate(nextStart, n, nextUnit));
  }

  function submit() {
    const parsed = schema.safeParse({
      name,
      kind,
      target_amount: parseMoney(amount),
      basis,
      start_date: start,
      end_date: kind === "objetivo" ? end || null : null,
      work_weekdays: weekdays,
      notes: notes.trim() || null,
    });
    if (!parsed.success) {
      const e: Record<string, string> = {};
      parsed.error.issues.forEach((i) => (e[String(i.path[0])] = i.message));
      return setErrors(e);
    }
    const done = {
      onSuccess: () => {
        onOpenChange(false);
        onSaved?.(record?.id ?? id);
      },
    };
    if (record) update.mutate({ id: record.id, values: parsed.data }, done);
    else insert.mutate({ id, ...parsed.data }, done);
  }

  return (
    <FormDialog
      open={open}
      onOpenChange={onOpenChange}
      title={record ? "Editar meta" : "Nova meta"}
      description="O app calcula quanto você precisa fazer em cada dia de trabalho."
      onSubmit={submit}
      pending={insert.isPending || update.isPending}
    >
      <SegmentedControl
        value={kind}
        onChange={changeKind}
        options={[
          { value: "mensal", label: "Meta do mês" },
          { value: "objetivo", label: "Objetivo com prazo" },
        ]}
      />
      <Field label="Nome" error={errors["name"]}>
        <TextInput
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder={kind === "mensal" ? "Ex.: Meta mensal" : "Ex.: Reformar a casa"}
          maxLength={80}
        />
      </Field>
      <Field
        label={kind === "mensal" ? "Quanto quer fazer por mês" : "Valor total do objetivo"}
        error={errors["target_amount"]}
      >
        <MoneyInput value={amount} onChange={(e) => setAmount(e.target.value)} />
      </Field>

      {kind === "objetivo" ? (
        <>
          <Field label="Começa em" error={errors["start_date"]}>
            <TextInput
              type="date"
              value={start}
              onChange={(e) => {
                setStart(e.target.value);
                if (duration) applyDuration(duration, unit, e.target.value);
              }}
            />
          </Field>
          <div className="grid grid-cols-[1fr_auto] items-end gap-3">
            <Field label="Dividir em">
              <TextInput
                inputMode="numeric"
                value={duration}
                placeholder="Ex.: 12"
                onChange={(e) => {
                  const v = e.target.value.replace(/\D/g, "").slice(0, 4);
                  setDuration(v);
                  applyDuration(v, unit);
                }}
              />
            </Field>
            <SegmentedControl
              value={unit}
              onChange={(u) => {
                setUnit(u);
                applyDuration(duration, u);
              }}
              options={[
                { value: "dias", label: "Dias" },
                { value: "meses", label: "Meses" },
                { value: "anos", label: "Anos" },
              ]}
            />
          </div>
          <Field
            label="Termina em"
            error={errors["end_date"]}
            hint={end && parseMoney(amount) > 0 ? `Prazo até ${dateBR(end)} para juntar ${money(parseMoney(amount))}.` : undefined}
          >
            <TextInput type="date" value={end} min={start} onChange={(e) => setEnd(e.target.value)} />
          </Field>
        </>
      ) : (
        <Field label="Começa no mês de" error={errors["start_date"]} hint="A meta se repete todo mês a partir daqui.">
          <TextInput type="date" value={start} onChange={(e) => setStart(e.target.value)} />
        </Field>
      )}

      <Field label="O que conta para a meta">
        <div className="grid gap-2">
          {(Object.keys(BASIS_LABEL) as GoalBasis[]).map((b) => (
            <button
              key={b}
              type="button"
              onClick={() => setBasis(b)}
              className={cn(
                "min-h-11 rounded-xl border px-3 text-left text-sm font-medium transition-colors",
                basis === b ? "border-primary bg-primary/10 text-foreground" : "bg-card hover:bg-accent",
              )}
            >
              {BASIS_LABEL[b]}
            </button>
          ))}
        </div>
      </Field>
      <p className="-mt-2 text-xs text-muted-foreground">
        {basis === "guardado"
          ? "Você registra na meta cada valor que separar para ela."
          : "Atualiza sozinha com os ganhos" + (basis === "lucro" ? " e gastos" : "") + " que você lançar."}
      </p>

      <Field label="Dias em que vou trabalhar" hint="Depois você pode marcar ou desmarcar dias específicos no calendário da meta.">
        <div className="flex flex-wrap gap-1.5" role="group" aria-label="Dias da semana">
          {WEEKDAYS.map((d) => {
            const on = weekdays.includes(d.value);
            return (
              <button
                key={d.value}
                type="button"
                aria-pressed={on}
                aria-label={d.label}
                title={d.label}
                onClick={() => setWeekdays((w) => (on ? w.filter((x) => x !== d.value) : [...w, d.value].sort()))}
                className={cn(
                  "grid size-11 place-items-center rounded-full border text-sm font-bold transition-colors",
                  on ? "border-primary bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:bg-accent",
                )}
              >
                {d.short}
              </button>
            );
          })}
        </div>
      </Field>
      <Field label="Observações (opcional)">
        <TextArea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} maxLength={1000} />
      </Field>
    </FormDialog>
  );
}
