import { useEffect, useRef, useState } from "react";
import { Camera, ImagePlus, X } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Field, FormDialog, TextArea, TextInput } from "@/components/common";
import { supabase } from "@/integrations/supabase/client";
import { useInvalidateAll } from "@/hooks/use-data";
import { useAuth } from "@/hooks/use-auth";
import { compressImage, PHOTO_BUCKET, useSignedUrls } from "@/hooks/use-photos";
import { errorMessage, isDuplicate, newId, type Workplace } from "@/lib/db";

const schema = z.object({
  name: z.string().trim().min(1, "Informe o nome do local").max(120),
  start_date: z.string().nullable(),
});

export function WorkplaceForm({ open, onOpenChange, record }: { open: boolean; onOpenChange: (o: boolean) => void; record?: Workplace | null }) {
  const { user } = useAuth();
  const invalidate = useInvalidateAll();
  const [id, setId] = useState(newId());
  const [v, setV] = useState({ name: "", address: "", app_used: "", notes: "", start_date: "" });
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [removePhoto, setRemovePhoto] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState(false);
  const galleryRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);
  const existing = useSignedUrls(record?.photo_path ? [record.photo_path] : []);

  useEffect(() => {
    if (!open) return;
    setId(record?.id ?? newId());
    setErrors({});
    setFile(null);
    setPreview(null);
    setRemovePhoto(false);
    setV({
      name: record?.name ?? "",
      address: record?.address ?? "",
      app_used: record?.app_used ?? "",
      notes: record?.notes ?? "",
      start_date: record?.start_date ?? "",
    });
  }, [open, record]);

  useEffect(() => {
    if (!file) return undefined;
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const set = (k: keyof typeof v) => (val: string) => setV((s) => ({ ...s, [k]: val }));

  function pick(f: File | undefined) {
    if (!f) return;
    if (!f.type.startsWith("image/")) {
      toast.error("Escolha uma imagem");
      return;
    }
    if (f.size > 15 * 1024 * 1024) {
      toast.error("Imagem muito grande (máx. 15 MB)");
      return;
    }
    setFile(f);
    setRemovePhoto(false);
  }

  async function submit() {
    const parsed = schema.safeParse({ name: v.name, start_date: v.start_date || null });
    if (!parsed.success) {
      const e: Record<string, string> = {};
      parsed.error.issues.forEach((i) => (e[String(i.path[0])] = i.message));
      return setErrors(e);
    }
    if (!user) return;
    setPending(true);
    try {
      let photo_path = record?.photo_path ?? null;
      if (file) {
        const blob = await compressImage(file);
        const path = `${user.id}/${id}-${Date.now()}.jpg`;
        const { error } = await supabase.storage.from(PHOTO_BUCKET).upload(path, blob, { contentType: "image/jpeg", upsert: false });
        if (error) throw error;
        if (record?.photo_path) await supabase.storage.from(PHOTO_BUCKET).remove([record.photo_path]);
        photo_path = path;
      } else if (removePhoto && record?.photo_path) {
        await supabase.storage.from(PHOTO_BUCKET).remove([record.photo_path]);
        photo_path = null;
      }
      const values = {
        name: parsed.data.name,
        start_date: parsed.data.start_date,
        address: v.address.trim() || null,
        app_used: v.app_used.trim() || null,
        notes: v.notes.trim() || null,
        photo_path,
      };
      const { error } = record
        ? await supabase.from("workplaces").update(values).eq("id", record.id)
        : await supabase.from("workplaces").insert({ id, ...values });
      if (error && !isDuplicate(error)) throw error;
      toast.success("Local salvo");
      invalidate();
      onOpenChange(false);
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setPending(false);
    }
  }

  const shown = preview ?? (!removePhoto && record?.photo_path ? existing.data?.[record.photo_path] : null);

  return (
    <FormDialog open={open} onOpenChange={onOpenChange} title={record ? "Editar local" : "Novo local de trabalho"} onSubmit={submit} pending={pending}>
      <Field label="Foto do local">
        {shown ? (
          <div className="relative overflow-hidden rounded-xl">
            <img src={shown} alt="Foto do local" className="aspect-video w-full object-cover" />
            <Button
              type="button"
              variant="secondary"
              size="icon-sm"
              className="absolute right-2 top-2"
              aria-label="Remover foto"
              onClick={() => {
                setFile(null);
                setPreview(null);
                setRemovePhoto(true);
              }}
            >
              <X />
            </Button>
          </div>
        ) : null}
        <div className="grid grid-cols-2 gap-2">
          <Button type="button" variant="outline" onClick={() => cameraRef.current?.click()}>
            <Camera /> Tirar foto
          </Button>
          <Button type="button" variant="outline" onClick={() => galleryRef.current?.click()}>
            <ImagePlus /> Galeria
          </Button>
        </div>
        <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => pick(e.target.files?.[0])} />
        <input ref={galleryRef} type="file" accept="image/*" className="hidden" onChange={(e) => pick(e.target.files?.[0])} />
      </Field>
      <Field label="Nome do local" error={errors["name"]}>
        <TextInput value={v.name} onChange={(e) => set("name")(e.target.value)} placeholder="Ex.: Shopping Norte" />
      </Field>
      <Field label="Endereço ou descrição">
        <TextInput value={v.address} onChange={(e) => set("address")(e.target.value)} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Aplicativo usado">
          <TextInput value={v.app_used} onChange={(e) => set("app_used")(e.target.value)} placeholder="Ex.: iFood" />
        </Field>
        <Field label="Início (opcional)">
          <TextInput type="date" value={v.start_date} onChange={(e) => set("start_date")(e.target.value)} />
        </Field>
      </div>
      <Field label="Observações">
        <TextArea value={v.notes} onChange={(e) => set("notes")(e.target.value)} maxLength={500} />
      </Field>
    </FormDialog>
  );
}
