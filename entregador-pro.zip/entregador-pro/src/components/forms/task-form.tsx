import { useEffect, useState } from "react";
import { z } from "zod";
import { Field, FormDialog, TextArea, TextInput } from "@/components/common";
import { useInsert, useUpdate } from "@/hooks/use-data";
import { newId, type Task } from "@/lib/db";
import { todayISO } from "@/lib/format";

const schema = z.object({
  title: z.string().trim().min(1, "Escreva a tarefa").max(120, "Use até 120 letras"),
  due_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Escolha a data"),
  due_time: z
    .string()
    .regex(/^\d{2}:\d{2}$/, "Horário inválido")
    .nullable(),
  notes: z.string().trim().max(1000).nullable(),
});

export function TaskForm({
  open,
  onOpenChange,
  record,
  defaultDate,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  record?: Task | null | undefined;
  defaultDate?: string | undefined;
}) {
  const insert = useInsert("tasks", "Tarefa salva");
  const update = useUpdate("tasks", "Tarefa atualizada");
  const [id, setId] = useState(newId());
  const [v, setV] = useState({ title: "", due_date: todayISO(), due_time: "", notes: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!open) return;
    setErrors({});
    setId(record?.id ?? newId());
    setV({
      title: record?.title ?? "",
      due_date: record?.due_date ?? defaultDate ?? todayISO(),
      due_time: record?.due_time?.slice(0, 5) ?? "",
      notes: record?.notes ?? "",
    });
  }, [open, record, defaultDate]);

  const set = (k: keyof typeof v) => (e: { target: { value: string } }) => setV((s) => ({ ...s, [k]: e.target.value }));

  function submit() {
    const parsed = schema.safeParse({ ...v, due_time: v.due_time || null, notes: v.notes.trim() || null });
    if (!parsed.success) {
      const e: Record<string, string> = {};
      parsed.error.issues.forEach((i) => (e[String(i.path[0])] = i.message));
      return setErrors(e);
    }
    const done = { onSuccess: () => onOpenChange(false) };
    if (record) update.mutate({ id: record.id, values: parsed.data }, done);
    else insert.mutate({ id, ...parsed.data }, done);
  }

  return (
    <FormDialog
      open={open}
      onOpenChange={onOpenChange}
      title={record ? "Editar tarefa" : "Nova tarefa"}
      description="A tarefa aparece no calendário no dia escolhido."
      onSubmit={submit}
      pending={insert.isPending || update.isPending}
    >
      <Field label="Tarefa" error={errors["title"]}>
        <TextInput value={v.title} onChange={set("title")} placeholder="Ex.: Trocar o óleo da moto" maxLength={120} autoFocus />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Data" error={errors["due_date"]}>
          <TextInput type="date" value={v.due_date} onChange={set("due_date")} />
        </Field>
        <Field label="Horário (opcional)" error={errors["due_time"]}>
          <TextInput type="time" value={v.due_time} onChange={set("due_time")} />
        </Field>
      </div>
      <Field label="Observações (opcional)" error={errors["notes"]}>
        <TextArea value={v.notes} onChange={set("notes")} rows={3} maxLength={1000} />
      </Field>
    </FormDialog>
  );
}
