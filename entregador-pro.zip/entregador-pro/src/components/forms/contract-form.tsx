import { useEffect, useMemo, useState } from "react";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { Field, FormDialog, MoneyInput, TextArea, TextInput } from "@/components/common";
import { supabase } from "@/integrations/supabase/client";
import { useInvalidateAll } from "@/hooks/use-data";
import { errorMessage, isDuplicate, newId } from "@/lib/db";
import { buildInstallments, financedAmount, loanTotal } from "@/lib/finance";
import { dateBR, money, parseDecimal, parseMoney, todayISO } from "@/lib/format";
import { toE164BR } from "@/lib/phone";
import { addMonths, format } from "date-fns";

type Kind = "sale" | "loan";

const phoneSchema = z
  .string()
  .trim()
  .refine((p) => p === "" || toE164BR(p) !== null, "Telefone inválido");

const saleSchema = z
  .object({
    customer_name: z.string().trim().min(1, "Informe o cliente").max(120),
    customer_phone: phoneSchema,
    description: z.string().trim().min(1, "Descreva a venda").max(200),
    total: z.number({ invalid_type_error: "Valor inválido" }).positive("Informe o valor total"),
    down_payment: z.number({ invalid_type_error: "Valor inválido" }).min(0),
    installments_count: z.number().int().min(1, "Mínimo 1").max(120, "Máximo 120"),
    sale_date: z.string().min(10, "Data inválida"),
    first_due_date: z.string().min(10, "Data inválida"),
  })
  .refine((v) => v.down_payment < v.total, { path: ["down_payment"], message: "Entrada deve ser menor que o total" });

const loanSchema = z
  .object({
    person_name: z.string().trim().min(1, "Informe a pessoa").max(120),
    person_phone: phoneSchema,
    principal: z.number({ invalid_type_error: "Valor inválido" }).positive("Informe o valor emprestado"),
    interest_rate: z.number().min(0, "Juros não pode ser negativo").max(1000).nullable(),
    total_due: z.number({ invalid_type_error: "Valor inválido" }).positive("Informe o total a devolver"),
    installments_count: z.number().int().min(1, "Mínimo 1").max(120, "Máximo 120"),
    loan_date: z.string().min(10, "Data inválida"),
    first_due_date: z.string().min(10, "Data inválida"),
  });

const nextMonth = () => format(addMonths(new Date(), 1), "yyyy-MM-dd");

export function ContractForm({ kind, open, onOpenChange, onCreated }: { kind: Kind; open: boolean; onOpenChange: (o: boolean) => void; onCreated?: (id: string) => void }) {
  const invalidate = useInvalidateAll();
  const [id, setId] = useState(newId());
  const [v, setV] = useState({
    name: "",
    phone: "",
    description: "",
    total: "",
    down: "",
    rate: "",
    totalDue: "",
    totalDueTouched: false,
    count: "1",
    date: todayISO(),
    firstDue: nextMonth(),
    notes: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!open) return;
    setId(newId());
    setErrors({});
    setV({ name: "", phone: "", description: "", total: "", down: "", rate: "", totalDue: "", totalDueTouched: false, count: "1", date: todayISO(), firstDue: nextMonth(), notes: "" });
  }, [open]);

  const set = (k: keyof typeof v) => (val: string) => setV((s) => ({ ...s, [k]: val }));

  const rate = parseDecimal(v.rate);
  const principal = parseMoney(v.total);
  const autoTotalDue = kind === "loan" && principal > 0 ? loanTotal(principal, rate ?? null) : NaN;
  const totalDue = kind === "loan" ? (v.totalDueTouched ? parseMoney(v.totalDue) : autoTotalDue) : NaN;
  const financed = kind === "sale" ? financedAmount(parseMoney(v.total) || 0, parseMoney(v.down || "0") || 0) : totalDue;
  const count = Number(v.count);

  const preview = useMemo(() => {
    try {
      if (!(financed > 0) || !Number.isInteger(count) || count < 1 || count > 120 || !v.firstDue) return [];
      return buildInstallments(financed, count, v.firstDue);
    } catch {
      return [];
    }
  }, [financed, count, v.firstDue]);

  const create = useMutation({
    mutationFn: async () => {
      if (kind === "sale") {
        const parsed = saleSchema.safeParse({
          customer_name: v.name,
          customer_phone: v.phone,
          description: v.description,
          total: parseMoney(v.total),
          down_payment: v.down ? parseMoney(v.down) : 0,
          installments_count: count,
          sale_date: v.date,
          first_due_date: v.firstDue,
        });
        if (!parsed.success) throw parsed.error;
        const d = parsed.data;
        const inst = buildInstallments(financedAmount(d.total, d.down_payment), d.installments_count, d.first_due_date);
        const { error } = await supabase.rpc("create_sale_with_installments", {
          p_sale: { id, ...d, customer_phone: d.customer_phone ? toE164BR(d.customer_phone) : "", notes: v.notes },
          p_installments: inst as never,
        });
        if (error && !isDuplicate(error)) throw error;
      } else {
        const parsed = loanSchema.safeParse({
          person_name: v.name,
          person_phone: v.phone,
          principal: parseMoney(v.total),
          interest_rate: rate === null ? null : rate,
          total_due: totalDue,
          installments_count: count,
          loan_date: v.date,
          first_due_date: v.firstDue,
        });
        if (!parsed.success) throw parsed.error;
        const d = parsed.data;
        const inst = buildInstallments(d.total_due, d.installments_count, d.first_due_date);
        const { error } = await supabase.rpc("create_loan_with_installments", {
          p_loan: {
            id,
            ...d,
            interest_rate: d.interest_rate === null ? "" : String(d.interest_rate),
            person_phone: d.person_phone ? toE164BR(d.person_phone) : "",
            notes: v.notes,
          },
          p_installments: inst as never,
        });
        if (error && !isDuplicate(error)) throw error;
      }
    },
    onSuccess: () => {
      toast.success(kind === "sale" ? "Venda criada com parcelas" : "Empréstimo criado com parcelas");
      invalidate();
      onOpenChange(false);
      onCreated?.(id);
    },
    onError: (e) => {
      if (e instanceof z.ZodError) {
        const errs: Record<string, string> = {};
        const map: Record<string, string> = {
          customer_name: "name",
          person_name: "name",
          customer_phone: "phone",
          person_phone: "phone",
          principal: "total",
          down_payment: "down",
          interest_rate: "rate",
          total_due: "totalDue",
          installments_count: "count",
          sale_date: "date",
          loan_date: "date",
          first_due_date: "firstDue",
        };
        e.issues.forEach((i) => {
          const k = String(i.path[0]);
          errs[map[k] ?? k] = i.message;
        });
        setErrors(errs);
        return;
      }
      toast.error(errorMessage(e));
    },
  });

  const isSale = kind === "sale";

  return (
    <FormDialog
      open={open}
      onOpenChange={onOpenChange}
      title={isSale ? "Nova venda parcelada" : "Novo empréstimo"}
      description="As parcelas são geradas automaticamente, mês a mês."
      onSubmit={() => create.mutate()}
      pending={create.isPending}
      submitLabel={isSale ? "Criar venda" : "Criar empréstimo"}
    >
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <Field label={isSale ? "Cliente" : "Pessoa"} error={errors["name"]}>
          <TextInput value={v.name} onChange={(e) => set("name")(e.target.value)} />
        </Field>
        <Field label="Telefone (opcional)" error={errors["phone"]}>
          <TextInput type="tel" inputMode="tel" value={v.phone} onChange={(e) => set("phone")(e.target.value)} />
        </Field>
      </div>
      {isSale && (
        <Field label="Produto ou descrição" error={errors["description"]}>
          <TextInput value={v.description} onChange={(e) => set("description")(e.target.value)} />
        </Field>
      )}
      <div className="grid grid-cols-2 gap-3">
        <Field label={isSale ? "Valor total" : "Valor emprestado"} error={errors["total"]}>
          <MoneyInput value={v.total} onChange={(e) => set("total")(e.target.value)} />
        </Field>
        {isSale ? (
          <Field label="Entrada" error={errors["down"]}>
            <MoneyInput value={v.down} onChange={(e) => set("down")(e.target.value)} />
          </Field>
        ) : (
          <Field label="Juros % (opcional)" error={errors["rate"]} hint={rate === null ? "Sem juros" : `Total do acordo`}>
            <TextInput inputMode="decimal" placeholder="Sem juros" value={v.rate} onChange={(e) => set("rate")(e.target.value)} />
          </Field>
        )}
      </div>
      {!isSale && (
        <Field
          label="Valor total combinado para devolução"
          error={errors["totalDue"]}
          hint={v.totalDueTouched ? "Valor definido por você" : "Calculado: valor emprestado + juros informados. Pode alterar."}
        >
          <MoneyInput
            value={v.totalDueTouched ? v.totalDue : Number.isFinite(autoTotalDue) ? String(autoTotalDue).replace(".", ",") : ""}
            onChange={(e) => setV((s) => ({ ...s, totalDue: e.target.value, totalDueTouched: true }))}
          />
        </Field>
      )}
      <div className="grid grid-cols-3 gap-3">
        <Field label="Parcelas" error={errors["count"]}>
          <TextInput inputMode="numeric" value={v.count} onChange={(e) => set("count")(e.target.value.replace(/\D/g, ""))} />
        </Field>
        <Field label={isSale ? "Data venda" : "Data"} error={errors["date"]}>
          <TextInput type="date" value={v.date} onChange={(e) => set("date")(e.target.value)} />
        </Field>
        <Field label="1º vencimento" error={errors["firstDue"]}>
          <TextInput type="date" value={v.firstDue} onChange={(e) => set("firstDue")(e.target.value)} />
        </Field>
      </div>
      <Field label="Observações">
        <TextArea value={v.notes} onChange={(e) => set("notes")(e.target.value)} maxLength={500} />
      </Field>

      {preview.length > 0 && (
        <div className="rounded-xl bg-muted p-3">
          <p className="mb-2 text-sm font-semibold">
            {preview.length}× de {money(preview[0]!.amount)}
            {preview.length > 1 && preview.at(-1)!.amount !== preview[0]!.amount && ` (última ${money(preview.at(-1)!.amount)})`}
            {" · "}total {money(financed)}
          </p>
          <div className="max-h-36 space-y-1 overflow-y-auto text-sm">
            {preview.map((p) => (
              <div key={p.number} className="flex justify-between tabular text-muted-foreground">
                <span>
                  {p.number}ª · {dateBR(p.due_date)}
                </span>
                <span>{money(p.amount)}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </FormDialog>
  );
}
