import { useEffect, useState } from "react";
import { z } from "zod";
import { Switch } from "@/components/ui/switch";
import { ChipSelect, Field, FormDialog, MoneyInput, TextArea, TextInput } from "@/components/common";
import { NativeSelect } from "@/components/native-select";
import { useInsert, useUpdate } from "@/hooks/use-data";
import { newId, type Bill } from "@/lib/db";
import { parseMoney, todayISO } from "@/lib/format";

export const BILL_CATEGORIES = ["Aluguel", "Internet", "Telefone", "Financiamento", "Energia", "Água", "Seguro", "Outros"] as const;
export const INTERVALS = [
  { value: 1, label: "Mensal" },
  { value: 2, label: "Bimestral" },
  { value: 3, label: "Trimestral" },
  { value: 6, label: "Semestral" },
  { value: 12, label: "Anual" },
];

const schema = z.object({
  name: z.string().trim().min(1, "Informe o nome da conta").max(120),
  expected_amount: z.number({ invalid_type_error: "Valor inválido" }).positive("Informe o valor previsto"),
  due_day: z.number().int().min(1, "Dia entre 1 e 31").max(31, "Dia entre 1 e 31"),
  category: z.string().trim().min(1).max(60),
  interval_months: z.number().int(),
  start_month: z.string().regex(/^\d{4}-\d{2}-01$/, "Mês inválido"),
  end_month: z.string().regex(/^\d{4}-\d{2}-01$/).nullable(),
});

export function BillForm({ open, onOpenChange, record }: { open: boolean; onOpenChange: (o: boolean) => void; record?: Bill | null }) {
  const insert = useInsert("bills", "Conta cadastrada");
  const update = useUpdate("bills");
  const [id, setId] = useState(newId());
  const [v, setV] = useState({ name: "", amount: "", due_day: "10", category: "Aluguel", interval: "1", start: todayISO().slice(0, 7), end: "", active: true, notes: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!open) return;
    setErrors({});
    setId(record?.id ?? newId());
    setV({
      name: record?.name ?? "",
      amount: record ? String(record.expected_amount).replace(".", ",") : "",
      due_day: String(record?.due_day ?? 10),
      category: record?.category ?? "Aluguel",
      interval: String(record?.interval_months ?? 1),
      start: (record?.start_month ?? todayISO()).slice(0, 7),
      end: record?.end_month?.slice(0, 7) ?? "",
      active: record?.active ?? true,
      notes: record?.notes ?? "",
    });
  }, [open, record]);

  const set = (k: keyof typeof v) => (val: string) => setV((s) => ({ ...s, [k]: val }));

  function submit() {
    const parsed = schema.safeParse({
      name: v.name,
      expected_amount: parseMoney(v.amount),
      due_day: Number(v.due_day),
      category: v.category || "Outros",
      interval_months: Number(v.interval),
      start_month: `${v.start}-01`,
      end_month: v.end ? `${v.end}-01` : null,
    });
    if (!parsed.success) {
      const e: Record<string, string> = {};
      parsed.error.issues.forEach((i) => (e[String(i.path[0])] = i.message));
      return setErrors(e);
    }
    if (parsed.data.end_month && parsed.data.end_month < parsed.data.start_month) return setErrors({ end_month: "Fim antes do início" });
    const values = { ...parsed.data, active: v.active, notes: v.notes.trim() || null };
    const done = { onSuccess: () => onOpenChange(false) };
    if (record) update.mutate({ id: record.id, values }, done);
    else insert.mutate({ id, ...values }, done);
  }

  return (
    <FormDialog open={open} onOpenChange={onOpenChange} title={record ? "Editar conta" : "Nova conta recorrente"} onSubmit={submit} pending={insert.isPending || update.isPending}>
      <Field label="Nome" error={errors["name"]}>
        <TextInput value={v.name} onChange={(e) => set("name")(e.target.value)} placeholder="Ex.: Aluguel do quarto" />
      </Field>
      <Field label="Categoria">
        <ChipSelect options={BILL_CATEGORIES} value={v.category} onChange={set("category")} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Valor previsto" error={errors["expected_amount"]}>
          <MoneyInput value={v.amount} onChange={(e) => set("amount")(e.target.value)} />
        </Field>
        <Field label="Dia do vencimento" error={errors["due_day"]}>
          <TextInput inputMode="numeric" value={v.due_day} onChange={(e) => set("due_day")(e.target.value.replace(/\D/g, "").slice(0, 2))} />
        </Field>
        <Field label="Recorrência">
          <NativeSelect value={v.interval} onChange={(e) => set("interval")(e.target.value)}>
            {INTERVALS.map((i) => (
              <option key={i.value} value={i.value}>
                {i.label}
              </option>
            ))}
          </NativeSelect>
        </Field>
        <Field label="Começa em" error={errors["start_month"]}>
          <TextInput type="month" value={v.start} onChange={(e) => set("start")(e.target.value)} />
        </Field>
        <Field label="Termina em (opcional)" error={errors["end_month"]}>
          <TextInput type="month" value={v.end} onChange={(e) => set("end")(e.target.value)} />
        </Field>
        <Field label="Ativa">
          <div className="flex h-12 items-center">
            <Switch checked={v.active} onCheckedChange={(c) => setV((s) => ({ ...s, active: c }))} />
          </div>
        </Field>
      </div>
      <Field label="Observações">
        <TextArea value={v.notes} onChange={(e) => set("notes")(e.target.value)} maxLength={500} />
      </Field>
    </FormDialog>
  );
}
