import { useEffect, useState } from "react";
import { z } from "zod";
import { useQueryClient } from "@tanstack/react-query";
import { Field, FormDialog, MoneyInput, TextArea, TextInput, ChipSelect } from "@/components/common";
import { NativeSelect } from "@/components/native-select";
import { SaveShortcutFields, saveShortcut, shortcutError, ShortcutChips } from "@/components/shortcuts";
import { useInsert, useTable, useUpdate } from "@/hooks/use-data";
import { useAuth } from "@/hooks/use-auth";
import { newId, type Earning, type EntryShortcut } from "@/lib/db";
import { parseDecimal, parseMoney, todayISO } from "@/lib/format";

export const EARNING_SOURCES = ["iFood", "99Food", "Rappi", "Uber", "99", "Lalamove", "Loggi", "Particular"] as const;

const schema = z.object({
  source: z.string().trim().min(1, "Informe a fonte do ganho").max(80),
  amount: z.number({ invalid_type_error: "Valor inválido" }).positive("Valor deve ser maior que zero").max(1_000_000),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Data inválida"),
  hours: z.number().min(0).max(24, "Máximo 24h por registro").nullable(),
  km: z.number().min(0).max(5000).nullable(),
});

const fmt = (n: number | null | undefined) => (n == null ? "" : String(n).replace(".", ","));

export function EarningForm({
  open,
  onOpenChange,
  record,
  preset,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  record?: Earning | null | undefined;
  preset?: EntryShortcut | null | undefined;
}) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const insert = useInsert("earnings", "Ganho registrado");
  const update = useUpdate("earnings");
  const { data: workplaces = [] } = useTable("workplaces");
  const [id, setId] = useState(newId());
  const [v, setV] = useState({ source: "", amount: "", date: todayISO(), hours: "", km: "", notes: "", workplace_id: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [asShortcut, setAsShortcut] = useState(false);
  const [shortcutName, setShortcutName] = useState("");

  function applyShortcut(s: EntryShortcut) {
    setV((cur) => ({
      ...cur,
      source: s.topic,
      amount: fmt(s.amount),
      hours: fmt(s.hours),
      km: fmt(s.km),
      notes: s.notes ?? "",
      workplace_id: s.workplace_id ?? "",
    }));
  }

  useEffect(() => {
    if (!open) return;
    setErrors({});
    setAsShortcut(false);
    setShortcutName("");
    setId(record?.id ?? newId());
    setV({
      source: record?.source ?? "",
      amount: record ? fmt(record.amount) : "",
      date: record?.date ?? todayISO(),
      hours: fmt(record?.hours),
      km: fmt(record?.km),
      notes: record?.notes ?? "",
      workplace_id: record?.workplace_id ?? "",
    });
    if (!record && preset) applyShortcut(preset);
  }, [open, record, preset]);

  const set = (k: keyof typeof v) => (val: string) => setV((s) => ({ ...s, [k]: val }));

  function submit() {
    const parsed = schema.safeParse({
      source: v.source,
      amount: parseMoney(v.amount),
      date: v.date,
      hours: parseDecimal(v.hours),
      km: parseDecimal(v.km),
    });
    if (!parsed.success) {
      const e: Record<string, string> = {};
      parsed.error.issues.forEach((i) => (e[String(i.path[0])] = i.message));
      return setErrors(e);
    }
    if (asShortcut && !shortcutName.trim()) return setErrors({ shortcut: "Dê um nome ao atalho" });
    const values = { ...parsed.data, notes: v.notes.trim() || null, workplace_id: v.workplace_id || null };
    const done = {
      onSuccess: async () => {
        if (asShortcut && user) {
          try {
            await saveShortcut(user.id, "earning", shortcutName, { topic: values.source, amount: values.amount, hours: values.hours, km: values.km, notes: values.notes, workplace_id: values.workplace_id });
            qc.invalidateQueries({ queryKey: ["db", "entry_shortcuts"] });
          } catch (e) {
            shortcutError(e);
          }
        }
        onOpenChange(false);
      },
    };
    if (record) update.mutate({ id: record.id, values }, done);
    else insert.mutate({ id, ...values }, done);
  }

  return (
    <FormDialog open={open} onOpenChange={onOpenChange} title={record ? "Editar ganho" : "Novo ganho"} onSubmit={submit} pending={insert.isPending || update.isPending}>
      {!record && <ShortcutChips kind="earning" onPick={applyShortcut} />}
      <Field label="Aplicativo ou fonte" error={errors["source"]}>
        <ChipSelect options={EARNING_SOURCES} value={v.source} onChange={set("source")} />
        <TextInput placeholder="Ou digite outro…" value={v.source} onChange={(e) => set("source")(e.target.value)} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Valor recebido" error={errors["amount"]}>
          <MoneyInput value={v.amount} onChange={(e) => set("amount")(e.target.value)} />
        </Field>
        <Field label="Data" error={errors["date"]}>
          <TextInput type="date" value={v.date} onChange={(e) => set("date")(e.target.value)} />
        </Field>
        <Field label="Horas (opcional)" error={errors["hours"]}>
          <TextInput inputMode="decimal" placeholder="Ex.: 8,5" value={v.hours} onChange={(e) => set("hours")(e.target.value)} />
        </Field>
        <Field label="Km rodados (opcional)" error={errors["km"]}>
          <TextInput inputMode="decimal" placeholder="Ex.: 120" value={v.km} onChange={(e) => set("km")(e.target.value)} />
        </Field>
      </div>
      {workplaces.length > 0 && (
        <Field label="Local de trabalho (opcional)">
          <NativeSelect value={v.workplace_id} onChange={(e) => set("workplace_id")(e.target.value)}>
            <option value="">Nenhum</option>
            {workplaces.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </NativeSelect>
        </Field>
      )}
      <Field label="Observações">
        <TextArea value={v.notes} onChange={(e) => set("notes")(e.target.value)} maxLength={500} />
      </Field>
      <SaveShortcutFields
        enabled={asShortcut}
        onEnabledChange={(on) => {
          setAsShortcut(on);
          if (on && !shortcutName) setShortcutName(v.source);
        }}
        name={shortcutName}
        onNameChange={setShortcutName}
      />
      {errors["shortcut"] && <p className="-mt-2 text-xs font-medium text-destructive">{errors["shortcut"]}</p>}
    </FormDialog>
  );
}
