import { useEffect, useState } from "react";
import { Field, FormDialog, MoneyInput, TextInput } from "@/components/common";
import { useInsert } from "@/hooks/use-data";
import { newId, type Installment } from "@/lib/db";
import { remainingOf } from "@/lib/finance";
import { dateBR, money, parseMoney, todayISO } from "@/lib/format";

export function PayInstallmentDialog({
  installment,
  onOpenChange,
  label,
}: {
  installment: Installment | null;
  onOpenChange: (o: boolean) => void;
  label?: string | undefined;
}) {
  const insert = useInsert("installment_payments", "Pagamento registrado");
  const [id, setId] = useState(newId());
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(todayISO());
  const [notes, setNotes] = useState("");
  const [error, setError] = useState<string | null>(null);
  const remaining = installment ? remainingOf(installment) : 0;

  useEffect(() => {
    if (!installment) return;
    setId(newId());
    setAmount(String(remainingOf(installment)).replace(".", ","));
    setDate(todayISO());
    setNotes("");
    setError(null);
  }, [installment]);

  function submit() {
    if (!installment) return;
    const value = parseMoney(amount);
    if (!(value > 0)) return setError("Informe um valor maior que zero");
    if (value > remaining + 0.001) return setError(`O saldo desta parcela é ${money(remaining)}`);
    if (!date) return setError("Informe a data do pagamento");
    insert.mutate(
      { id, installment_id: installment.id, amount: value, paid_on: date, notes: notes.trim() || null, is_demo: installment.is_demo },
      { onSuccess: () => onOpenChange(false) },
    );
  }

  return (
    <FormDialog
      open={!!installment}
      onOpenChange={onOpenChange}
      title={`Registrar pagamento${installment ? ` · parcela ${installment.number}` : ""}`}
      description={installment ? `${label ? label + " · " : ""}vence ${dateBR(installment.due_date)} · saldo ${money(remaining)}` : undefined}
      onSubmit={submit}
      pending={insert.isPending}
      submitLabel="Confirmar recebimento"
    >
      <div className="grid grid-cols-2 gap-3">
        <Field label="Valor recebido" error={error ?? undefined} hint="Pode ser parcial">
          <MoneyInput value={amount} onChange={(e) => setAmount(e.target.value)} />
        </Field>
        <Field label="Data do pagamento">
          <TextInput type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </Field>
      </div>
      <Field label="Observação (opcional)">
        <TextInput value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Ex.: Pix" maxLength={200} />
      </Field>
    </FormDialog>
  );
}
