import { useEffect, useState } from "react";
import { z } from "zod";
import { useQueryClient } from "@tanstack/react-query";
import { ChipSelect, Field, FormDialog, MoneyInput, TextArea, TextInput } from "@/components/common";
import { SaveShortcutFields, saveShortcut, shortcutError, ShortcutChips } from "@/components/shortcuts";
import { useInsert, useUpdate } from "@/hooks/use-data";
import { useAuth } from "@/hooks/use-auth";
import { newId, type EntryShortcut, type Expense } from "@/lib/db";
import { parseMoney, todayISO } from "@/lib/format";

export const EXPENSE_CATEGORIES = [
  "Combustível",
  "Alimentação",
  "Manutenção",
  "Pneus e peças",
  "Internet e telefone",
  "Estacionamento",
  "Outros",
] as const;

const schema = z.object({
  description: z.string().trim().min(1, "Descreva a despesa").max(120),
  category: z.string().trim().min(1, "Escolha uma categoria").max(60),
  amount: z.number({ invalid_type_error: "Valor inválido" }).positive("Valor deve ser maior que zero").max(1_000_000),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Data inválida"),
});

const isPreset = (c: string) => (EXPENSE_CATEGORIES as readonly string[]).includes(c);

export function ExpenseForm({
  open,
  onOpenChange,
  record,
  preset,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  record?: Expense | null | undefined;
  preset?: EntryShortcut | null | undefined;
}) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const insert = useInsert("expenses", "Despesa registrada");
  const update = useUpdate("expenses");
  const [id, setId] = useState(newId());
  const [v, setV] = useState({ description: "", category: "Combustível", amount: "", date: todayISO(), notes: "" });
  const [custom, setCustom] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [asShortcut, setAsShortcut] = useState(false);
  const [shortcutName, setShortcutName] = useState("");

  function applyShortcut(s: EntryShortcut) {
    setCustom(!isPreset(s.topic));
    setV((cur) => ({
      ...cur,
      category: s.topic,
      description: s.description ?? "",
      amount: s.amount == null ? "" : String(s.amount).replace(".", ","),
      notes: s.notes ?? "",
    }));
  }

  useEffect(() => {
    if (!open) return;
    setErrors({});
    setAsShortcut(false);
    setShortcutName("");
    setId(record?.id ?? newId());
    const cat = record?.category ?? "Combustível";
    setCustom(!isPreset(cat));
    setV({
      description: record?.description ?? "",
      category: cat,
      amount: record ? String(record.amount).replace(".", ",") : "",
      date: record?.date ?? todayISO(),
      notes: record?.notes ?? "",
    });
    if (!record && preset) applyShortcut(preset);
  }, [open, record, preset]);

  const set = (k: keyof typeof v) => (val: string) => setV((s) => ({ ...s, [k]: val }));

  function submit() {
    const parsed = schema.safeParse({ ...v, description: v.description || v.category, amount: parseMoney(v.amount) });
    if (!parsed.success) {
      const e: Record<string, string> = {};
      parsed.error.issues.forEach((i) => (e[String(i.path[0])] = i.message));
      return setErrors(e);
    }
    if (asShortcut && !shortcutName.trim()) return setErrors({ shortcut: "Dê um nome ao atalho" });
    const values = { ...parsed.data, notes: v.notes.trim() || null };
    const done = {
      onSuccess: async () => {
        if (asShortcut && user) {
          try {
            await saveShortcut(user.id, "expense", shortcutName, { topic: values.category, description: values.description, amount: values.amount, notes: values.notes });
            qc.invalidateQueries({ queryKey: ["db", "entry_shortcuts"] });
          } catch (e) {
            shortcutError(e);
          }
        }
        onOpenChange(false);
      },
    };
    if (record) update.mutate({ id: record.id, values }, done);
    else insert.mutate({ id, ...values }, done);
  }

  return (
    <FormDialog
      open={open}
      onOpenChange={onOpenChange}
      title={record ? "Editar despesa" : "Nova despesa"}
      description="Datas futuras aparecem no calendário como despesa prevista."
      onSubmit={submit}
      pending={insert.isPending || update.isPending}
    >
      {!record && <ShortcutChips kind="expense" onPick={applyShortcut} />}
      <Field label="Categoria" error={errors["category"]}>
        <ChipSelect
          options={[...EXPENSE_CATEGORIES, "Personalizada"]}
          value={custom ? "Personalizada" : v.category}
          onChange={(c) => {
            if (c === "Personalizada") {
              setCustom(true);
              set("category")("");
            } else {
              setCustom(false);
              set("category")(c);
            }
          }}
        />
        {custom && <TextInput placeholder="Nome da categoria" value={v.category} onChange={(e) => set("category")(e.target.value)} />}
      </Field>
      <Field label="Descrição" error={errors["description"]}>
        <TextInput placeholder="Ex.: Gasolina posto Centro" value={v.description} onChange={(e) => set("description")(e.target.value)} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Valor" error={errors["amount"]}>
          <MoneyInput value={v.amount} onChange={(e) => set("amount")(e.target.value)} />
        </Field>
        <Field label="Data" error={errors["date"]}>
          <TextInput type="date" value={v.date} onChange={(e) => set("date")(e.target.value)} />
        </Field>
      </div>
      <Field label="Observações">
        <TextArea value={v.notes} onChange={(e) => set("notes")(e.target.value)} maxLength={500} />
      </Field>
      <SaveShortcutFields
        enabled={asShortcut}
        onEnabledChange={(on) => {
          setAsShortcut(on);
          if (on && !shortcutName) setShortcutName(v.description || v.category);
        }}
        name={shortcutName}
        onNameChange={setShortcutName}
      />
      {errors["shortcut"] && <p className="-mt-2 text-xs font-medium text-destructive">{errors["shortcut"]}</p>}
    </FormDialog>
  );
}
