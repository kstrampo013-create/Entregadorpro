import { useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, Check, HandCoins, Pencil, Phone, Plus, ShoppingBag, Undo2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ConfirmDelete, EmptyState, Field, FormDialog, LoadingBlock, PageHeader, Panel, StatCard, StatusBadge, TextArea, TextInput } from "@/components/common";
import { ContractForm } from "@/components/forms/contract-form";
import { PayInstallmentDialog } from "@/components/forms/pay-installment-dialog";
import { useContracts, type Contract } from "@/hooks/use-derived";
import { useDelete, useTable, useUpdate } from "@/hooks/use-data";
import { useQuickPay } from "@/hooks/use-quick-pay";
import type { Installment } from "@/lib/db";
import { installmentStatus, remainingOf } from "@/lib/finance";
import { dateBR, money, todayISO } from "@/lib/format";
import { formatPhoneBR } from "@/lib/phone";

const LABEL = {
  sale: { plural: "Vendas parceladas", single: "venda", newLabel: "Nova venda", icon: ShoppingBag, list: "/vendas" as const },
  loan: { plural: "Empréstimos", single: "empréstimo", newLabel: "Novo empréstimo", icon: HandCoins, list: "/emprestimos" as const },
};

export function ContractList({ kind }: { kind: "sale" | "loan" }) {
  const { contracts, isLoading } = useContracts();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [filter, setFilter] = useState<"abertos" | "atrasados" | "quitados" | "todos">("abertos");
  const L = LABEL[kind];
  const mine = contracts.filter((c) => c.kind === kind);
  const shown = mine
    .filter((c) =>
      filter === "todos" ? true : filter === "quitados" ? c.summary.status === "quitado" : filter === "atrasados" ? c.summary.status === "atrasado" : c.summary.status !== "quitado",
    )
    .sort((a, b) => (a.summary.nextDue ?? "9999").localeCompare(b.summary.nextDue ?? "9999"));
  const totals = mine.reduce(
    (acc, c) => ({ original: acc.original + c.summary.original, received: acc.received + c.summary.received, remaining: acc.remaining + c.summary.remaining }),
    { original: 0, received: 0, remaining: 0 },
  );
  const goDetail = (id: string) =>
    kind === "sale" ? navigate({ to: "/vendas/$id", params: { id } }) : navigate({ to: "/emprestimos/$id", params: { id } });

  return (
    <>
      <PageHeader
        title={L.plural}
        subtitle={kind === "sale" ? "Produtos e serviços vendidos a prazo." : "Dinheiro emprestado e as parcelas combinadas."}
        action={
          <Button size="lg" onClick={() => setOpen(true)}>
            <Plus /> {L.newLabel}
          </Button>
        }
      />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label={kind === "sale" ? "Total parcelado" : "Total combinado"} value={money(totals.original)} />
        <StatCard label="Já recebido" value={money(totals.received)} tone="income" />
        <StatCard label="A receber" value={money(totals.remaining)} tone="brand" />
        <StatCard label="Em atraso" value={String(mine.filter((c) => c.summary.status === "atrasado").length)} hint="contratos" tone="expense" />
      </div>
      <Panel className="mt-5">
        <div className="mb-4 flex flex-wrap gap-2">
          {(["abertos", "atrasados", "quitados", "todos"] as const).map((f) => (
            <Button key={f} size="sm" variant={filter === f ? "default" : "outline"} onClick={() => setFilter(f)} className="capitalize">
              {f}
            </Button>
          ))}
        </div>
        {isLoading ? (
          <LoadingBlock />
        ) : shown.length === 0 ? (
          <EmptyState icon={<L.icon />} title={`Nenhum ${L.single} aqui`} action={<Button onClick={() => setOpen(true)}>{L.newLabel}</Button>} />
        ) : (
          <ul className="grid gap-3 md:grid-cols-2">
            {shown.map((c) => (
              <li key={c.id}>
                <button onClick={() => goDetail(c.id)} className="w-full rounded-xl border bg-card p-4 text-left transition hover:border-primary/40 hover:shadow-soft">
                  <ContractCardBody c={c} />
                </button>
              </li>
            ))}
          </ul>
        )}
      </Panel>
      <ContractForm kind={kind} open={open} onOpenChange={setOpen} onCreated={goDetail} />
    </>
  );
}

export function ContractCardBody({ c }: { c: Contract }) {
  const pct = c.summary.original ? Math.round((c.summary.received / c.summary.original) * 100) : 0;
  return (
    <>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="truncate font-semibold">
            {c.name}
            {c.isDemo && <span className="ml-2 rounded bg-muted px-1.5 text-[10px] font-bold uppercase text-muted-foreground">demo</span>}
          </p>
          <p className="truncate text-sm text-muted-foreground">{c.description}</p>
        </div>
        <StatusBadge status={c.summary.status} />
      </div>
      <div className="mt-3 h-2 overflow-hidden rounded-full bg-muted">
        <div className="h-full rounded-full bg-primary" style={{ width: `${pct}%` }} />
      </div>
      <div className="mt-2 flex flex-wrap justify-between gap-2 text-xs text-muted-foreground">
        <span>
          Recebido <b className="text-foreground">{money(c.summary.received)}</b> de {money(c.summary.original)}
        </span>
        <span>
          {c.summary.pendingCount > 0 ? (
            <>
              {c.summary.pendingCount} pendente(s) · próx. {dateBR(c.summary.nextDue)}
            </>
          ) : (
            "Tudo pago"
          )}
        </span>
      </div>
    </>
  );
}

export function ContractDetail({ kind, id }: { kind: "sale" | "loan"; id: string }) {
  const navigate = useNavigate();
  const { contracts, isLoading } = useContracts();
  const sales = useTable("sales");
  const loans = useTable("loans");
  const payments = useTable("installment_payments");
  const delSale = useDelete("sales", "Venda excluída");
  const delLoan = useDelete("loans", "Empréstimo excluído");
  const delPayment = useDelete("installment_payments", "Pagamento desfeito");
  const [paying, setPaying] = useState<Installment | null>(null);
  const quick = useQuickPay();
  const [editOpen, setEditOpen] = useState(false);
  const today = todayISO();
  const L = LABEL[kind];

  const c = contracts.find((x) => x.id === id && x.kind === kind);
  const sale = kind === "sale" ? sales.data?.find((s) => s.id === id) : undefined;
  const loan = kind === "loan" ? loans.data?.find((l) => l.id === id) : undefined;

  if (isLoading) return <LoadingBlock />;
  if (!c) {
    return (
      <EmptyState
        title="Registro não encontrado"
        text="Ele pode ter sido excluído."
        action={
          <Button asChild>
            <Link to={L.list}>Voltar</Link>
          </Button>
        }
      />
    );
  }

  const instIds = new Set(c.installments.map((i) => i.id));
  const history = (payments.data ?? []).filter((p) => instIds.has(p.installment_id)).sort((a, b) => b.paid_on.localeCompare(a.paid_on));
  const instNumber = new Map(c.installments.map((i) => [i.id, i.number]));

  return (
    <>
      <Button variant="ghost" asChild className="-ml-3 mb-2">
        <Link to={L.list}>
          <ArrowLeft /> {L.plural}
        </Link>
      </Button>
      <PageHeader
        title={c.name}
        subtitle={c.description}
        action={
          <>
            <Button variant="outline" onClick={() => setEditOpen(true)}>
              <Pencil /> Editar
            </Button>
            <ConfirmDelete
              title={`Excluir este ${L.single}?`}
              description="Todas as parcelas e pagamentos registrados também serão excluídos."
              trigger={<Button variant="soft-destructive">Excluir</Button>}
              onConfirm={() => {
                (kind === "sale" ? delSale : delLoan).mutate(id, { onSuccess: () => navigate({ to: L.list }) });
              }}
            />
          </>
        }
      />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Valor parcelado" value={money(c.summary.original)} hint={sale && Number(sale.down_payment) > 0 ? `+ entrada ${money(sale.down_payment)}` : loan ? `Emprestado ${money(loan.principal)}` : undefined} />
        <StatCard label="Recebido" value={money(c.summary.received)} tone="income" />
        <StatCard label="Saldo restante" value={money(c.summary.remaining)} tone="brand" />
        <StatCard label="Próximo vencimento" value={dateBR(c.summary.nextDue)} hint={`${c.summary.pendingCount} parcela(s) pendente(s)`} />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_320px]">
        <Panel title="Parcelas" action={<span className="text-xs text-muted-foreground">“Pago” registra o valor total hoje</span>}>
          <ul className="divide-y rounded-xl border">
            {c.installments.map((i) => {
              const st = installmentStatus(i, today);
              return (
                <li key={i.id} className="flex items-center gap-3 p-3">
                  <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-muted text-sm font-bold">{i.number}</span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="font-semibold tabular">{money(i.amount)}</p>
                      <StatusBadge status={st} />
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Vence {dateBR(i.due_date)}
                      {Number(i.paid_amount) > 0 && st !== "pago" && ` · pago ${money(i.paid_amount)}`}
                      {i.paid_at && ` · quitada em ${dateBR(i.paid_at)}`}
                    </p>
                  </div>
                  {st !== "pago" ? (
                    <div className="flex shrink-0 items-center gap-1">
                      <Button size="sm" onClick={() => quick.payInstallment.mutate(i)} disabled={quick.busy}>
                        <Check /> Pago
                      </Button>
                      <Button size="icon-sm" variant="outline" aria-label="Pagamento parcial ou outra data" onClick={() => setPaying(i)}>
                        <HandCoins />
                      </Button>
                    </div>
                  ) : (
                    <ConfirmDelete
                      title="Desmarcar esta parcela?"
                      description="Todos os pagamentos registrados nela serão desfeitos."
                      confirmLabel="Desmarcar"
                      onConfirm={() => quick.unpayInstallment.mutate(i)}
                      trigger={
                        <Button size="icon-sm" variant="ghost" aria-label="Desmarcar parcela">
                          <Undo2 />
                        </Button>
                      }
                    />
                  )}
                </li>
              );
            })}
          </ul>
        </Panel>
        <div className="space-y-5">
          <Panel title="Dados">
            <dl className="space-y-2 text-sm">
              <Row label="Data">{dateBR(c.date)}</Row>
              {c.phone && (
                <Row label="Telefone">
                  <a href={`tel:${c.phone}`} className="inline-flex items-center gap-1 font-medium text-primary">
                    <Phone className="size-3" /> {formatPhoneBR(c.phone)}
                  </a>
                </Row>
              )}
              {sale && <Row label="Valor total">{money(sale.total)}</Row>}
              {sale && <Row label="Entrada">{money(sale.down_payment)}</Row>}
              {loan && <Row label="Juros">{loan.interest_rate != null ? `${String(loan.interest_rate).replace(".", ",")}%` : "Sem juros"}</Row>}
              {loan && <Row label="Total combinado">{money(loan.total_due)}</Row>}
              {(sale?.notes || loan?.notes) && <Row label="Observações">{sale?.notes ?? loan?.notes}</Row>}
            </dl>
          </Panel>
          <Panel title="Histórico de pagamentos">
            {history.length === 0 ? (
              <p className="text-sm text-muted-foreground">Nenhum pagamento registrado.</p>
            ) : (
              <ul className="space-y-2">
                {history.map((p) => (
                  <li key={p.id} className="flex items-center gap-2 text-sm">
                    <div className="flex-1">
                      <p className="font-semibold text-income tabular">{money(p.amount)}</p>
                      <p className="text-xs text-muted-foreground">
                        Parcela {instNumber.get(p.installment_id)} · {dateBR(p.paid_on)}
                        {p.notes && ` · ${p.notes}`}
                      </p>
                    </div>
                    <ConfirmDelete
                      title="Desfazer este pagamento?"
                      description="A parcela voltará a ficar em aberto pelo valor deste pagamento."
                      confirmLabel="Desfazer"
                      trigger={
                        <Button variant="ghost" size="icon-sm" aria-label="Desfazer pagamento">
                          <Undo2 />
                        </Button>
                      }
                      onConfirm={() => delPayment.mutate(p.id)}
                    />
                  </li>
                ))}
              </ul>
            )}
          </Panel>
        </div>
      </div>
      <PayInstallmentDialog installment={paying} onOpenChange={(o) => !o && setPaying(null)} label={c.name} />
      <EditContractDialog kind={kind} open={editOpen} onOpenChange={setEditOpen} sale={sale} loan={loan} />
    </>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="text-right font-medium">{children}</dd>
    </div>
  );
}

function EditContractDialog({
  kind,
  open,
  onOpenChange,
  sale,
  loan,
}: {
  kind: "sale" | "loan";
  open: boolean;
  onOpenChange: (o: boolean) => void;
  sale?: { id: string; customer_name: string; customer_phone: string | null; description: string; notes: string | null } | undefined;
  loan?: { id: string; person_name: string; person_phone: string | null; notes: string | null } | undefined;
}) {
  const upSale = useUpdate("sales");
  const upLoan = useUpdate("loans");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [desc, setDesc] = useState("");
  const [notes, setNotes] = useState("");
  const [init, setInit] = useState(false);
  if (open && !init) {
    setName(sale?.customer_name ?? loan?.person_name ?? "");
    setPhone(sale?.customer_phone ?? loan?.person_phone ?? "");
    setDesc(sale?.description ?? "");
    setNotes(sale?.notes ?? loan?.notes ?? "");
    setInit(true);
  }
  if (!open && init) setInit(false);

  function submit() {
    if (!name.trim()) return;
    const done = { onSuccess: () => onOpenChange(false) };
    if (kind === "sale" && sale)
      upSale.mutate({ id: sale.id, values: { customer_name: name.trim(), customer_phone: phone.trim() || null, description: desc.trim() || sale.description, notes: notes.trim() || null } }, done);
    if (kind === "loan" && loan) upLoan.mutate({ id: loan.id, values: { person_name: name.trim(), person_phone: phone.trim() || null, notes: notes.trim() || null } }, done);
  }

  return (
    <FormDialog
      open={open}
      onOpenChange={onOpenChange}
      title="Editar dados"
      description="Valores e parcelas não mudam aqui. Para mudar valores, exclua e crie novamente."
      onSubmit={submit}
      pending={upSale.isPending || upLoan.isPending}
    >
      <Field label={kind === "sale" ? "Cliente" : "Pessoa"}>
        <TextInput value={name} onChange={(e) => setName(e.target.value)} />
      </Field>
      <Field label="Telefone">
        <TextInput type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
      </Field>
      {kind === "sale" && (
        <Field label="Descrição">
          <TextInput value={desc} onChange={(e) => setDesc(e.target.value)} />
        </Field>
      )}
      <Field label="Observações">
        <TextArea value={notes} onChange={(e) => setNotes(e.target.value)} />
      </Field>
    </FormDialog>
  );
}
