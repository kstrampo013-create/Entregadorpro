import { Link } from "@tanstack/react-router";
import { CalendarCheck2, ChevronRight, Target } from "lucide-react";
import type { GoalView } from "@/hooks/use-derived";
import type { GoalStatus } from "@/lib/finance";
import { dateBR, monthLabel, money } from "@/lib/format";
import { cn } from "@/lib/utils";

export const GOAL_STATUS_LABEL: Record<GoalStatus, string> = {
  concluida: "Meta batida",
  em_andamento: "Em andamento",
  futura: "Ainda não começou",
  encerrada: "Prazo encerrado",
  sem_dias: "Sem dias de trabalho restantes",
};

export function ProgressBar({ pct, className }: { pct: number; className?: string }) {
  return (
    <div className={cn("h-2.5 w-full overflow-hidden rounded-full bg-muted", className)} role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
      <div className={cn("h-full rounded-full transition-all", pct >= 100 ? "bg-success" : "bg-primary")} style={{ width: `${pct}%` }} />
    </div>
  );
}

/** One line telling what today asks for. */
export function todayLine({ progress: p }: GoalView): { text: string; tone: "ok" | "todo" | "muted" } {
  if (p.status === "concluida") return { text: "Meta batida!", tone: "ok" };
  if (p.status === "futura") return { text: `Começa em ${dateBR(p.period.start)}`, tone: "muted" };
  if (p.status === "encerrada") return { text: `Prazo terminou faltando ${money(p.remaining)}`, tone: "muted" };
  if (p.status === "sem_dias") return { text: `Faltam ${money(p.remaining)} e não há dias de trabalho marcados`, tone: "todo" };
  if (!p.todayIsWorkDay) return { text: "Hoje é folga", tone: "muted" };
  if (p.todayMissing <= 0) return { text: `Meta de hoje batida (${money(p.todayDone)})`, tone: "ok" };
  return { text: `Hoje falta ${money(p.todayMissing)} de ${money(p.perDay)}`, tone: "todo" };
}

export function GoalCard({ view }: { view: GoalView }) {
  const { goal: g, progress: p } = view;
  const t = todayLine(view);
  return (
    <Link
      to="/metas/$id"
      params={{ id: g.id }}
      className={cn("block rounded-2xl border bg-card p-4 shadow-soft transition active:scale-[0.99]", !g.active && "opacity-60")}
    >
      <div className="mb-3 flex items-start gap-3">
        <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-highlight/30 text-highlight-foreground">
          {g.kind === "mensal" ? <CalendarCheck2 className="size-5" /> : <Target className="size-5" />}
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate font-display font-bold">{g.name}</p>
          <p className="text-xs text-muted-foreground first-letter:uppercase">
            {g.kind === "mensal" ? `Meta de ${monthLabel(p.period.start)}` : `Até ${dateBR(g.end_date)}`}
            {!g.active && " · arquivada"}
          </p>
        </div>
        <ChevronRight className="size-5 shrink-0 text-muted-foreground" />
      </div>
      <div className="mb-1.5 flex items-baseline justify-between gap-2 text-sm">
        <span className="font-bold tabular">{money(p.achieved)}</span>
        <span className="text-muted-foreground tabular">de {money(p.target)} · {p.pct}%</span>
      </div>
      <ProgressBar pct={p.pct} />
      <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
        <div className="rounded-xl bg-secondary/50 p-2.5">
          <p className="text-[11px] text-muted-foreground">Por dia de trabalho</p>
          <p className="font-bold tabular">{p.perDay != null ? money(p.perDay) : "—"}</p>
          <p className="text-[11px] text-muted-foreground">{p.workDaysLeft} dia(s) restante(s)</p>
        </div>
        <div className="rounded-xl bg-secondary/50 p-2.5">
          <p className="text-[11px] text-muted-foreground">{g.kind === "mensal" ? "Falta no mês" : "Por mês"}</p>
          <p className="font-bold tabular">{g.kind === "mensal" ? money(p.remaining) : p.perMonth != null ? money(p.perMonth) : "—"}</p>
          <p className="text-[11px] text-muted-foreground">
            {g.kind === "mensal" ? `até ${dateBR(p.period.end)}` : `${p.monthsLeft} mês(es) restante(s)`}
          </p>
        </div>
      </div>
      <p
        className={cn(
          "mt-3 rounded-xl px-3 py-2 text-sm font-semibold",
          t.tone === "ok" && "bg-success/12 text-success",
          t.tone === "todo" && "bg-highlight/25 text-highlight-foreground",
          t.tone === "muted" && "bg-muted text-muted-foreground",
        )}
      >
        {t.text}
      </p>
    </Link>
  );
}
