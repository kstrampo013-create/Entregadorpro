import { Children, cloneElement, isValidElement, useId, type ComponentProps, type ReactElement, type ReactNode } from "react";
import { Loader2, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div className="min-w-0">
        <h1 className="text-2xl font-bold md:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}
      </div>
      {action && <div className="flex flex-wrap gap-2">{action}</div>}
    </div>
  );
}

type Tone = "default" | "income" | "expense" | "highlight" | "brand";

export function StatCard({
  label,
  value,
  hint,
  icon,
  tone = "default",
  className,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  icon?: ReactNode;
  tone?: Tone;
  className?: string;
}) {
  const brand = tone === "brand";
  return (
    <div
      className={cn(
        "rounded-2xl border p-4 shadow-soft",
        brand ? "border-transparent bg-card-gradient text-primary-foreground" : "bg-card",
        className,
      )}
    >
      <div className="flex items-center justify-between gap-2">
        <span className={cn("text-xs font-semibold uppercase tracking-wide", brand ? "opacity-80" : "text-muted-foreground")}>
          {label}
        </span>
        {icon && (
          <span
            className={cn(
              "grid size-8 place-items-center rounded-lg [&_svg]:size-4",
              brand && "bg-primary-foreground/15",
              tone === "income" && "bg-income/10 text-income",
              tone === "expense" && "bg-expense/10 text-expense",
              tone === "highlight" && "bg-highlight/20 text-highlight-foreground dark:text-highlight",
              tone === "default" && "bg-muted text-muted-foreground",
            )}
          >
            {icon}
          </span>
        )}
      </div>
      <div
        className={cn(
          "mt-2 font-display text-xl font-bold tabular md:text-2xl",
          tone === "income" && "text-income",
          tone === "expense" && "text-expense",
        )}
      >
        {value}
      </div>
      {hint && <div className={cn("mt-1 text-xs", brand ? "opacity-80" : "text-muted-foreground")}>{hint}</div>}
    </div>
  );
}

export function Panel({ title, action, children, className }: { title?: ReactNode; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={cn("rounded-2xl border bg-card p-4 shadow-soft md:p-5", className)}>
      {(title || action) && (
        <div className="mb-3 flex items-center justify-between gap-2">
          {title && <h2 className="text-base font-semibold">{title}</h2>}
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

export function EmptyState({ icon, title, text, action }: { icon?: ReactNode; title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border border-dashed px-4 py-10 text-center">
      {icon && <div className="grid size-12 place-items-center rounded-2xl bg-secondary text-secondary-foreground [&_svg]:size-6">{icon}</div>}
      <p className="font-semibold">{title}</p>
      {text && <p className="max-w-sm text-sm text-muted-foreground">{text}</p>}
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}

const STATUS_STYLE: Record<string, string> = {
  pago: "bg-success/12 text-success",
  quitado: "bg-success/12 text-success",
  recebido: "bg-success/12 text-success",
  parcial: "bg-highlight/20 text-highlight-foreground dark:text-highlight",
  pendente: "bg-muted text-muted-foreground",
  em_dia: "bg-secondary text-secondary-foreground",
  prevista: "bg-secondary text-secondary-foreground",
  atrasado: "bg-destructive/12 text-destructive",
};
const STATUS_LABEL: Record<string, string> = {
  pago: "Pago",
  quitado: "Quitado",
  recebido: "Recebido",
  parcial: "Parcial",
  pendente: "Pendente",
  em_dia: "Em dia",
  prevista: "Prevista",
  atrasado: "Atrasado",
};

export function StatusBadge({ status, label }: { status: string; label?: string }) {
  return (
    <span className={cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold", STATUS_STYLE[status] ?? STATUS_STYLE["pendente"])}>
      {label ?? STATUS_LABEL[status] ?? status}
    </span>
  );
}

export function Field({
  label,
  error,
  hint,
  children,
  className,
}: {
  label: string;
  error?: string | undefined;
  hint?: ReactNode | undefined;
  children: ReactNode;
  className?: string | undefined;
}) {
  const autoId = useId();
  let targetId: string | undefined;
  const items = Children.map(children, (child) => {
    if (targetId || !isValidElement(child)) return child;
    const el = child as ReactElement<{ id?: string; options?: unknown }>;
    if (el.props.options !== undefined) return child; // chip groups are not form controls
    targetId = el.props.id ?? autoId;
    return el.props.id ? child : cloneElement(el, { id: autoId });
  });
  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      <Label htmlFor={targetId} className="text-sm font-semibold">
        {label}
      </Label>
      {items}
      {hint && !error && <p className="text-xs text-muted-foreground">{hint}</p>}
      {error && <p className="text-xs font-medium text-destructive">{error}</p>}
    </div>
  );
}

export function TextInput(props: ComponentProps<typeof Input>) {
  return <Input {...props} className={cn("h-12 rounded-xl text-base", props.className)} />;
}

export function MoneyInput(props: Omit<ComponentProps<typeof Input>, "type">) {
  return (
    <div className="relative">
      <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm font-semibold text-muted-foreground">R$</span>
      <Input inputMode="decimal" placeholder="0,00" {...props} className={cn("h-12 rounded-xl pl-10 text-base tabular", props.className)} />
    </div>
  );
}

export function TextArea(props: ComponentProps<"textarea">) {
  return (
    <textarea
      {...props}
      className={cn(
        "min-h-20 w-full rounded-xl border border-input bg-transparent px-3 py-2 text-base shadow-sm outline-none focus-visible:ring-2 focus-visible:ring-ring",
        props.className,
      )}
    />
  );
}

export function ChipSelect<T extends string>({
  options,
  value,
  onChange,
}: {
  options: readonly T[] | T[];
  value: string;
  onChange: (v: T) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((o) => (
        <button
          key={o}
          type="button"
          onClick={() => onChange(o)}
          className={cn(
            "min-h-10 rounded-full border px-3.5 text-sm font-medium transition-colors",
            value === o ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:bg-accent",
          )}
        >
          {o}
        </button>
      ))}
    </div>
  );
}

export function SegmentedControl<T extends string>({
  options,
  value,
  onChange,
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <div className="inline-flex rounded-xl border bg-muted p-1">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          className={cn(
            "min-h-9 rounded-lg px-3.5 text-sm font-semibold transition-colors",
            value === o.value ? "bg-card text-foreground shadow-sm" : "text-muted-foreground",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function ConfirmDelete({
  title = "Excluir este registro?",
  description = "Essa ação não pode ser desfeita.",
  onConfirm,
  trigger,
  confirmLabel = "Excluir",
}: {
  title?: string;
  description?: string;
  onConfirm: () => void;
  trigger?: ReactNode;
  confirmLabel?: string;
}) {
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        {trigger ?? (
          <Button variant="soft-destructive" size="icon-sm" aria-label="Excluir">
            <Trash2 />
          </Button>
        )}
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{title}</AlertDialogTitle>
          <AlertDialogDescription>{description}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="h-11">Cancelar</AlertDialogCancel>
          <AlertDialogAction className="h-11 bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={onConfirm}>
            {confirmLabel}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

export function FormDialog({
  open,
  onOpenChange,
  title,
  description,
  children,
  onSubmit,
  submitLabel = "Salvar",
  pending,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  title: string;
  description?: string | undefined;
  children: ReactNode;
  onSubmit: () => void;
  submitLabel?: string;
  pending?: boolean;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92dvh] overflow-y-auto rounded-2xl sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">{title}</DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>
        <form
          className="flex flex-col gap-4"
          onSubmit={(e) => {
            e.preventDefault();
            if (!pending) onSubmit();
          }}
        >
          {children}
          <div className="sticky -bottom-6 -mx-6 -mb-6 flex gap-2 border-t bg-background px-6 py-4">
            <Button type="button" variant="outline" className="flex-1" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" className="flex-1" disabled={pending}>
              {pending && <Loader2 className="animate-spin" />}
              {submitLabel}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function LoadingBlock() {
  return (
    <div className="flex items-center justify-center py-16 text-muted-foreground">
      <Loader2 className="size-6 animate-spin" />
    </div>
  );
}
