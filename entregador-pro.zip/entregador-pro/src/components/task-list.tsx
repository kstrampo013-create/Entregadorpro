import { Check, Clock, Pencil } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { ConfirmDelete } from "@/components/common";
import { supabase } from "@/integrations/supabase/client";
import { useDelete, useInvalidateAll } from "@/hooks/use-data";
import type { Task } from "@/lib/db";
import { errorMessage } from "@/lib/db";
import { dateBR, todayISO } from "@/lib/format";
import { cn } from "@/lib/utils";

export function sortTasks(tasks: Task[]): Task[] {
  return [...tasks].sort(
    (a, b) => a.due_date.localeCompare(b.due_date) || (a.due_time ?? "99").localeCompare(b.due_time ?? "99") || a.title.localeCompare(b.title),
  );
}

function useToggleTask() {
  const invalidate = useInvalidateAll();
  return useMutation({
    mutationFn: async (t: Task) => {
      const done = !t.done;
      const { error } = await supabase
        .from("tasks")
        .update({ done, done_at: done ? new Date().toISOString() : null })
        .eq("id", t.id);
      if (error) throw error;
      return done;
    },
    onSuccess: (done) => {
      toast.success(done ? "Tarefa concluída" : "Tarefa reaberta");
      invalidate();
    },
    onError: (e) => toast.error(errorMessage(e)),
  });
}

export function TaskRow({ task, onEdit, showDate = false }: { task: Task; onEdit: (t: Task) => void; showDate?: boolean }) {
  const toggle = useToggleTask();
  const del = useDelete("tasks", "Tarefa excluída");
  const late = !task.done && task.due_date < todayISO();
  return (
    <li className="flex items-center gap-3 rounded-xl border bg-card p-2.5 pl-3">
      <button
        type="button"
        onClick={() => toggle.mutate(task)}
        disabled={toggle.isPending}
        aria-label={task.done ? `Reabrir: ${task.title}` : `Concluir: ${task.title}`}
        aria-pressed={task.done}
        className={cn(
          "grid size-9 shrink-0 place-items-center rounded-full border-2 transition",
          task.done ? "border-success bg-success text-success-foreground" : "border-muted-foreground/40 hover:border-primary",
        )}
      >
        {task.done && <Check className="size-4" />}
      </button>
      <div className="min-w-0 flex-1">
        <p className={cn("truncate text-sm font-semibold", task.done && "text-muted-foreground line-through")}>{task.title}</p>
        <p className={cn("flex items-center gap-1 text-xs text-muted-foreground", late && "font-semibold text-destructive")}>
          {(task.due_time || showDate) && <Clock className="size-3" />}
          {showDate && dateBR(task.due_date)}
          {showDate && task.due_time && " · "}
          {task.due_time?.slice(0, 5)}
          {late && " · atrasada"}
        </p>
        {task.notes && <p className="line-clamp-2 text-xs text-muted-foreground">{task.notes}</p>}
      </div>
      <Button variant="ghost" size="icon-sm" onClick={() => onEdit(task)} aria-label="Editar tarefa">
        <Pencil />
      </Button>
      <ConfirmDelete title="Excluir esta tarefa?" onConfirm={() => del.mutate(task.id)} />
    </li>
  );
}
