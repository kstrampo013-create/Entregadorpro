import { useState } from "react";
import { Settings2, Trash2, Zap } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { TextInput } from "@/components/common";
import { supabase } from "@/integrations/supabase/client";
import { useDelete, useTable } from "@/hooks/use-data";
import type { EntryShortcut } from "@/lib/db";
import { money } from "@/lib/format";

export type ShortcutKind = "earning" | "expense";

export function useShortcuts(kind: ShortcutKind) {
  const q = useTable("entry_shortcuts");
  return { ...q, data: (q.data ?? []).filter((s) => s.kind === kind).sort((a, b) => a.name.localeCompare(b.name)) };
}

export interface ShortcutValues {
  topic: string;
  description?: string | null | undefined;
  amount?: number | null | undefined;
  hours?: number | null | undefined;
  km?: number | null | undefined;
  notes?: string | null | undefined;
  workplace_id?: string | null | undefined;
}

/** Creates or replaces (same name) a named shortcut. */
export async function saveShortcut(userId: string, kind: ShortcutKind, name: string, v: ShortcutValues) {
  const { error } = await supabase.from("entry_shortcuts").upsert(
    {
      user_id: userId,
      kind,
      name: name.trim().slice(0, 60),
      topic: v.topic,
      description: v.description ?? null,
      amount: v.amount ?? null,
      hours: v.hours ?? null,
      km: v.km ?? null,
      notes: v.notes ?? null,
      workplace_id: v.workplace_id ?? null,
    },
    { onConflict: "user_id,kind,name" },
  );
  if (error) throw error;
}

/** Tappable chips of saved shortcuts. */
export function ShortcutChips({ kind, onPick, label = true }: { kind: ShortcutKind; onPick: (s: EntryShortcut) => void; label?: boolean }) {
  const { data } = useShortcuts(kind);
  const [manage, setManage] = useState(false);
  if (data.length === 0) return null;
  return (
    <div className="flex flex-col gap-2">
      {label && (
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-sm font-semibold">
            <Zap className="size-4 text-highlight" /> Atalhos
          </span>
          <Button type="button" variant="ghost" size="sm" onClick={() => setManage(true)}>
            <Settings2 /> Gerenciar
          </Button>
        </div>
      )}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {data.map((s) => (
          <button
            key={s.id}
            type="button"
            onClick={() => onPick(s)}
            className="flex shrink-0 flex-col items-start rounded-xl border border-highlight/50 bg-highlight/10 px-3 py-2 text-left transition hover:bg-highlight/20 active:scale-95"
          >
            <span className="text-sm font-semibold">{s.name}</span>
            <span className="text-xs text-muted-foreground">
              {s.topic}
              {s.amount != null && ` · ${money(s.amount)}`}
            </span>
          </button>
        ))}
      </div>
      <ManageShortcuts kind={kind} open={manage} onOpenChange={setManage} />
    </div>
  );
}

export function ManageShortcuts({ kind, open, onOpenChange }: { kind: ShortcutKind; open: boolean; onOpenChange: (o: boolean) => void }) {
  const { data } = useShortcuts(kind);
  const del = useDelete("entry_shortcuts", "Atalho excluído");
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85dvh] overflow-y-auto rounded-2xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">Atalhos de {kind === "earning" ? "ganhos" : "gastos"}</DialogTitle>
          <DialogDescription>Para criar um atalho, marque “Salvar como atalho” ao registrar um lançamento.</DialogDescription>
        </DialogHeader>
        {data.length === 0 ? (
          <p className="text-sm text-muted-foreground">Nenhum atalho salvo.</p>
        ) : (
          <ul className="divide-y rounded-xl border">
            {data.map((s) => (
              <li key={s.id} className="flex items-center gap-3 p-3">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{s.name}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {s.topic}
                    {s.amount != null && ` · ${money(s.amount)}`}
                    {s.km != null && ` · ${s.km} km`}
                  </p>
                </div>
                <Button variant="soft-destructive" size="icon-sm" aria-label={`Excluir atalho ${s.name}`} onClick={() => del.mutate(s.id)}>
                  <Trash2 />
                </Button>
              </li>
            ))}
          </ul>
        )}
      </DialogContent>
    </Dialog>
  );
}

/** "Salvar como atalho" checkbox + name field, used inside entry forms. */
export function SaveShortcutFields({
  enabled,
  onEnabledChange,
  name,
  onNameChange,
}: {
  enabled: boolean;
  onEnabledChange: (v: boolean) => void;
  name: string;
  onNameChange: (v: string) => void;
}) {
  return (
    <div className="rounded-xl border border-dashed p-3">
      <label className="flex min-h-9 items-center gap-3 text-sm font-semibold">
        <Checkbox checked={enabled} onCheckedChange={(v) => onEnabledChange(v === true)} className="size-5" />
        <Zap className="size-4 text-highlight" /> Salvar como atalho
      </label>
      {enabled && (
        <TextInput
          className="mt-2"
          placeholder="Nome do atalho (ex.: Almoço, Turno iFood)"
          maxLength={60}
          value={name}
          onChange={(e) => onNameChange(e.target.value)}
          aria-label="Nome do atalho"
        />
      )}
    </div>
  );
}

export function shortcutError(e: unknown) {
  toast.error(`Lançamento salvo, mas o atalho falhou: ${e instanceof Error ? e.message : "erro"}`);
}
