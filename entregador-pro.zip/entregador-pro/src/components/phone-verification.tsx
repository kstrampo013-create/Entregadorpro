import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { BadgeCheck, Loader2, MessageSquareWarning } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { getSmsStatus, sendPhoneCode, verifyPhoneCode } from "@/lib/sms.functions";
import { useProfile } from "@/hooks/use-auth";
import { formatPhoneBR } from "@/lib/phone";

export function PhoneVerification() {
  const qc = useQueryClient();
  const { data: profile } = useProfile();
  const statusFn = useServerFn(getSmsStatus);
  const sendFn = useServerFn(sendPhoneCode);
  const verifyFn = useServerFn(verifyPhoneCode);
  const status = useQuery({ queryKey: ["sms-status"], queryFn: () => statusFn(), staleTime: 60_000 });
  const [code, setCode] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState<"send" | "verify" | null>(null);

  if (!profile) return null;

  if (profile.phone_verified) {
    return (
      <div className="flex items-center gap-3 rounded-xl bg-success/10 p-4 text-success">
        <BadgeCheck className="size-6 shrink-0" />
        <div>
          <p className="font-semibold">Telefone confirmado</p>
          <p className="text-sm opacity-90">{formatPhoneBR(profile.phone)}</p>
        </div>
      </div>
    );
  }

  if (status.isLoading) {
    return (
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="size-4 animate-spin" /> Verificando serviço de SMS…
      </div>
    );
  }

  if (!status.data?.configured) {
    return (
      <div className="flex gap-3 rounded-xl border border-warning/40 bg-warning/10 p-4">
        <MessageSquareWarning className="size-6 shrink-0 text-warning" />
        <div className="text-sm">
          <p className="font-semibold">Confirmação por SMS ainda não está ativa</p>
          <p className="mt-1 text-muted-foreground">
            O envio de SMS depende de uma conta no provedor de mensagens, que o responsável pelo app ainda vai configurar.
            Seu telefone {formatPhoneBR(profile.phone)} fica salvo como <b>não confirmado</b> até lá. Você pode usar o app normalmente.
          </p>
        </div>
      </div>
    );
  }

  async function send() {
    setBusy("send");
    try {
      const r = await sendFn();
      if (r.ok) {
        setSent(true);
        toast.success(r.message);
      } else toast.error(r.message);
    } catch {
      toast.error("Falha ao enviar o código.");
    } finally {
      setBusy(null);
    }
  }

  async function verify() {
    setBusy("verify");
    try {
      const r = await verifyFn({ data: { code } });
      if (r.ok) {
        toast.success(r.message);
        qc.invalidateQueries({ queryKey: ["db", "profile"] });
      } else toast.error(r.message);
    } catch {
      toast.error("Falha ao confirmar o código.");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <p className="text-sm text-muted-foreground">
        Enviaremos um código de 6 números para <b className="text-foreground">{formatPhoneBR(profile.phone)}</b>.
      </p>
      {!sent ? (
        <Button size="lg" onClick={send} disabled={busy !== null}>
          {busy === "send" && <Loader2 className="animate-spin" />}
          Enviar código por SMS
        </Button>
      ) : (
        <>
          <InputOTP maxLength={6} value={code} onChange={setCode} inputMode="numeric" autoComplete="one-time-code">
            <InputOTPGroup>
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <InputOTPSlot key={i} index={i} className="h-12 w-11 text-lg" />
              ))}
            </InputOTPGroup>
          </InputOTP>
          <div className="flex flex-wrap gap-2">
            <Button size="lg" onClick={verify} disabled={code.length !== 6 || busy !== null}>
              {busy === "verify" && <Loader2 className="animate-spin" />}
              Confirmar
            </Button>
            <Button size="lg" variant="ghost" onClick={send} disabled={busy !== null}>
              Reenviar código
            </Button>
          </div>
        </>
      )}
    </div>
  );
}
