CREATE OR REPLACE FUNCTION public.ingest_news(p_items jsonb)
RETURNS integer
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  inserted integer;
BEGIN
  INSERT INTO public.news_items (url, title, title_key, summary, source_id, source_name, origin, published_at, cities, topics, is_alert)
  SELECT
    x->>'url',
    x->>'title',
    x->>'title_key',
    NULLIF(x->>'summary', ''),
    x->>'source_id',
    x->>'source_name',
    x->>'origin',
    NULLIF(x->>'published_at', '')::timestamptz,
    COALESCE(ARRAY(SELECT jsonb_array_elements_text(x->'cities')), '{}'),
    COALESCE(ARRAY(SELECT jsonb_array_elements_text(x->'topics')), '{}'),
    COALESCE((x->>'is_alert')::boolean, false)
  FROM jsonb_array_elements(p_items) AS x
  ON CONFLICT DO NOTHING;
  GET DIAGNOSTICS inserted = ROW_COUNT;
  RETURN inserted;
END;
$$;
REVOKE ALL ON FUNCTION public.ingest_news(jsonb) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.ingest_news(jsonb) TO service_role;
