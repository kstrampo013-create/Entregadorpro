
-- ============ PROFILES ============
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  phone_verified boolean NOT NULL DEFAULT false,
  phone_verified_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own profile select" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id);
CREATE POLICY "own profile insert" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "own profile update" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE OR REPLACE FUNCTION public.protect_profile_fields()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF coalesce(auth.role(), '') <> 'service_role' THEN
    IF TG_OP = 'INSERT' THEN
      NEW.phone_verified := false;
      NEW.phone_verified_at := NULL;
    ELSE
      NEW.phone_verified := OLD.phone_verified;
      NEW.phone_verified_at := OLD.phone_verified_at;
    END IF;
  END IF;
  IF TG_OP = 'UPDATE' AND NEW.phone IS DISTINCT FROM OLD.phone THEN
    NEW.phone_verified := false;
    NEW.phone_verified_at := NULL;
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;
CREATE TRIGGER profiles_protect BEFORE INSERT OR UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.protect_profile_fields();

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, phone, email)
  VALUES (
    NEW.id,
    coalesce(NEW.raw_user_meta_data->>'full_name', ''),
    coalesce(NEW.raw_user_meta_data->>'phone', ''),
    coalesce(NEW.email, '')
  ) ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============ PHONE VERIFICATION (server only) ============
CREATE TABLE public.phone_verifications (
  user_id uuid PRIMARY KEY,
  phone text NOT NULL,
  code_hash text NOT NULL,
  expires_at timestamptz NOT NULL,
  attempts int NOT NULL DEFAULT 0,
  sent_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.phone_verifications TO service_role;
ALTER TABLE public.phone_verifications ENABLE ROW LEVEL SECURITY;

-- ============ WORKPLACES ============
CREATE TABLE public.workplaces (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  name text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 120),
  photo_path text,
  address text,
  app_used text,
  notes text,
  start_date date,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.workplaces TO authenticated;
GRANT ALL ON public.workplaces TO service_role;
ALTER TABLE public.workplaces ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own workplaces" ON public.workplaces FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ============ EARNINGS ============
CREATE TABLE public.earnings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  source text NOT NULL CHECK (char_length(source) BETWEEN 1 AND 80),
  amount numeric(12,2) NOT NULL CHECK (amount > 0),
  date date NOT NULL,
  hours numeric(6,2) CHECK (hours IS NULL OR hours >= 0),
  km numeric(9,1) CHECK (km IS NULL OR km >= 0),
  notes text,
  workplace_id uuid REFERENCES public.workplaces(id) ON DELETE SET NULL,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX earnings_user_date ON public.earnings(user_id, date);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.earnings TO authenticated;
GRANT ALL ON public.earnings TO service_role;
ALTER TABLE public.earnings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own earnings" ON public.earnings FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ============ EXPENSES ============
CREATE TABLE public.expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  description text NOT NULL CHECK (char_length(description) BETWEEN 1 AND 120),
  category text NOT NULL CHECK (char_length(category) BETWEEN 1 AND 60),
  amount numeric(12,2) NOT NULL CHECK (amount > 0),
  date date NOT NULL,
  notes text,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX expenses_user_date ON public.expenses(user_id, date);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.expenses TO authenticated;
GRANT ALL ON public.expenses TO service_role;
ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own expenses" ON public.expenses FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ============ SALES ============
CREATE TABLE public.sales (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  customer_name text NOT NULL CHECK (char_length(customer_name) BETWEEN 1 AND 120),
  customer_phone text,
  description text NOT NULL CHECK (char_length(description) BETWEEN 1 AND 200),
  total numeric(12,2) NOT NULL CHECK (total > 0),
  down_payment numeric(12,2) NOT NULL DEFAULT 0 CHECK (down_payment >= 0),
  installments_count int NOT NULL CHECK (installments_count BETWEEN 1 AND 120),
  sale_date date NOT NULL,
  first_due_date date NOT NULL,
  notes text,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (down_payment < total)
);
GRANT SELECT, INSERT, DELETE ON public.sales TO authenticated;
GRANT UPDATE (customer_name, customer_phone, description, notes) ON public.sales TO authenticated;
GRANT ALL ON public.sales TO service_role;
ALTER TABLE public.sales ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own sales" ON public.sales FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ============ LOANS ============
CREATE TABLE public.loans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  person_name text NOT NULL CHECK (char_length(person_name) BETWEEN 1 AND 120),
  person_phone text,
  principal numeric(12,2) NOT NULL CHECK (principal > 0),
  interest_rate numeric(7,3) CHECK (interest_rate IS NULL OR interest_rate >= 0),
  total_due numeric(12,2) NOT NULL CHECK (total_due > 0),
  installments_count int NOT NULL CHECK (installments_count BETWEEN 1 AND 120),
  loan_date date NOT NULL,
  first_due_date date NOT NULL,
  notes text,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.loans TO authenticated;
GRANT UPDATE (person_name, person_phone, notes) ON public.loans TO authenticated;
GRANT ALL ON public.loans TO service_role;
ALTER TABLE public.loans ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own loans" ON public.loans FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ============ INSTALLMENTS ============
CREATE TABLE public.installments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  sale_id uuid REFERENCES public.sales(id) ON DELETE CASCADE,
  loan_id uuid REFERENCES public.loans(id) ON DELETE CASCADE,
  number int NOT NULL CHECK (number >= 1),
  amount numeric(12,2) NOT NULL CHECK (amount > 0),
  due_date date NOT NULL,
  paid_amount numeric(12,2) NOT NULL DEFAULT 0,
  paid_at date,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK ((sale_id IS NOT NULL)::int + (loan_id IS NOT NULL)::int = 1),
  UNIQUE (sale_id, number),
  UNIQUE (loan_id, number)
);
CREATE INDEX installments_user_due ON public.installments(user_id, due_date);
GRANT SELECT, INSERT, DELETE ON public.installments TO authenticated;
GRANT UPDATE (due_date) ON public.installments TO authenticated;
GRANT ALL ON public.installments TO service_role;
ALTER TABLE public.installments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own installments select" ON public.installments FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own installments insert" ON public.installments FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = user_id AND paid_amount = 0 AND (
      (sale_id IS NOT NULL AND EXISTS (SELECT 1 FROM public.sales s WHERE s.id = sale_id AND s.user_id = auth.uid()))
      OR (loan_id IS NOT NULL AND EXISTS (SELECT 1 FROM public.loans l WHERE l.id = loan_id AND l.user_id = auth.uid()))
    )
  );
CREATE POLICY "own installments update" ON public.installments FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own installments delete" ON public.installments FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ============ INSTALLMENT PAYMENTS ============
CREATE TABLE public.installment_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  installment_id uuid NOT NULL REFERENCES public.installments(id) ON DELETE CASCADE,
  amount numeric(12,2) NOT NULL CHECK (amount > 0),
  paid_on date NOT NULL,
  notes text,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX installment_payments_inst ON public.installment_payments(installment_id);
GRANT SELECT, INSERT, DELETE ON public.installment_payments TO authenticated;
GRANT ALL ON public.installment_payments TO service_role;
ALTER TABLE public.installment_payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own payments select" ON public.installment_payments FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own payments insert" ON public.installment_payments FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id AND EXISTS (SELECT 1 FROM public.installments i WHERE i.id = installment_id AND i.user_id = auth.uid()));
CREATE POLICY "own payments delete" ON public.installment_payments FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Prevent overpayment
CREATE OR REPLACE FUNCTION public.validate_installment_payment()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE v_amount numeric; v_paid numeric;
BEGIN
  SELECT amount INTO v_amount FROM public.installments WHERE id = NEW.installment_id FOR UPDATE;
  SELECT coalesce(sum(amount), 0) INTO v_paid FROM public.installment_payments WHERE installment_id = NEW.installment_id;
  IF v_paid + NEW.amount > v_amount + 0.001 THEN
    RAISE EXCEPTION 'Pagamento maior que o saldo da parcela (saldo: %)', v_amount - v_paid USING ERRCODE = 'P0001';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER installment_payments_validate BEFORE INSERT ON public.installment_payments
FOR EACH ROW EXECUTE FUNCTION public.validate_installment_payment();

-- Keep paid_amount / paid_at in sync (single source of truth = payments)
CREATE OR REPLACE FUNCTION public.sync_installment_paid()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_id uuid; v_sum numeric; v_last date; v_amount numeric;
BEGIN
  v_id := coalesce(NEW.installment_id, OLD.installment_id);
  SELECT coalesce(sum(amount), 0), max(paid_on) INTO v_sum, v_last FROM public.installment_payments WHERE installment_id = v_id;
  SELECT amount INTO v_amount FROM public.installments WHERE id = v_id;
  UPDATE public.installments
     SET paid_amount = v_sum,
         paid_at = CASE WHEN v_sum >= v_amount - 0.001 THEN v_last ELSE NULL END
   WHERE id = v_id;
  RETURN NULL;
END $$;
CREATE TRIGGER installment_payments_sync AFTER INSERT OR DELETE ON public.installment_payments
FOR EACH ROW EXECUTE FUNCTION public.sync_installment_paid();

-- ============ RPCs for atomic creation ============
CREATE OR REPLACE FUNCTION public.create_sale_with_installments(p_sale jsonb, p_installments jsonb)
RETURNS uuid LANGUAGE plpgsql SET search_path = public AS $$
DECLARE v_id uuid; v_sum numeric; v_count int; v_total numeric; v_down numeric; v_n int;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  v_id := coalesce((p_sale->>'id')::uuid, gen_random_uuid());
  v_total := (p_sale->>'total')::numeric;
  v_down := coalesce((p_sale->>'down_payment')::numeric, 0);
  v_n := (p_sale->>'installments_count')::int;
  SELECT coalesce(sum((x->>'amount')::numeric), 0), count(*) INTO v_sum, v_count FROM jsonb_array_elements(p_installments) x;
  IF v_count <> v_n THEN RAISE EXCEPTION 'Quantidade de parcelas inconsistente'; END IF;
  IF abs(v_sum - (v_total - v_down)) > 0.005 THEN RAISE EXCEPTION 'Soma das parcelas difere do valor financiado'; END IF;

  INSERT INTO public.sales (id, customer_name, customer_phone, description, total, down_payment, installments_count, sale_date, first_due_date, notes, is_demo)
  VALUES (v_id, p_sale->>'customer_name', nullif(p_sale->>'customer_phone', ''), p_sale->>'description', v_total, v_down, v_n,
          (p_sale->>'sale_date')::date, (p_sale->>'first_due_date')::date, nullif(p_sale->>'notes', ''), coalesce((p_sale->>'is_demo')::boolean, false));

  INSERT INTO public.installments (sale_id, number, amount, due_date, is_demo)
  SELECT v_id, (x->>'number')::int, (x->>'amount')::numeric, (x->>'due_date')::date, coalesce((p_sale->>'is_demo')::boolean, false)
  FROM jsonb_array_elements(p_installments) x;
  RETURN v_id;
END $$;

CREATE OR REPLACE FUNCTION public.create_loan_with_installments(p_loan jsonb, p_installments jsonb)
RETURNS uuid LANGUAGE plpgsql SET search_path = public AS $$
DECLARE v_id uuid; v_sum numeric; v_count int; v_total numeric; v_n int;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  v_id := coalesce((p_loan->>'id')::uuid, gen_random_uuid());
  v_total := (p_loan->>'total_due')::numeric;
  v_n := (p_loan->>'installments_count')::int;
  SELECT coalesce(sum((x->>'amount')::numeric), 0), count(*) INTO v_sum, v_count FROM jsonb_array_elements(p_installments) x;
  IF v_count <> v_n THEN RAISE EXCEPTION 'Quantidade de parcelas inconsistente'; END IF;
  IF abs(v_sum - v_total) > 0.005 THEN RAISE EXCEPTION 'Soma das parcelas difere do total combinado'; END IF;

  INSERT INTO public.loans (id, person_name, person_phone, principal, interest_rate, total_due, installments_count, loan_date, first_due_date, notes, is_demo)
  VALUES (v_id, p_loan->>'person_name', nullif(p_loan->>'person_phone', ''), (p_loan->>'principal')::numeric,
          nullif(p_loan->>'interest_rate', '')::numeric, v_total, v_n,
          (p_loan->>'loan_date')::date, (p_loan->>'first_due_date')::date, nullif(p_loan->>'notes', ''), coalesce((p_loan->>'is_demo')::boolean, false));

  INSERT INTO public.installments (loan_id, number, amount, due_date, is_demo)
  SELECT v_id, (x->>'number')::int, (x->>'amount')::numeric, (x->>'due_date')::date, coalesce((p_loan->>'is_demo')::boolean, false)
  FROM jsonb_array_elements(p_installments) x;
  RETURN v_id;
END $$;
GRANT EXECUTE ON FUNCTION public.create_sale_with_installments(jsonb, jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.create_loan_with_installments(jsonb, jsonb) TO authenticated;

-- ============ RECURRING BILLS ============
CREATE TABLE public.bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  name text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 120),
  expected_amount numeric(12,2) NOT NULL CHECK (expected_amount > 0),
  due_day int NOT NULL CHECK (due_day BETWEEN 1 AND 31),
  category text NOT NULL DEFAULT 'Outros',
  interval_months int NOT NULL DEFAULT 1 CHECK (interval_months IN (1, 2, 3, 6, 12)),
  start_month date NOT NULL,
  end_month date,
  active boolean NOT NULL DEFAULT true,
  notes text,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bills TO authenticated;
GRANT ALL ON public.bills TO service_role;
ALTER TABLE public.bills ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own bills" ON public.bills FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE public.bill_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  bill_id uuid NOT NULL REFERENCES public.bills(id) ON DELETE CASCADE,
  reference_month date NOT NULL,
  paid_amount numeric(12,2) NOT NULL CHECK (paid_amount > 0),
  paid_on date NOT NULL,
  notes text,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (bill_id, reference_month)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bill_payments TO authenticated;
GRANT ALL ON public.bill_payments TO service_role;
ALTER TABLE public.bill_payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own bill payments select" ON public.bill_payments FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own bill payments insert" ON public.bill_payments FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id AND EXISTS (SELECT 1 FROM public.bills b WHERE b.id = bill_id AND b.user_id = auth.uid()));
CREATE POLICY "own bill payments update" ON public.bill_payments FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own bill payments delete" ON public.bill_payments FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ============ STORAGE POLICIES (bucket workplace-photos) ============
CREATE POLICY "workplace photos read own" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'workplace-photos' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "workplace photos insert own" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'workplace-photos' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "workplace photos update own" ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'workplace-photos' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "workplace photos delete own" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'workplace-photos' AND (storage.foldername(name))[1] = auth.uid()::text);
