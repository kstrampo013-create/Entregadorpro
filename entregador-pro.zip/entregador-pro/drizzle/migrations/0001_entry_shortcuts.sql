CREATE TABLE public.entry_shortcuts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  kind text NOT NULL CHECK (kind IN ('earning', 'expense')),
  name text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 60),
  topic text NOT NULL CHECK (char_length(topic) BETWEEN 1 AND 80),
  description text,
  amount numeric(12,2) CHECK (amount IS NULL OR amount > 0),
  hours numeric(6,2) CHECK (hours IS NULL OR hours >= 0),
  km numeric(9,1) CHECK (km IS NULL OR km >= 0),
  notes text,
  workplace_id uuid REFERENCES public.workplaces(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, kind, name)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.entry_shortcuts TO authenticated;
GRANT ALL ON public.entry_shortcuts TO service_role;
ALTER TABLE public.entry_shortcuts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own shortcuts" ON public.entry_shortcuts FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
