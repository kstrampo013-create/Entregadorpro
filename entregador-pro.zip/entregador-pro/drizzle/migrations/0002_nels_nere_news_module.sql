-- Nels Nere: shared regional news (written only by the server collector)
CREATE TABLE public.news_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url text NOT NULL UNIQUE,
  title text NOT NULL,
  title_key text NOT NULL UNIQUE,
  summary text,
  source_id text NOT NULL,
  source_name text NOT NULL,
  origin text NOT NULL CHECK (origin IN ('rss', 'google')),
  published_at timestamptz,
  fetched_at timestamptz NOT NULL DEFAULT now(),
  cities text[] NOT NULL DEFAULT '{}',
  topics text[] NOT NULL DEFAULT '{}',
  is_alert boolean NOT NULL DEFAULT false
);
CREATE INDEX news_items_published_idx ON public.news_items (published_at DESC NULLS LAST);
CREATE INDEX news_items_fetched_idx ON public.news_items (fetched_at DESC);
CREATE INDEX news_items_cities_idx ON public.news_items USING gin (cities);
CREATE INDEX news_items_topics_idx ON public.news_items USING gin (topics);
GRANT SELECT ON public.news_items TO authenticated;
GRANT ALL ON public.news_items TO service_role;
ALTER TABLE public.news_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "signed-in users read news" ON public.news_items FOR SELECT TO authenticated USING (true);

CREATE TABLE public.news_source_status (
  source_id text PRIMARY KEY,
  ok boolean NOT NULL DEFAULT false,
  last_run_at timestamptz,
  last_ok_at timestamptz,
  last_count integer NOT NULL DEFAULT 0,
  last_error text
);
GRANT SELECT ON public.news_source_status TO authenticated;
GRANT ALL ON public.news_source_status TO service_role;
ALTER TABLE public.news_source_status ENABLE ROW LEVEL SECURITY;
CREATE POLICY "signed-in users read source status" ON public.news_source_status FOR SELECT TO authenticated USING (true);

-- Background job lease + circuit breaker state
CREATE TABLE public.job_state (
  name text PRIMARY KEY,
  locked_until timestamptz,
  last_run_at timestamptz,
  last_ingest_at timestamptz,
  paused_reason text,
  paused_at timestamptz,
  last_error text
);
GRANT SELECT ON public.job_state TO authenticated;
GRANT ALL ON public.job_state TO service_role;
ALTER TABLE public.job_state ENABLE ROW LEVEL SECURITY;
CREATE POLICY "signed-in users read job state" ON public.job_state FOR SELECT TO authenticated USING (true);

-- Per-user preferences
CREATE TABLE public.news_preferences (
  user_id uuid PRIMARY KEY DEFAULT auth.uid(),
  cities text[] NOT NULL DEFAULT '{}',
  topics text[] NOT NULL DEFAULT '{}',
  morning_enabled boolean NOT NULL DEFAULT true,
  morning_time time NOT NULL DEFAULT '06:00',
  afternoon_enabled boolean NOT NULL DEFAULT true,
  afternoon_time time NOT NULL DEFAULT '16:00',
  tg_bulletins boolean NOT NULL DEFAULT true,
  tg_alerts boolean NOT NULL DEFAULT true,
  tg_topics text[] NOT NULL DEFAULT '{}',
  tg_from time NOT NULL DEFAULT '07:00',
  tg_until time NOT NULL DEFAULT '22:00',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.news_preferences TO authenticated;
GRANT ALL ON public.news_preferences TO service_role;
ALTER TABLE public.news_preferences ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own news preferences" ON public.news_preferences FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Bulletins (written by the server, read/deleted by the owner)
CREATE TABLE public.bulletins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  slot text NOT NULL CHECK (slot IN ('manha', 'tarde', 'avulso')),
  bulletin_date date NOT NULL,
  period_start timestamptz NOT NULL,
  period_end timestamptz NOT NULL,
  title text NOT NULL,
  intro text,
  outro text,
  body_text text NOT NULL,
  items jsonb NOT NULL DEFAULT '[]',
  sources text[] NOT NULL DEFAULT '{}',
  cities text[] NOT NULL DEFAULT '{}',
  audio_path text,
  audio_status text CHECK (audio_status IN ('generating', 'ready', 'failed')),
  audio_started_at timestamptz,
  telegram_status text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX bulletins_one_per_slot ON public.bulletins (user_id, slot, bulletin_date) WHERE slot <> 'avulso';
CREATE INDEX bulletins_user_idx ON public.bulletins (user_id, created_at DESC);
GRANT SELECT, DELETE ON public.bulletins TO authenticated;
GRANT ALL ON public.bulletins TO service_role;
ALTER TABLE public.bulletins ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own bulletins read" ON public.bulletins FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own bulletins delete" ON public.bulletins FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Telegram linking
CREATE TABLE public.telegram_links (
  user_id uuid PRIMARY KEY,
  chat_id bigint NOT NULL UNIQUE,
  tg_username text,
  tg_name text,
  linked_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, DELETE ON public.telegram_links TO authenticated;
GRANT ALL ON public.telegram_links TO service_role;
ALTER TABLE public.telegram_links ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own telegram link read" ON public.telegram_links FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own telegram link delete" ON public.telegram_links FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TABLE public.telegram_link_codes (
  code text PRIMARY KEY,
  user_id uuid NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.telegram_link_codes TO service_role;
ALTER TABLE public.telegram_link_codes ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.notification_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  news_id uuid NOT NULL REFERENCES public.news_items(id) ON DELETE CASCADE,
  kind text NOT NULL,
  sent_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, news_id)
);
GRANT ALL ON public.notification_log TO service_role;
ALTER TABLE public.notification_log ENABLE ROW LEVEL SECURITY;

-- Thassi conversations (threads saved in the account)
CREATE TABLE public.chat_threads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  title text NOT NULL DEFAULT 'Nova conversa',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX chat_threads_user_idx ON public.chat_threads (user_id, updated_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_threads TO authenticated;
GRANT ALL ON public.chat_threads TO service_role;
ALTER TABLE public.chat_threads ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own chat threads" ON public.chat_threads FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE public.chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id uuid NOT NULL REFERENCES public.chat_threads(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid(),
  message_id text NOT NULL,
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  parts jsonb NOT NULL DEFAULT '[]',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (thread_id, message_id)
);
CREATE INDEX chat_messages_thread_idx ON public.chat_messages (thread_id, created_at);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_messages TO authenticated;
GRANT ALL ON public.chat_messages TO service_role;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own chat messages" ON public.chat_messages FOR ALL TO authenticated
  USING (auth.uid() = user_id AND EXISTS (SELECT 1 FROM public.chat_threads t WHERE t.id = thread_id AND t.user_id = auth.uid()))
  WITH CHECK (auth.uid() = user_id AND EXISTS (SELECT 1 FROM public.chat_threads t WHERE t.id = thread_id AND t.user_id = auth.uid()));

INSERT INTO public.job_state (name) VALUES ('nels-nere') ON CONFLICT DO NOTHING;
